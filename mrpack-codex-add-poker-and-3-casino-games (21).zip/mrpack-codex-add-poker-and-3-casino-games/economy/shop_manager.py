import html
import json
import time
from pathlib import Path
from typing import Any, Dict, Iterable, Optional, Tuple

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.constants import ParseMode

from economy.storage import PLAN_BASIC, PLAN_ULTIMATE


class ShopManager:
    """Fixed-item shop with JSON definitions."""

    def __init__(self, bot: Any) -> None:
        self.bot = bot
        self.items = self._load_items()
        self.items_map = {item.get("code"): item for item in self.items if item.get("code")}

    def _load_items(self) -> Tuple[Dict[str, Any], ...]:
        config_path = Path(__file__).with_name("fixed_items.json")
        if not config_path.exists():
            return tuple()
        try:
            data = json.loads(config_path.read_text(encoding="utf-8"))
            items: list[Dict[str, Any]] = []
            for entry in data:
                if not entry.get("code"):
                    continue
                items.append(entry)
            return tuple(items)
        except Exception:
            return tuple()

    def visible_items(self, plan_code: str) -> Tuple[Dict[str, Any], ...]:
        """Hide job-related upgrades for users без доступа к работам."""

        if getattr(self.bot, "_plan_allowed")(plan_code, PLAN_ULTIMATE):
            return self.items
        return tuple(
            item for item in self.items if not str(item.get("type", "")).startswith("upgrade")
        )

    def upgrade_items(self, plan_code: str) -> Tuple[Dict[str, Any], ...]:
        """Return only upgrade items for job-related boosts."""

        items = self.visible_items(plan_code)
        return tuple(item for item in items if str(item.get("type", "")).startswith("upgrade"))

    # ---------- rendering helpers ----------
    def build_purchase_keyboard(self, chat_id: int, buyer_id: int, page: int, total_pages: int) -> Optional[InlineKeyboardMarkup]:
        if total_pages <= 1:
            return None
        buttons = []
        row = []
        if page > 0:
            row.append(InlineKeyboardButton("←", callback_data=f"purchases:{chat_id}:{buyer_id}:{page-1}"))
        if page < total_pages - 1:
            row.append(InlineKeyboardButton("→", callback_data=f"purchases:{chat_id}:{buyer_id}:{page+1}"))
        if row:
            buttons.append(row)
        return InlineKeyboardMarkup(buttons) if buttons else None

    @staticmethod
    def render_shop_menu_text() -> str:
        return "Магазин. Выбери товар:"

    @staticmethod
    def render_upgrade_menu_text() -> str:
        return "Магазин прокачки. Выбери улучшение:"
    def render_item_text(self, item: Dict[str, Any], currency: Dict) -> str:
        from economy.formatters import format_currency

        title = item.get("name")
        price = item.get("price", 0)
        description = item.get("description") or ""
        active_type = item.get("type_label") or item.get("type", "")
        target_note = " (требует указания цели)" if item.get("target_required") else ""
        activate_label = "активируемый" if item.get("activatable") else "неактивируемый"
        return (
            f"<b>{title}</b>\n"
            f"Цена: {format_currency(price, currency)}\n"
            f"Тип: {activate_label}{target_note}\n"
            f"Категория: {active_type}\n"
            f"{html.escape(description)}"
        )

    def render_purchases(self, items: tuple, currency: Dict) -> str:
        if not items:
            return "<b>История покупок пуста.</b>"
        from economy.formatters import format_currency

        lines = ["<b>История покупок:</b>"]
        for idx, (pid, title, price, seller_username, seller_id, created_at, item_code, consumed) in enumerate(items, start=1):
            timestamp = time.strftime("%d.%m.%Y", time.localtime(created_at))
            safe_title = html.escape(title)
            meta = self.items_map.get(item_code, {})
            type_label = meta.get("type_label") or meta.get("type") or ""
            activatable = meta.get("activatable", False)
            target_required = meta.get("target_required", False)
            if activatable:
                type_label = "активируемый" + (" (нужна цель)" if target_required else "") + (f" | {type_label}" if type_label else "")
            else:
                type_label = "неактивируемый" + (f" | {type_label}" if type_label else "")
            idx_label = f"#{idx} (Неактивно)" if consumed else f"#{idx}"
            lines.append(
                f"• {idx_label} <blockquote>{safe_title}</blockquote>\n"
                f"Тип: {type_label}\n"
                f"<i>{timestamp}</i> ~ <b>{format_currency(price, currency)}</b>"
            )
        return "\n\n".join(lines)

    # ---------- keyboards ----------
    def build_shop_keyboard(
        self,
        chat_id: int,
        items: Iterable[Dict[str, Any]],
        currency_icon: str,
        page: int = 0,
        *,
        callback_prefix: str = "shop",
    ) -> Optional[InlineKeyboardMarkup]:
        items = tuple(items)
        if not items:
            return None
        page_size = getattr(self.bot, "SHOP_PAGE_SIZE", getattr(self.bot, "shop_page_size", 5))
        start = page * page_size
        end = start + page_size
        current = items[start:end]
        from economy.formatters import format_currency

        buttons = []
        for idx, item in enumerate(current, start=start + 1):
            price = item.get("price", 0)
            buttons.append(
                [
                    InlineKeyboardButton(
                        f"[{idx}] {item.get('name')}: {format_currency(price, {'icon': currency_icon})}",
                        callback_data=f"{callback_prefix}:view:{chat_id}:{page}:{idx}",
                    )
                ]
            )
        nav_row = []
        total_pages = max(1, (len(items) + page_size - 1) // page_size)
        if page > 0:
            nav_row.append(InlineKeyboardButton("←", callback_data=f"{callback_prefix}:open:{chat_id}:{page-1}"))
        if page < total_pages - 1:
            nav_row.append(InlineKeyboardButton("→", callback_data=f"{callback_prefix}:open:{chat_id}:{page+1}"))
        if nav_row:
            buttons.append(nav_row)
        return InlineKeyboardMarkup(buttons)

    # ---------- callbacks ----------
    async def _handle_shop_callback(
        self,
        update: Update,
        context,
        *,
        items: Tuple[Dict[str, Any], ...],
        menu_text: str,
        empty_text: str,
        callback_prefix: str,
    ) -> None:
        query = update.callback_query
        if not query:
            return
        if not await self.bot._ensure_subscription(query.from_user, context):
            await query.answer("❌ Требуется подписка на новости.", show_alert=True)
            return
        await query.answer()
        parts = query.data.split(":")
        if len(parts) < 3:
            return
        action = parts[1]
        chat_id = int(parts[2])
        page = int(parts[3]) if len(parts) > 3 else 0
        index = int(parts[4]) if len(parts) > 4 else None
        session_key = None
        if query.message:
            session_key = f"{query.message.chat_id}:{query.message.message_id}"
        store = self.bot.ensure_storage()
        if await store.is_blocked(chat_id) and not self.bot.ensure_creator(update):
            await query.answer("Ваша группа неожиданно разорвала соединение с ботом. Код ошибки: POSHEL_NAHUY", show_alert=True)
            return
        if await store.is_banned(chat_id, query.from_user.id):
            await query.answer("Команда не распознана. Попробуй !!poshel naxui", show_alert=True)
            return
        currency = await store.chat_currency(chat_id)
        page_size = getattr(self.bot, "SHOP_PAGE_SIZE", getattr(self.bot, "shop_page_size", 5))
        total_pages = max(1, (len(items) + page_size - 1) // page_size)
        page = max(0, min(page, total_pages - 1))
        keyboard = self.build_shop_keyboard(
            chat_id,
            items,
            currency.get("icon", "💰"),
            page=page,
            callback_prefix=callback_prefix,
        )
        if action == "open":
            if session_key:
                self.bot.shop_sessions.pop(session_key, None)
            text = menu_text if items else empty_text
            await query.edit_message_text(text, reply_markup=keyboard, parse_mode=ParseMode.HTML)
            return
        if action == "view" and index:
            if not items or index < 1 or index > len(items):
                await query.edit_message_text("Товар не найден.")
                return
            item = items[index - 1]
            await query.edit_message_text(
                self.render_item_text(item, currency),
                reply_markup=InlineKeyboardMarkup(
                    [
                        [InlineKeyboardButton("Приобрести", callback_data=f"{callback_prefix}:confirm:{chat_id}:{page}:{index}")],
                        [InlineKeyboardButton("Назад", callback_data=f"{callback_prefix}:open:{chat_id}:{page}")],
                    ]
                ),
                parse_mode=ParseMode.HTML,
            )
            return
        if action == "confirm" and index:
            if session_key:
                if self.bot.shop_sessions.get(session_key) == query.data:
                    await query.answer("Покупка уже обработана", show_alert=True)
                    return
                self.bot.shop_sessions[session_key] = query.data
            if not items or index < 1 or index > len(items):
                await query.edit_message_text("Товар не найден.")
                return
            item = items[index - 1]
            title = item.get("name")
            price_value = int(item.get("price", 0))
            min_tx = getattr(self.bot, "MIN_TRANSACTION", getattr(self.bot, "min_transaction", 50))
            max_tx = getattr(self.bot, "MAX_TRANSACTION", getattr(self.bot, "max_transaction", 100_000_000))
            if price_value < min_tx or price_value > max_tx:
                await query.edit_message_text("Цена товара вне допустимого диапазона.")
                return
            buyer = query.from_user
            buyer_name = buyer.username or buyer.full_name
            tax_rate = max(0, min(10000, int(currency.get("tax_rate", 500))))
            if await store.tax_holiday_remaining(chat_id) > 0:
                tax_rate = 0
            idem_key = f"fixed:{chat_id}:{query.message.message_id}:{buyer.id}:{item.get('code')}"
            try:
                result = await store.purchase_fixed_item(
                    chat_id=chat_id,
                    buyer_id=buyer.id,
                    buyer_username=buyer_name,
                    item_code=item.get("code", ""),
                    title=title,
                    price=price_value,
                    tax_rate=tax_rate,
                    idempotency_key=idem_key,
                    consumed=not item.get("activatable", False),
                    metadata={"message_id": query.message.message_id},
                )
            except ValueError:
                await query.edit_message_text(
                    "Недостаточно средств для покупки.",
                    reply_markup=InlineKeyboardMarkup(
                        [[InlineKeyboardButton("Назад", callback_data=f"{callback_prefix}:open:{chat_id}:{page}")]]
                    ),
                )
                return
            if result is None:
                await query.edit_message_text("Покупка уже обработана.")
                return
            await store.log_event(
                chat_id,
                f"{self.bot.log_handle(user=buyer)} купил {title} за {price_value}",
            )
            try:
                await store.update_job_rating(chat_id, buyer.id, delta=0.05)
            except Exception:
                pass
            from economy.formatters import format_currency
            await store.log_event(
                chat_id,
                f"Пользователь {self.bot.log_handle(buyer)} купил '{title}' за {format_currency(price_value, currency)} (налог {tax_rate / 100:.2f}%)",
            )
            if item.get("type", "").startswith("upgrade"):
                await self.bot.jobs.apply_shop_upgrade(chat_id, buyer.id, item, currency)
            await query.edit_message_text(
                f"<b>Транзакция завершена!</b> Вы приобрели <b>{title}</b> за {format_currency(price_value, currency)}."
                f" Баланс: {format_currency(result['new_balance'], currency)}",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Назад", callback_data=f"{callback_prefix}:open:{chat_id}:{page}")]]),
                parse_mode=ParseMode.HTML,
            )
            return

    async def handle_shop_callback(self, update: Update, context) -> None:
        query = update.callback_query
        if not query:
            return
        parts = query.data.split(":") if query.data else []
        if len(parts) < 3:
            return
        chat_id = int(parts[2])
        plan_info = await self.bot._plan_for_chat(chat_id, context)
        items = self.visible_items(plan_info.get("plan", PLAN_BASIC))
        await self._handle_shop_callback(
            update,
            context,
            items=items,
            menu_text=self.render_shop_menu_text(),
            empty_text="Магазин пуст.",
            callback_prefix="shop",
        )

    async def handle_upgrade_callback(self, update: Update, context) -> None:
        query = update.callback_query
        if not query:
            return
        parts = query.data.split(":") if query.data else []
        if len(parts) < 3:
            return
        chat_id = int(parts[2])
        plan_info = await self.bot._plan_for_chat(chat_id, context)
        items = self.upgrade_items(plan_info.get("plan", PLAN_BASIC))
        await self._handle_shop_callback(
            update,
            context,
            items=items,
            menu_text=self.render_upgrade_menu_text(),
            empty_text="Магазин прокачки пуст.",
            callback_prefix="upshop",
        )

    async def handle_purchases_callback(self, update: Update, context) -> None:
        query = update.callback_query
        if not query:
            return
        parts = query.data.split(":")
        if len(parts) < 4:
            return
        chat_id = int(parts[1])
        buyer_id = int(parts[2])
        page = int(parts[3])
        session = self.bot.purchases_sessions.get(query.message.message_id) if query.message else None
        if session:
            chat_id = session.get("chat_id", chat_id)
            buyer_id = session.get("buyer_id", buyer_id)
            viewer_id = session.get("viewer_id")
            allowed = {buyer_id, viewer_id, query.from_user.id}
            if not self.bot.ensure_creator(update) and query.from_user.id not in allowed:
                await query.answer("Это не ваша история", show_alert=True)
                return
        elif query.from_user.id != buyer_id and not self.bot.ensure_creator(update):
            await query.answer("Это не ваша история", show_alert=True)
            return
        store = self.bot.ensure_storage()
        if await store.is_blocked(chat_id) and not self.bot.ensure_creator(update):
            await query.answer("Ваша группа неожиданно разорвала соединение с ботом. Код ошибки: POSHEL_NAHUY", show_alert=True)
            return
        if await store.is_banned(chat_id, query.from_user.id):
            await query.answer("Команда не распознана. Попробуй !!poshel naxui", show_alert=True)
            return
        currency = await store.chat_currency(chat_id)
        total = await store.purchases_count(chat_id, buyer_id, include_consumed=True)
        per_page = 5
        total_pages = max(1, (total + per_page - 1) // per_page)
        page = max(0, min(page, total_pages - 1))
        items = await store.list_purchases(
            chat_id, buyer_id, limit=per_page, offset=page * per_page, include_consumed=True
        )
        keyboard = self.build_purchase_keyboard(chat_id, buyer_id, page, total_pages)
        await query.edit_message_text(self.render_purchases(items, currency), reply_markup=keyboard)


__all__ = ["ShopManager"]
