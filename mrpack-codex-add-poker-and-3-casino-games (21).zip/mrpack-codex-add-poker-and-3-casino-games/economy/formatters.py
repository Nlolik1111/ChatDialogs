from typing import Dict


def _format_amount(amount: int) -> str:
    sign = "-" if amount < 0 else ""
    units = abs(int(amount))
    return f"{sign}{units}"


def russian_plural(amount: int, forms: Dict[str, str]) -> str:
    number = abs(int(amount))
    last_two = number % 100
    last_digit = number % 10

    if 11 <= last_two <= 19:
        return forms.get("many") or forms.get("one") or ""
    if last_digit == 1:
        return forms.get("one") or ""
    if 2 <= last_digit <= 4:
        return forms.get("few") or forms.get("many") or ""
    return forms.get("many") or forms.get("few") or ""


def format_currency(amount_cents: int, currency: Dict, *, include_name: bool = False) -> str:
    name = currency.get("name", "валюта")
    icon = currency.get("icon", "💰")
    cases = currency.get(
        "cases", {"one": name, "few": f"{name}а", "many": f"{name}ов"}
    )
    if currency.get("auto_declension", True):
        name = russian_plural(amount_cents, cases)
    suffix = f" {name}" if include_name else ""
    return f"{_format_amount(amount_cents)} {icon}{suffix}"
