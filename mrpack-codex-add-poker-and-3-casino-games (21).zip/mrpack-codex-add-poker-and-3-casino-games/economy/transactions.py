import asyncio
import logging
import time
from io import BytesIO
from pathlib import Path
from typing import Any, Optional

from PIL import Image
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Message, Update
from telegram.constants import ParseMode
from telegram.ext import ContextTypes

from economy.formatters import format_currency

logger = logging.getLogger(__name__)


class Transactions:
    def __init__(self, bot: Any) -> None:
        self.bot = bot
        self.receipts_dir = Path("Payments")
        self.receipt_ttl_seconds = getattr(bot, "RECEIPT_TTL_SECONDS", 7 * 24 * 3600)
        self.receipt_max_files = getattr(bot, "RECEIPT_MAX_FILES", 200)

    def cancel_receipt_timeout(self, user_id: int, plan_code: str) -> None:
        task = self.bot.receipt_wait_tasks.pop((user_id, plan_code), None)
        if task:
            task.cancel()

    @staticmethod
    def extract_receipt(message: Message) -> tuple[Optional[str], str]:
        """Return (file_id, kind) for any image-like payload or receipt document."""

        if message.photo:
            return message.photo[-1].file_id, "photo"
        if message.animation:
            return message.animation.file_id, "animation"
        if message.document:
            doc = message.document
            mime = (doc.mime_type or "").lower()
            name = (doc.file_name or "").lower()
            if mime.startswith("image") or name.endswith(
                (".jpg", ".jpeg", ".png", ".webp", ".heic", ".heif", ".gif")
            ):
                return doc.file_id, "document"
            # Принимаем любые документы как чек (pdf и пр.)
            return doc.file_id, "document"
        return None, ""

    async def schedule_receipt_timeout(
        self,
        context: ContextTypes.DEFAULT_TYPE,
        user_id: int,
        plan_code: str,
        amount: float,
    ) -> None:
        key = (user_id, plan_code)

        async def waiter() -> None:
            await asyncio.sleep(600)
            store = self.bot.ensure_storage()
            pending = await store.get_pending_transfer(user_id)
            if not pending or pending.get("plan") != plan_code or pending.get("file_id"):
                return
            creator_id = await self.bot._creator_chat_id(context)
            caption = (
                f"⚠️ Пользователь {self.bot.mention_id(user_id)} не прикрепил квитанцию за 10 минут\n"
                f"План: {plan_code}, сумма: {amount}₽"
            )
            if creator_id:
                buttons = InlineKeyboardMarkup(
                    [
                        [InlineKeyboardButton("Одобрить", callback_data=f"plans:approve:{user_id}:{plan_code}")],
                        [InlineKeyboardButton("Отклонить", callback_data=f"plans:decline:{user_id}:{plan_code}")],
                    ]
                )
                await store.set_pending_transfer(
                    user_id,
                    plan_code,
                    amount,
                    pending.get("method", "transfer"),
                    file_id=pending.get("file_id"),
                    prompt_id=pending.get("prompt_id"),
                    ttl_seconds=3600,
                )
                await self.bot._safe_send_message(
                    context,
                    chat_id=creator_id,
                    text=caption,
                    reply_markup=buttons,
                    parse_mode=ParseMode.HTML,
                )

        task = asyncio.create_task(waiter())
        self.cancel_receipt_timeout(user_id, plan_code)
        self.bot.receipt_wait_tasks[key] = task

    def _cleanup_receipts(self) -> None:
        if not self.receipts_dir.exists():
            return
        try:
            files = [p for p in self.receipts_dir.iterdir() if p.is_file()]
        except Exception:
            return
        now = time.time()
        ttl = self.receipt_ttl_seconds
        max_files = self.receipt_max_files
        for file in files:
            try:
                if now - file.stat().st_mtime > ttl:
                    file.unlink(missing_ok=True)
            except Exception:
                logger.debug("Не удалось удалить старый чек: %s", file)
        if max_files <= 0:
            return
        try:
            files = [p for p in self.receipts_dir.iterdir() if p.is_file()]
        except Exception:
            return
        if len(files) <= max_files:
            return
        files.sort(key=lambda p: p.stat().st_mtime)
        for file in files[: max(0, len(files) - max_files)]:
            try:
                file.unlink(missing_ok=True)
            except Exception:
                logger.debug("Не удалось удалить чек по лимиту: %s", file)

    async def forward_receipt(
        self,
        message: Message,
        plan_code: str,
        amount: float,
        user_id: int,
        context: ContextTypes.DEFAULT_TYPE,
    ) -> bool:
        creator_id = self.bot.settings.creator_id
        if not creator_id:
            return False
        caption = (
            f"🧾 Квитанция от {self.bot.mention_id(user_id)}\n"
            f"План: {plan_code}, сумма: {amount}₽"
        )
        buttons = InlineKeyboardMarkup(
            [
                [InlineKeyboardButton("Одобрить", callback_data=f"plans:approve:{user_id}:{plan_code}")],
                [InlineKeyboardButton("Отклонить", callback_data=f"plans:decline:{user_id}:{plan_code}")],
            ]
        )
        file_id, kind = self.extract_receipt(message)
        if not file_id:
            logger.warning(
                "Квитанция не распознана: user_id=%s, has_photo=%s, has_document=%s, has_animation=%s",
                user_id,
                bool(message.photo),
                bool(message.document),
                bool(message.animation),
            )
            return False
        try:
            self.receipts_dir.mkdir(parents=True, exist_ok=True)
            file = await context.bot.get_file(file_id)
            data = await file.download_as_bytearray()
            file_unique = f"{user_id}_{plan_code}_{int(time.time())}"
            filename = None
            saved_path = None
            if kind in {"photo", "animation", "document"}:
                try:
                    image = Image.open(BytesIO(data))
                    if image.mode not in {"RGB", "L"}:
                        image = image.convert("RGB")
                    filename = f"receipt_{file_unique}.jpg"
                    saved_path = self.receipts_dir / filename
                    image.save(saved_path, format="JPEG")
                except Exception:
                    filename = None
            if not filename:
                if message.document:
                    filename = message.document.file_name or f"receipt_{file_unique}.dat"
                elif message.animation:
                    filename = f"receipt_{file_unique}.gif"
                else:
                    filename = f"receipt_{file_unique}.jpg"
                saved_path = self.receipts_dir / filename
                saved_path.write_bytes(bytes(data))
                logger.info("Квитанция сохранена без конвертации: %s", saved_path)
            with saved_path.open("rb") as handle:
                await context.bot.send_document(
                    creator_id,
                    document=handle,
                    filename=saved_path.name,
                    caption=caption,
                    reply_markup=buttons,
                    parse_mode=ParseMode.HTML,
                )
            logger.info(
                "Квитанция отправлена создателю: user_id=%s, plan=%s, file=%s",
                user_id,
                plan_code,
                saved_path,
            )
            self._cleanup_receipts()
            return True
        except Exception as exc:
            logger.exception(
                "Не удалось переслать квитанцию создателю: user_id=%s, plan=%s, kind=%s, error=%s",
                user_id,
                plan_code,
                kind,
                exc,
            )
            return False

    async def successful_payment_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        payment = update.message.successful_payment if update.message else None
        if not payment:
            return
        payload = payment.invoice_payload or ""
        if not payload.startswith("plan:"):
            return
        _tag, plan_code, months_raw = payload.split(":")
        months = 1
        try:
            months = int(months_raw)
        except Exception:
            months = 1
        store = self.bot.ensure_storage()
        info = await store.set_user_plan(update.effective_user.id, plan_code, months)
        status = self.bot._plan_label(info)
        await update.message.reply_text(f"План активирован: {status}")

    async def handle_transfer_command(
        self,
        message: Message,
        user,
        args: list[str],
        prefix: str,
        chat_id: int,
        store,
        currency: dict,
        plan_code: str,
        context: ContextTypes.DEFAULT_TYPE,
        *,
        reply,
    ) -> bool:
        explicit_username = self.bot.pick_username_argument(args)
        target = await self.bot.resolve_target_from_message(
            message, store, context, explicit_username, use_reply=not explicit_username
        )
        if not target or len(args) < 1:
            await reply(f"Используй {prefix}перевод @user amount")
            return True
        if getattr(user, "is_bot", False) or self.bot.is_bot_username(user.username or ""):
            await reply("Боты не участвуют в экономике.")
            return True
        amount_value, is_all = self.bot.parse_amount_token(args[-1])
        if amount_value is None and not is_all:
            await reply(
                f"Сумма должна быть от {self.bot.MIN_TRANSACTION} до {self.bot.MAX_TRANSACTION} или all."
            )
            return True
        uid, uname = target
        if self.bot.is_bot_username(uname):
            await reply("У ботов нет душ.")
            return True
        if uid == user.id:
            await reply("Перевод самому себе не имеет смысла.")
            return True
        limits = await store.get_limits(chat_id, user.id)
        transfer_cap = self.bot._plan_limits(plan_code).get("transfer")
        if transfer_cap and limits.get("transfer", 0) + amount_value > transfer_cap:
            await reply("Достигнут максимальный лимит на переводы")
            return True
        sender_balance = await store.get_balance(chat_id, user.id)
        if is_all:
            amount_value = min(sender_balance, self.bot.MAX_TRANSACTION)
        if amount_value <= 0:
            await reply("Недостаточно средств для перевода.")
            return True
        day_val = int(time.time() // 86400)
        idem_key = f"transfer:{chat_id}:{message.message_id}:{user.id}:{uid}:{amount_value}"
        try:
            result = await store.transfer_balance(
                chat_id=chat_id,
                sender_id=user.id,
                sender_username=user.username or user.full_name,
                receiver_id=uid,
                receiver_username=uname,
                amount=amount_value,
                idempotency_key=idem_key,
                day=day_val,
                metadata={"message_id": message.message_id},
            )
        except ValueError:
            await reply("Недостаточно средств для перевода.")
            return True
        if result is None:
            await reply("Перевод уже обработан.")
            return True
        sender_balance, new_balance = result
        await store.log_event(
            chat_id,
            (
                "Пользователь "
                f"{self.bot.log_handle(user)} перевёл {format_currency(amount_value, currency)} "
                f"пользователю {self.bot.log_handle(username=uname)}"
            ),
        )
        await self.bot._bump_rating(chat_id, user.id, 0.05)
        try:
            await self.bot._bump_rating(chat_id, uid, 0.02)
        except Exception:
            pass
        await reply(
            (
                f"Перевод выполнен: {format_currency(amount_value, currency)} для "
                f"{self.bot.mention_id(uid, uname, notify=False)}. "
                f"Ваш баланс: {format_currency(sender_balance, currency)}. "
                f"Баланс получателя: {format_currency(new_balance, currency)}"
            )
        )
        return True
