from typing import Iterable


class PermissionError(Exception):
    pass


def is_allowed(user_id: int, permissions: dict, *, allow_admin: bool = False, admins: Iterable[int] = ()) -> bool:
    """Return True only for экономические администраторы.

    Параметры allow_admin/admins оставлены для совместимости, но групповые
    администраторы больше не дают прав: доступ есть только у economy_admins.
    """

    uid = int(user_id)
    return uid in set(permissions.get("economy_admins", []))


def can_credit(user_id: int, permissions: dict, *, admins: Iterable[int] = ()) -> bool:
    uid = int(user_id)
    if is_allowed(uid, permissions, allow_admin=True, admins=admins):
        return True
    return uid in set(permissions.get("allow_credit", []))


def can_debit(user_id: int, permissions: dict, *, admins: Iterable[int] = ()) -> bool:
    uid = int(user_id)
    if is_allowed(uid, permissions, allow_admin=True, admins=admins):
        return True
    return uid in set(permissions.get("allow_debit", []))
