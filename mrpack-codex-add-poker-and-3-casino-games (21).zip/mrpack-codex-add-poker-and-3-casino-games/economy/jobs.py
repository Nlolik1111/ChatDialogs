"""Job system handling work assignments and payouts."""
import random
import time
from decimal import Decimal, ROUND_HALF_UP
from typing import Any, Dict, List, Optional, Tuple

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.constants import ParseMode

from economy.formatters import format_currency as _format_currency

QUESTIONS = [
    {
        "prompt": "Что ближе по типу задач?",
        "options": [
            ("Писать код и чинить баги", "tech", 2),
            ("Крутить цифры и отчёты", "analytics", 2),
            ("Придумывать тексты и креатив", "creative", 2),
            ("Договариваться и продавать", "sales", 2),
        ],
    },
    {
        "prompt": "Как вы предпочитаете работать?",
        "options": [
            ("В команде, общаясь много", "communication", 2),
            ("С цифрами и формулами", "finance", 2),
            ("С техникой и железом", "tech", 2),
            ("Управляя процессами", "management", 2),
        ],
    },
    {
        "prompt": "Что вам проще всего давалось в учёбе?",
        "options": [
            ("Математика и статистика", "analytics", 2),
            ("Литература и тексты", "creative", 2),
            ("Физика, информатика", "tech", 2),
            ("Презентации и выступления", "communication", 2),
        ],
    },
    {
        "prompt": "Какой результат мотивирует сильнее?",
        "options": [
            ("Закрытая сделка", "sales", 2),
            ("Запущенный продукт", "product", 2),
            ("Отлаженный процесс", "management", 2),
            ("Спасибо от клиента", "support", 2),
        ],
    },
    {
        "prompt": "Как проводите свободное время?",
        "options": [
            ("Собираю гаджеты, пробую новое ПО", "tech", 2),
            ("Читаю про бизнес и деньги", "finance", 2),
            ("Делаю видео, пишу посты", "creative", 2),
            ("Учусь новым навыкам и делюсь ими", "teaching", 2),
        ],
    },
    {
        "prompt": "Как реагируете на конфликтную ситуацию?",
        "options": [
            ("Разбираю факты и цифры", "analytics", 2),
            ("Ищу компромисс в диалоге", "support", 2),
            ("Действую жёстко и быстро", "risk", 2),
            ("Перевожу в конструктив", "communication", 2),
        ],
    },
    {
        "prompt": "Что ближе к вашим целям?",
        "options": [
            ("Стать экспертом и обучать", "teaching", 2),
            ("Руководить командой", "management", 2),
            ("Делать продукты и сервисы", "product", 2),
            ("Поддерживать пользователей", "support", 2),
        ],
    },
    {
        "prompt": "Какой риск приемлем?",
        "options": [
            ("Эксперимент ради роста", "product", 2),
            ("Осознанный риск ради прибыли", "finance", 2),
            ("Минимальный риск, чёткие процессы", "management", 2),
            ("Без риска, стабильность", "support", 2),
        ],
    },
    {
        "prompt": "Что важнее в работе?",
        "options": [
            ("Стабильный доход", "finance", 2),
            ("Творческая свобода", "creative", 2),
            ("Рост и сложные задачи", "tech", 2),
            ("Командное признание", "communication", 2),
        ],
    },
    {
        "prompt": "Какая роль в проекте комфортнее?",
        "options": [
            ("Архитектить и проектировать", "product", 2),
            ("Вести переговоры и продажи", "sales", 2),
            ("Контролировать сроки и ресурсы", "management", 2),
            ("Наставлять и поддерживать", "teaching", 2),
        ],
    },
    {
        "prompt": "Как относитесь к работе с данными?",
        "options": [
            ("Люблю глубоко копать в цифрах", "analytics", 2),
            ("Использую данные для решений", "product", 2),
            ("Смотрю метрики, но не углубляюсь", "management", 1),
            ("Предпочитаю людей, а не таблицы", "communication", 1),
        ],
    },
    {
        "prompt": "Что вам проще организовать?",
        "options": [
            ("Расклад задач и дедлайны", "management", 2),
            ("Автоматизацию и тесты", "tech", 2),
            ("Сценарии продаж", "sales", 2),
            ("Базу знаний и обучение", "teaching", 2),
        ],
    },
    {
        "prompt": "Какие сообщения пишете охотнее?",
        "options": [
            ("Статейные, блоги, посты", "creative", 2),
            ("Отчёты и сводки", "analytics", 2),
            ("Продающие тексты", "sales", 2),
            ("Памятки и инструкции", "support", 2),
        ],
    },
    {
        "prompt": "Где ощущаете себя уверенно?",
        "options": [
            ("Перед аудиторией", "communication", 2),
            ("За клавиатурой и IDE", "tech", 2),
            ("В Excel и BI", "analytics", 2),
            ("В роли наставника", "teaching", 2),
        ],
    },
    {
        "prompt": "Как реагируете на баг или инцидент?",
        "options": [
            ("Разбираю логи и фиксю", "tech", 2),
            ("Ставлю задачу и контролирую", "management", 2),
            ("Успокаиваю клиента", "support", 2),
            ("Ищу, как предотвратить в будущем", "product", 2),
        ],
    },
    {
        "prompt": "К чему больше тянет?",
        "options": [
            ("Собирать требования и брифы", "product", 2),
            ("Настраивать рекламные кампании", "creative", 2),
            ("Оптимизировать воронку продаж", "sales", 2),
            ("Делать аналитику и отчёты", "analytics", 2),
        ],
    },
    {
        "prompt": "Какое окружение подходит?",
        "options": [
            ("Громкая и активная команда", "communication", 2),
            ("Спокойный кабинет и код", "tech", 2),
            ("Полевая работа с клиентами", "sales", 2),
            ("Учебный класс или вебинар", "teaching", 2),
        ],
    },
    {
        "prompt": "Какую задачу возьмёте первой?",
        "options": [
            ("Настроить отчёт и цифры", "analytics", 2),
            ("Написать рекламный текст", "creative", 2),
            ("Разобрать баг и починить", "tech", 2),
            ("Позвонить клиенту", "sales", 2),
        ],
    },
    {
        "prompt": "Как воспринимаете дедлайны?",
        "options": [
            ("Строго планирую задачи", "management", 2),
            ("Делаю заранее, чтобы успеть", "analytics", 2),
            ("Гибко, если нужно творить", "creative", 2),
            ("Придерживаюсь, но важнее качество", "product", 2),
        ],
    },
    {
        "prompt": "Что хочется улучшать?",
        "options": [
            ("Продукт и пользовательский опыт", "product", 2),
            ("Обслуживание и помощь людям", "support", 2),
            ("Техническую надёжность", "tech", 2),
            ("Показатели продаж", "sales", 2),
        ],
    },
]

JOBS: List[Dict[str, Any]] = [
    {"code": "dev", "name": "Разработчик", "salary": 200, "tag": "tech"},
    {"code": "analyst", "name": "Аналитик", "salary": 180, "tag": "analytics"},
    {"code": "sales", "name": "Менеджер продаж", "salary": 140, "tag": "sales"},
    {"code": "support", "name": "Саппорт", "salary": 110, "tag": "support"},
    {"code": "pm", "name": "Проджект-менеджер", "salary": 190, "tag": "management"},
    {"code": "marketing", "name": "Маркетолог", "salary": 150, "tag": "creative"},
    {"code": "writer", "name": "Копирайтер", "salary": 90, "tag": "creative"},
    {"code": "qa", "name": "Тестировщик", "salary": 130, "tag": "tech"},
    {"code": "teacher", "name": "Ментор", "salary": 160, "tag": "teaching"},
    {"code": "fin", "name": "Финансист", "salary": 170, "tag": "finance"},
]

UPGRADES: List[Dict[str, Any]] = [
    {"code": "rate_s", "label": "Репутация (+0.2): 300", "cost": 300, "rating_delta": 0.2},
    {"code": "rate_l", "label": "Репутация (+0.5): 900", "cost": 900, "rating_delta": 0.5},
    {"code": "job_s", "label": "Профнавык (+0.3): 700", "cost": 700, "job_delta": 0.3},
    {"code": "job_l", "label": "Профнавык (+0.7): 2100", "cost": 2100, "job_delta": 0.7},
    {"code": "salary_s", "label": "Сертификация (+15% оклада): 2500", "cost": 2500, "salary_mult": 1.15},
    {"code": "salary_l", "label": "Executive-курс (+30% оклада): 6000", "cost": 6000, "salary_mult": 1.30},
]

FAIL_PHRASES = [
    "Вы конкретно облажались и начальник недоволен. Зарплата не получена.",
    "Отчёт сорван, премия мимо, зарплата не начислена.",
    "Дедлайны сгорели, дохода нет.",
    "Вы опоздали на работу => начальнику это не понравилось."
]

SUCCESS_PHRASES = [
    "Вы отлично справились со своей работой и получили {amount}.",
    "Проект сдан вовремя, зарплата {amount} начислена!",
    "Начальник доволен, получайте {amount}.",
    "Вы пришли на работу за 2 часа до смены. Начальник выписал премию"
]


class JobSystem:
    def __init__(self, bot: Any) -> None:
        self.bot = bot
        self.pending_tests: Dict[Tuple[int, int], Dict[str, Any]] = {}
        self.pending_work_buttons: Dict[int, Tuple[int, int]] = {}

    @staticmethod
    def _format_currency(amount: int | float, currency: Dict[str, Any]) -> str:
        if amount is None:
            amount = 0
        try:
            normalized = int(round(float(amount)))
        except (TypeError, ValueError):
            normalized = 0
        return _format_currency(normalized, currency)

    def _job_for_tag(self, tag: str) -> Dict[str, Any]:
        for job in JOBS:
            if job["tag"] == tag:
                return job
        return random.choice(JOBS)

    def _rating_to_stars(self, rating: float, *, max_stars: int) -> str:
        capped = max(0.0, min(float(max_stars), rating))
        stars = int(round((capped / max_stars) * max_stars))
        return "⭐" * stars if stars else "-"

    def overall_stars(self, rating: float) -> str:
        return self._rating_to_stars(rating, max_stars=10)

    def job_stars(self, rating: float) -> str:
        return self._rating_to_stars(rating, max_stars=20)

    def _question_text(self, idx: int) -> str:
        question = QUESTIONS[idx]
        prompt = question["prompt"]
        options = "\n".join([f"{i+1}) {opt[0]}" for i, opt in enumerate(question["options"])])
        return f"<b>{idx+1}/20.</b> {prompt}\n\nВыберите вариант ответа:\n{options}"

    def _question_keyboard(self, chat_id: int, user_id: int, idx: int) -> InlineKeyboardMarkup:
        question = QUESTIONS[idx]
        buttons = [
            [
                InlineKeyboardButton(
                    label,
                    callback_data=f"job:testans:{chat_id}:{user_id}:{idx}:{i}",
                )
            ]
            for i, (label, _tag, _score) in enumerate(question["options"])
        ]
        return InlineKeyboardMarkup(buttons)

    def _apply_answer(self, state: Dict[str, Any], idx: int, option_index: int) -> None:
        question = QUESTIONS[idx]
        options = question["options"]
        if 0 <= option_index < len(options):
            _label, tag, score = options[option_index]
            if score > 0:
                state.setdefault("answers", {})[tag] = state.get("answers", {}).get(tag, 0) + score

    async def handle_test_answer_callback(
        self, query, chat_id: int, user_id: int, idx: int, option_index: int
    ) -> bool:
        # Разрешаем отвечать только инициатору теста
        if query.from_user and query.from_user.id != user_id:
            await query.answer("Это не ваш тест", show_alert=True)
            return False
        key = (chat_id, user_id)
        state = self.pending_tests.get(key)
        if not state or state.get("index") != idx:
            await query.answer("Вопрос устарел, начни тест заново", show_alert=True)
            return False
        self._apply_answer(state, idx, option_index)
        idx += 1
        if idx >= len(QUESTIONS):
            best_tag = max(state.get("answers", {"default": 0}).items(), key=lambda kv: kv[1])[0]
            job = self._job_for_tag(best_tag)
            await self.bot.storage.set_job(
                chat_id,
                user_id,
                job_code=job["code"],
                job_name=job["name"],
                base_salary=job["salary"],
            )
            try:
                await self.bot.storage.update_job_rating(chat_id, user_id, delta=0.15)
                await self.bot._bump_rating(chat_id, user_id, 0.1)
            except Exception:
                pass
            self.pending_tests.pop(key, None)
            await query.edit_message_text(
                f"<b>Тест завершён.</b> Вы назначены на должность<b>{job['name']}</b> с зарплатой {job['salary']}",
                parse_mode=ParseMode.HTML,
            )
            return True
        state["index"] = idx
        text = self._question_text(idx)
        kb = self._question_keyboard(chat_id, user_id, idx)
        await query.edit_message_text(text, reply_markup=kb, parse_mode=ParseMode.HTML)
        state["message_id"] = query.message.message_id if query.message else state.get("message_id")
        return True

    async def handle_test_reply(self, update: Update, context) -> bool:
        message = update.effective_message
        if not message or not message.reply_to_message:
            return False
        key = (message.chat_id, message.from_user.id)
        state = self.pending_tests.get(key)
        if not state:
            return False
        if message.reply_to_message.message_id != state.get("message_id"):
            return False
        idx = state.get("index", 0)
        answer_text = (message.text or "").strip().lower()
        question = QUESTIONS[idx]
        vote_map = {str(i + 1): i for i in range(len(question["options"]))}
        option_index = vote_map.get(answer_text, -1)
        if option_index >= 0:
            self._apply_answer(state, idx, option_index)
        idx += 1
        if idx >= len(QUESTIONS):
            # pick best tag
            answers = state.get("answers", {"default": 0})
            best_tag = max(answers.items(), key=lambda kv: kv[1])[0]
            job = self._job_for_tag(best_tag)
            await self.bot.storage.set_job(message.chat_id, message.from_user.id, job_code=job["code"], job_name=job["name"], base_salary=job["salary"])
            try:
                await self.bot.storage.update_job_rating(message.chat_id, message.from_user.id, delta=0.15)
                await self.bot._bump_rating(message.chat_id, message.from_user.id, 0.1)
            except Exception:
                pass
            self.pending_tests.pop(key, None)
            await message.reply_text(
                f"<b>Тест завершён.</b> Вы назначены на должность <b>{job['name']}</b> с зарплатой {job['salary']}",
                parse_mode=ParseMode.HTML,
            )
            return True
        text = self._question_text(idx)
        sent = await message.reply_text(
            text,
            reply_markup=self._question_keyboard(message.chat_id, message.from_user.id, idx),
            parse_mode=ParseMode.HTML,
        )
        state["index"] = idx
        state["message_id"] = sent.message_id
        return True

    async def start_test(self, chat_id: int, user_id: int, message, *, use_edit: bool = False) -> None:
        text = self._question_text(0)
        kb = self._question_keyboard(chat_id, user_id, 0)
        if use_edit:
            sent = await message.edit_text(text, reply_markup=kb, parse_mode=ParseMode.HTML)
            msg_id = message.message_id
        else:
            sent = await message.reply_text(text, reply_markup=kb, parse_mode=ParseMode.HTML)
            msg_id = sent.message_id
        self.pending_tests[(chat_id, user_id)] = {"index": 0, "answers": {}, "message_id": msg_id}

    def _salary_with_rating(self, base_salary: int, rating: float, job_rating: float) -> int:
        salary = int(base_salary or 0)
        if salary < 1:
            salary = 1
        rating_bonus_units = (
            Decimal(str(max(0.0, float(rating)))) * Decimal("5")
        ).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
        job_bonus_units = (
            Decimal(str(max(0.0, float(job_rating)))) * Decimal("0.5")
        ).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
        boosted = Decimal(str(salary)) + rating_bonus_units + job_bonus_units
        return max(1, int(boosted))

    def upgrade_keyboard(self, chat_id: int, user_id: int) -> InlineKeyboardMarkup:
        buttons = [
            [InlineKeyboardButton(opt["label"], callback_data=f"job:uprate:{chat_id}:{user_id}:{opt['code']}")]
            for opt in UPGRADES
        ]
        buttons.append([InlineKeyboardButton("Назад", callback_data=f"job:open:{chat_id}:{user_id}")])
        return InlineKeyboardMarkup(buttons)

    async def apply_shop_upgrade(self, chat_id: int, user_id: int, item: Dict[str, Any], currency: Dict[str, Any]) -> None:
        store = self.bot.storage
        job = await store.get_job(chat_id, user_id)
        delta_rating = item.get("rating_delta", 0.0)
        delta_job = item.get("job_delta") if "job_delta" in item else delta_rating
        if delta_rating or delta_job:
            await store.update_job_rating(chat_id, user_id, delta=delta_rating, delta_job=delta_job)
        salary_mult = item.get("salary_mult")
        if salary_mult and job.get("job_code") and job.get("job_name"):
            new_base = int(
                (Decimal(str(job.get("base_salary", 0))) * Decimal(str(salary_mult))).quantize(
                    Decimal("1"), rounding=ROUND_HALF_UP
                )
            )
            await store.set_job(
                chat_id,
                user_id,
                job_code=job.get("job_code"),
                job_name=job.get("job_name"),
                base_salary=new_base,
            )
        await store.log_event(
            chat_id,
            f"{self.bot.log_handle(user_id=user_id)} купил '{item.get('name')}'",
        )

    async def apply_upgrade(self, chat_id: int, user_id: int, option_code: str, *, currency: Dict[str, Any]) -> tuple[bool, str, InlineKeyboardMarkup]:
        store = self.bot.storage
        job = await store.get_job(chat_id, user_id)
        option = next((o for o in UPGRADES if o["code"] == option_code), None)
        if not option:
            return False, "Неизвестное улучшение", self.upgrade_keyboard(chat_id, user_id)

        cost = int(option.get("cost", 0))
        min_tx = getattr(self.bot, "MIN_TRANSACTION", getattr(self.bot, "min_transaction", 50))
        max_tx = getattr(self.bot, "MAX_TRANSACTION", getattr(self.bot, "max_transaction", 100_000_000))
        if cost < min_tx or cost > max_tx:
            return False, "Цена вне допустимого диапазона", self.upgrade_keyboard(chat_id, user_id)

        new_balance = await store.adjust_balance(chat_id, user_id, None, -cost)
        if new_balance is None:
            return False, "Недостаточно средств", self.upgrade_keyboard(chat_id, user_id)

        delta_rating = option.get("rating_delta", 0.0)
        delta_job = option.get("job_delta") if "job_delta" in option else delta_rating
        if delta_rating or delta_job:
            await store.update_job_rating(chat_id, user_id, delta=delta_rating, delta_job=delta_job)

        salary_mult = option.get("salary_mult")
        if salary_mult and job.get("job_code") and job.get("job_name"):
            new_base = int(
                (Decimal(str(job.get("base_salary", 0))) * Decimal(str(salary_mult))).quantize(
                    Decimal("1"), rounding=ROUND_HALF_UP
                )
            )
            await store.set_job(
                chat_id,
                user_id,
                job_code=job.get("job_code"),
                job_name=job.get("job_name"),
                base_salary=new_base,
            )

        await store.log_event(
            chat_id,
            f"{self.bot.log_handle(user_id=user_id)} купил прокачку '{option.get('label')}' за {self._format_currency(cost, currency)}",
        )

        success_text = (
            f"Улучшение <b>{option.get('label')}</b> куплено. Списано {self._format_currency(cost, currency)}."
        )
        return True, success_text, InlineKeyboardMarkup([[InlineKeyboardButton("Назад", callback_data=f"job:open:{chat_id}:{user_id}")]])

    async def handle_work_command(self, update: Update, context, *, currency: Dict[str, Any], perms: Dict) -> None:
        message = update.effective_message
        user = update.effective_user
        chat_id = message.chat_id
        if user and user.is_bot:
            await message.reply_text("Боты не участвуют в экономике.", parse_mode=ParseMode.HTML)
            return
        store = self.bot.ensure_storage()
        job = await store.get_job(chat_id, user.id)
        if not job.get("job_name"):
            await message.reply_text(
                "<b>У тебя нет работы.</b> Пройди тест из 20 вопросов, отвечая на кнопки ниже.",
                reply_markup=InlineKeyboardMarkup(
                    [[InlineKeyboardButton("Пройти тест", callback_data=f"job:teststart:{chat_id}:{user.id}")]]
                ),
                parse_mode=ParseMode.HTML,
            )
            return
        now = time.time()
        if job.get("job_blocked_until", 0) > now and not self.bot.ensure_creator(update):
            remaining = int(job["job_blocked_until"] - now)
            hrs = remaining // 3600
            mins = (remaining % 3600) // 60
            await message.reply_text(
                f"Смена недоступна. Подожди {hrs}ч {mins}м из-за частых увольнений.",
                parse_mode=ParseMode.HTML,
            )
            return
        now = time.time()
        if not self.bot.test_mode and job.get("last_work") and now - job.get("last_work") < 3 * 3600:
            instant_remaining = await store.instant_work_remaining(chat_id, user.id)
            if instant_remaining > 0:
                await store.clear_cooldown(f"instant_work:{chat_id}:{user.id}")
            else:
                remaining = int(3 * 3600 - (now - job.get("last_work")))
                hours = remaining // 3600
                minutes = (remaining % 3600) // 60
                await message.reply_text(
                    f"Подожди {hours}ч {minutes}м перед следующей сменой.",
                    parse_mode=ParseMode.HTML,
                )
                return
        now = time.time()
        # success/fail
        payout_chance = random.random()
        is_creator = (user.username or "").lower() == self.bot.settings.creator_username if user else False
        success = payout_chance < (0.6 if is_creator else 0.5)
        salary = self._salary_with_rating(job.get("base_salary", 0), job.get("rating", 0.0), job.get("job_rating", 0.0))
        tax_rate = max(0, min(10000, int(currency.get("tax_rate", 500))))
        if await store.tax_holiday_remaining(chat_id) > 0:
            tax_rate = 0
        tax_amount = salary * tax_rate // 10000 if success else 0
        net = salary - tax_amount if success else 0
        await store.update_job_stats(chat_id, user.id, success=success, payout=net, tax_amount=tax_amount)
        if success:
            phrase = random.choice(SUCCESS_PHRASES).format(amount=self._format_currency(net, currency))
            try:
                await self.bot._bump_rating(chat_id, user.id, 0.08)
            except Exception:
                pass
        else:
            phrase = random.choice(FAIL_PHRASES)
        await message.reply_text(phrase, parse_mode=ParseMode.HTML)

    async def work_info(self, chat_id: int, target_id: int, *, currency: Dict[str, Any]) -> str:
        job = await self.bot.storage.get_job(chat_id, target_id)
        name = job.get("job_name") or "Безработный"
        rating = job.get("rating", 0.0)
        job_rating = job.get("job_rating", 0.0)
        salary = self._salary_with_rating(job.get("base_salary", 0), rating, job_rating)
        return (
            f"<b>Работа:</b> {name}\n"
            f"Зарплата: {self._format_currency(salary, currency)}\n"
            f"Отработано удачно: {job.get('successes', 0)}, неудач: {job.get('failures', 0)}\n"
            f"Рабочий рейтинг: {self.job_stars(job_rating)} ({job_rating:.1f})"
        )

    async def adjust_inactivity(self, chat_id: int, user_id: int) -> None:
        job = await self.bot.storage.get_job(chat_id, user_id)
        last = job.get("last_work", 0)
        if last and time.time() - last > 3 * 24 * 3600:
            await self.bot.storage.update_job_rating(chat_id, user_id, delta=-0.3)
