import os
from dataclasses import dataclass
from pathlib import Path


def load_env_file(path: str) -> None:
    """Load environment variables from a ``.env``-style file if it exists."""

    env_path = Path(path)
    if not env_path.exists():
        return

    for line in env_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip())


# Загружаем .env из корня проекта (или путь из переменной ENV_PATH), чтобы конфиг
# вел себя как в пользовательском примере на Windows.
load_env_file(os.getenv("ENV_PATH", str(Path(__file__).resolve().parent.parent / ".env")))


@dataclass
class BotSettings:
    token: str
    creator_username: str
    db_host: str
    db_port: int
    db_user: str
    db_password: str
    db_name: str
    plan_medium_stars: int
    plan_ultimate_stars: int
    plan_medium_rub: int
    plan_ultimate_rub: int
    card_number: str
    card_payee: str
    stars_provider_token: str
    creator_id: int | None
    news_channel_id: int
    news_channel_link: str = ""
    test_mode: bool = False


def load_settings() -> BotSettings:
    token = os.getenv("BOT_TOKEN", "")
    creator_username = os.getenv("CREATOR_USERNAME", "")
    db_name = os.getenv("DB_NAME") or os.getenv("ECONOMY_DB") or "economy"

    return BotSettings(
        token=token,
        creator_username=creator_username.lower(),
        db_host=os.getenv("DB_HOST", "localhost"),
        db_port=int(os.getenv("DB_PORT", "3306")),
        db_user=os.getenv("DB_USER", "root"),
        db_password=os.getenv("DB_PASSWORD", ""),
        db_name=db_name,
        plan_medium_stars=int(os.getenv("PLAN_MEDIUM_STARS", "10")),
        plan_ultimate_stars=int(os.getenv("PLAN_ULTIMATE_STARS", "20")),
        plan_medium_rub=int(os.getenv("PLAN_MEDIUM_RUB", "200")),
        plan_ultimate_rub=int(os.getenv("PLAN_ULTIMATE_RUB", "400")),
        card_number=os.getenv("CARD_NUMBER", "0000 0000 0000 0000"),
        card_payee=os.getenv("CARD_PAYEE", "Иванов И.И."),
        stars_provider_token=os.getenv("STARS_PROVIDER_TOKEN", ""),
        creator_id=int(os.getenv("CREATOR_ID", "1116636564")),
        news_channel_id=int(os.getenv("NEWS_CHANNEL_ID", "0")),
        news_channel_link=os.getenv("NEWS_CHANNEL_LINK", "").strip(),
        test_mode=os.getenv("TEST_MODE", "false").lower() in {"1", "true", "yes", "on"},
    )
