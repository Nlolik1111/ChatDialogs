import asyncio
import json
import logging
import random
import time
from typing import Any, Dict, Iterable, Optional, Tuple

import aiomysql

logger = logging.getLogger(__name__)

DEFAULT_CURRENCY = {
    "name": "тублик",
    "icon": "🪙",
    "rate": 1,
    "shop_type": "fixed",
    "auto_declension": True,
    "cases": {"one": "тублик", "few": "тублика", "many": "тубликов"},
    "daily_reward": 10000,
    "tax_rate": 500,
    "blocked": False,
    "treasury": 0,
    "free_mode": False,
}

DEFAULT_PREFIXES = ("!!",)

PLAN_BASIC = "basic"
PLAN_MEDIUM = "medium"
PLAN_ULTIMATE = "ultimate"

# Job defaults
DEFAULT_JOB = {
    "job_code": None,
    "job_name": None,
    "base_salary": 0,
    "successes": 0,
    "failures": 0,
    "rating": 0.0,
    "job_rating": 0.0,
    "last_work": 0,
    "work_balance": 0,
    "quit_count": 0,
    "quit_window": 0,
    "job_blocked_until": 0,
}


class MySQLEconomyStorage:
    """Async storage layer for chat economy data based on MySQL."""

    def __init__(self, pool: aiomysql.Pool) -> None:
        self.pool = pool

    @classmethod
    async def create(
        cls,
        *,
        host: str,
        port: int,
        user: str,
        password: str,
        db: str,
    ) -> "MySQLEconomyStorage":
        pool = await aiomysql.create_pool(
            host=host,
            port=port,
            user=user,
            password=password,
            db=db,
            autocommit=True,
            minsize=1,
            maxsize=5,
        )
        storage = cls(pool)
        await storage._create_tables()
        return storage

    async def close(self) -> None:
        self.pool.close()
        await self.pool.wait_closed()

    async def _create_tables(self) -> None:
        queries = [
            """
            CREATE TABLE IF NOT EXISTS chats (
                chat_id BIGINT PRIMARY KEY,
                currency_name VARCHAR(64) NOT NULL DEFAULT 'тублик',
                currency_icon VARCHAR(8) NOT NULL DEFAULT '🪙',
                rate BIGINT NOT NULL DEFAULT 1,
                shop_type VARCHAR(16) NOT NULL DEFAULT 'fixed',
                auto_declension BOOLEAN NOT NULL DEFAULT TRUE,
                case_one VARCHAR(64) NOT NULL DEFAULT 'тублик',
                case_few VARCHAR(64) NOT NULL DEFAULT 'тублика',
                case_many VARCHAR(64) NOT NULL DEFAULT 'тубликов',
                daily_reward BIGINT NOT NULL DEFAULT 10000,
                tax_rate BIGINT NOT NULL DEFAULT 500,
                blocked BOOLEAN NOT NULL DEFAULT FALSE,
                treasury BIGINT NOT NULL DEFAULT 0,
                free_mode BOOLEAN NOT NULL DEFAULT FALSE
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS chat_prefixes (
                chat_id BIGINT NOT NULL,
                prefix VARCHAR(32) NOT NULL,
                PRIMARY KEY (chat_id, prefix),
                CONSTRAINT fk_prefix_chat FOREIGN KEY (chat_id) REFERENCES chats(chat_id) ON DELETE CASCADE
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS balances (
                chat_id BIGINT NOT NULL,
                user_id BIGINT NOT NULL,
                username VARCHAR(255) DEFAULT NULL,
                balance BIGINT NOT NULL DEFAULT 0,
                PRIMARY KEY (chat_id, user_id)
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS chat_owners (
                chat_id BIGINT PRIMARY KEY,
                owner_id BIGINT NOT NULL,
                CONSTRAINT fk_owner_chat FOREIGN KEY (chat_id) REFERENCES chats(chat_id) ON DELETE CASCADE
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS permissions (
                chat_id BIGINT NOT NULL,
                user_id BIGINT NOT NULL,
                role ENUM('admin', 'credit', 'debit') NOT NULL,
                PRIMARY KEY (chat_id, user_id, role)
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS banned_users (
                chat_id BIGINT NOT NULL,
                user_id BIGINT NOT NULL,
                PRIMARY KEY (chat_id, user_id),
                CONSTRAINT fk_ban_chat FOREIGN KEY (chat_id) REFERENCES chats(chat_id) ON DELETE CASCADE
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS daily_claims (
                chat_id BIGINT NOT NULL,
                user_id BIGINT NOT NULL,
                last_claim BIGINT NOT NULL DEFAULT 0,
                PRIMARY KEY (chat_id, user_id)
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS shop_items (
                id BIGINT PRIMARY KEY AUTO_INCREMENT,
                chat_id BIGINT NOT NULL,
                title VARCHAR(255) NOT NULL,
                price BIGINT NOT NULL,
                author_id BIGINT NOT NULL,
                author_username VARCHAR(255),
                quantity BIGINT NOT NULL DEFAULT 0,
                INDEX idx_shop_items_chat (chat_id)
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS logs (
                id BIGINT PRIMARY KEY AUTO_INCREMENT,
                chat_id BIGINT NOT NULL,
                entry TEXT NOT NULL,
                created_at BIGINT NOT NULL
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS transactions (
                id BIGINT PRIMARY KEY AUTO_INCREMENT,
                chat_id BIGINT NOT NULL,
                operation_type VARCHAR(64) NOT NULL,
                amount BIGINT NOT NULL,
                from_user BIGINT,
                to_user BIGINT,
                metadata JSON,
                idempotency_key VARCHAR(128) NOT NULL,
                created_at BIGINT NOT NULL,
                UNIQUE KEY uniq_idempotency (idempotency_key),
                INDEX idx_transactions_from (from_user, created_at),
                INDEX idx_transactions_to (to_user, created_at)
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS processed_updates (
                update_id BIGINT PRIMARY KEY,
                processed_at BIGINT NOT NULL
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS cooldowns (
                cooldown_key VARCHAR(128) PRIMARY KEY,
                expires_at BIGINT NOT NULL,
                INDEX idx_cooldowns_expires (expires_at)
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS pending_transfers (
                user_id BIGINT PRIMARY KEY,
                plan_code VARCHAR(32) NOT NULL,
                amount BIGINT NOT NULL,
                file_id VARCHAR(255),
                method VARCHAR(32) NOT NULL,
                prompt_id BIGINT,
                expires_at BIGINT NOT NULL
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS pending_item_edits (
                prompt_id BIGINT PRIMARY KEY,
                chat_id BIGINT NOT NULL,
                item_index BIGINT NOT NULL,
                field VARCHAR(32) NOT NULL,
                owner_id BIGINT NOT NULL,
                expires_at BIGINT NOT NULL
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS nuke_shields (
                chat_id BIGINT NOT NULL,
                user_id BIGINT NOT NULL,
                expires_at BIGINT NOT NULL,
                PRIMARY KEY (chat_id, user_id),
                INDEX idx_nuke_shields_expires (expires_at)
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS bot_metrics (
                metric_key VARCHAR(128) PRIMARY KEY,
                value BIGINT NOT NULL DEFAULT 0
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS command_usage (
                stat_date DATE NOT NULL,
                chat_id BIGINT NOT NULL,
                user_id BIGINT NOT NULL,
                command_count BIGINT NOT NULL DEFAULT 0,
                last_ts BIGINT NOT NULL DEFAULT 0,
                PRIMARY KEY (stat_date, chat_id, user_id),
                INDEX idx_command_usage_last_ts (last_ts)
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS daily_metrics (
                metric_date DATE NOT NULL,
                metric_key VARCHAR(128) NOT NULL,
                value BIGINT NOT NULL DEFAULT 0,
                PRIMARY KEY (metric_date, metric_key)
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS schema_migrations (
                version VARCHAR(64) PRIMARY KEY,
                applied_at BIGINT NOT NULL
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS purchases (
                id BIGINT PRIMARY KEY AUTO_INCREMENT,
                chat_id BIGINT NOT NULL,
                buyer_id BIGINT NOT NULL,
                buyer_username VARCHAR(255),
                title VARCHAR(255) NOT NULL,
                price BIGINT NOT NULL,
                seller_username VARCHAR(255),
                seller_id BIGINT,
                item_code VARCHAR(128),
                consumed TINYINT NOT NULL DEFAULT 0,
                created_at BIGINT NOT NULL,
                INDEX idx_purchases_buyer (chat_id, buyer_id, created_at)
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS jobs (
                chat_id BIGINT NOT NULL,
                user_id BIGINT NOT NULL,
                job_code VARCHAR(64),
                job_name VARCHAR(255),
                base_salary BIGINT NOT NULL DEFAULT 0,
                successes BIGINT NOT NULL DEFAULT 0,
                failures BIGINT NOT NULL DEFAULT 0,
                rating DOUBLE NOT NULL DEFAULT 0,
                job_rating DOUBLE NOT NULL DEFAULT 0,
                last_work BIGINT NOT NULL DEFAULT 0,
                work_balance BIGINT NOT NULL DEFAULT 0,
                quit_count BIGINT NOT NULL DEFAULT 0,
                quit_window BIGINT NOT NULL DEFAULT 0,
                job_blocked_until BIGINT NOT NULL DEFAULT 0,
                PRIMARY KEY (chat_id, user_id)
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS user_plans (
                user_id BIGINT PRIMARY KEY,
                plan ENUM('basic','medium','ultimate') NOT NULL DEFAULT 'basic',
                expires_at BIGINT NOT NULL DEFAULT 0,
                remind_at BIGINT NOT NULL DEFAULT 0
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS promo_redemptions (
                user_id BIGINT NOT NULL,
                code VARCHAR(255) NOT NULL,
                redeemed_at BIGINT NOT NULL,
                PRIMARY KEY (user_id, code)
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS user_limits (
                chat_id BIGINT NOT NULL,
                user_id BIGINT NOT NULL,
                day BIGINT NOT NULL,
                transfer_total BIGINT NOT NULL DEFAULT 0,
                credit_total BIGINT NOT NULL DEFAULT 0,
                PRIMARY KEY (chat_id, user_id, day)
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS escripts (
                id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
                chat_id BIGINT NOT NULL,
                name VARCHAR(255) NOT NULL,
                filename VARCHAR(255) NOT NULL,
                author_id BIGINT NOT NULL,
                author_username VARCHAR(255) DEFAULT NULL,
                active BOOLEAN NOT NULL DEFAULT TRUE,
                errors INT NOT NULL DEFAULT 0,
                warnings INT NOT NULL DEFAULT 0,
                created_at BIGINT NOT NULL,
                updated_at BIGINT NOT NULL,
                last_compiled_at BIGINT NOT NULL,
                last_log_path VARCHAR(255) DEFAULT NULL,
                INDEX idx_escripts_chat (chat_id),
                CONSTRAINT fk_escripts_chat FOREIGN KEY (chat_id) REFERENCES chats(chat_id) ON DELETE CASCADE
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS escript_errors (
                id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
                chat_id BIGINT NOT NULL,
                script_id BIGINT NOT NULL,
                created_at BIGINT NOT NULL,
                message TEXT,
                INDEX idx_escript_errors_chat (chat_id),
                INDEX idx_escript_errors_script (script_id)
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS escript_runs (
                chat_id BIGINT NOT NULL,
                script_id BIGINT NOT NULL,
                event_key VARCHAR(64) NOT NULL,
                last_run BIGINT NOT NULL DEFAULT 0,
                PRIMARY KEY (chat_id, script_id, event_key)
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS escript_kv (
                chat_id BIGINT NOT NULL,
                script_id BIGINT NOT NULL,
                user_id BIGINT NOT NULL,
                kv_key VARCHAR(128) NOT NULL,
                kv_value TEXT,
                PRIMARY KEY (chat_id, script_id, user_id, kv_key)
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS escript_kv_global (
                chat_id BIGINT NOT NULL,
                script_id BIGINT NOT NULL,
                kv_key VARCHAR(128) NOT NULL,
                kv_value TEXT,
                PRIMARY KEY (chat_id, script_id, kv_key)
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS pending_escripts (
                prompt_id BIGINT NOT NULL PRIMARY KEY,
                chat_id BIGINT NOT NULL,
                user_id BIGINT NOT NULL,
                script_id BIGINT DEFAULT NULL,
                name VARCHAR(255) DEFAULT NULL,
                created_at BIGINT NOT NULL
            )
            """,
        ]
        async with self.pool.acquire() as conn:
            async with conn.cursor() as cur:
                for query in queries:
                    await cur.execute(query)
                await self._apply_migrations(cur)

    async def _apply_migrations(self, cur: aiomysql.Cursor) -> None:
        migrations = [
            (
                "2024-09-01-add-columns",
                [
                    "ALTER TABLE chats ADD COLUMN daily_reward BIGINT NOT NULL DEFAULT 10000",
                    "ALTER TABLE chats ADD COLUMN tax_rate BIGINT NOT NULL DEFAULT 500",
                    "ALTER TABLE chats ADD COLUMN blocked BOOLEAN NOT NULL DEFAULT FALSE",
                    "ALTER TABLE chats ADD COLUMN treasury BIGINT NOT NULL DEFAULT 0",
                    "ALTER TABLE shop_items ADD COLUMN quantity BIGINT NOT NULL DEFAULT 0",
                    "ALTER TABLE logs ADD COLUMN chat_id BIGINT NOT NULL",
                    "ALTER TABLE purchases ADD COLUMN seller_username VARCHAR(255)",
                    "ALTER TABLE purchases ADD COLUMN seller_id BIGINT",
                    "ALTER TABLE purchases ADD COLUMN item_code VARCHAR(128)",
                    "ALTER TABLE purchases ADD COLUMN consumed TINYINT NOT NULL DEFAULT 0",
                    "ALTER TABLE jobs ADD COLUMN job_code VARCHAR(64)",
                    "ALTER TABLE jobs ADD COLUMN job_name VARCHAR(255)",
                    "ALTER TABLE jobs ADD COLUMN base_salary BIGINT NOT NULL DEFAULT 0",
                    "ALTER TABLE jobs ADD COLUMN successes BIGINT NOT NULL DEFAULT 0",
                    "ALTER TABLE jobs ADD COLUMN failures BIGINT NOT NULL DEFAULT 0",
                    "ALTER TABLE jobs ADD COLUMN rating DOUBLE NOT NULL DEFAULT 0",
                    "ALTER TABLE jobs ADD COLUMN job_rating DOUBLE NOT NULL DEFAULT 0",
                    "ALTER TABLE jobs ADD COLUMN last_work BIGINT NOT NULL DEFAULT 0",
                    "ALTER TABLE jobs ADD COLUMN work_balance BIGINT NOT NULL DEFAULT 0",
                    "ALTER TABLE jobs ADD COLUMN quit_count BIGINT NOT NULL DEFAULT 0",
                    "ALTER TABLE jobs ADD COLUMN quit_window BIGINT NOT NULL DEFAULT 0",
                    "ALTER TABLE jobs ADD COLUMN job_blocked_until BIGINT NOT NULL DEFAULT 0",
                    "ALTER TABLE user_plans ADD COLUMN plan ENUM('basic','medium','ultimate') NOT NULL DEFAULT 'basic'",
                    "ALTER TABLE user_plans ADD COLUMN expires_at BIGINT NOT NULL DEFAULT 0",
                    "ALTER TABLE user_plans ADD COLUMN remind_at BIGINT NOT NULL DEFAULT 0",
                    "ALTER TABLE chats ADD COLUMN shop_type VARCHAR(16) NOT NULL DEFAULT 'fixed'",
                ],
            ),
            (
                "2024-09-02-money-cents",
                [
                    "UPDATE chats SET daily_reward = CAST(daily_reward * 100 AS SIGNED), tax_rate = CAST(tax_rate * 100 AS SIGNED), treasury = CAST(treasury * 100 AS SIGNED)",
                    "UPDATE balances SET balance = CAST(balance * 100 AS SIGNED)",
                    "UPDATE shop_items SET price = CAST(price * 100 AS SIGNED)",
                    "UPDATE purchases SET price = CAST(price * 100 AS SIGNED)",
                    "UPDATE jobs SET base_salary = CAST(base_salary * 100 AS SIGNED), work_balance = CAST(work_balance * 100 AS SIGNED)",
                    "UPDATE user_limits SET transfer_total = CAST(transfer_total * 100 AS SIGNED), credit_total = CAST(credit_total * 100 AS SIGNED)",
                    "ALTER TABLE chats MODIFY rate BIGINT NOT NULL DEFAULT 1",
                    "ALTER TABLE chats MODIFY daily_reward BIGINT NOT NULL DEFAULT 10000",
                    "ALTER TABLE chats MODIFY tax_rate BIGINT NOT NULL DEFAULT 500",
                    "ALTER TABLE chats MODIFY treasury BIGINT NOT NULL DEFAULT 0",
                    "ALTER TABLE balances MODIFY balance BIGINT NOT NULL DEFAULT 0",
                    "ALTER TABLE shop_items MODIFY price BIGINT NOT NULL",
                    "ALTER TABLE purchases MODIFY price BIGINT NOT NULL",
                    "ALTER TABLE jobs MODIFY base_salary BIGINT NOT NULL DEFAULT 0",
                    "ALTER TABLE jobs MODIFY work_balance BIGINT NOT NULL DEFAULT 0",
                    "ALTER TABLE user_limits MODIFY transfer_total BIGINT NOT NULL DEFAULT 0",
                    "ALTER TABLE user_limits MODIFY credit_total BIGINT NOT NULL DEFAULT 0",
                    "ALTER TABLE transactions MODIFY amount BIGINT NOT NULL",
                ],
            ),
            (
                "2024-09-03-free-mode",
                ["ALTER TABLE chats ADD COLUMN free_mode BOOLEAN NOT NULL DEFAULT FALSE"],
            ),
        ]
        await cur.execute("SELECT version FROM schema_migrations")
        applied = {row[0] for row in await cur.fetchall()}
        for version, queries in migrations:
            if version in applied:
                continue
            for query in queries:
                try:
                    await cur.execute(query)
                except Exception as exc:
                    msg = str(exc).lower()
                    if "duplicate" in msg or "exists" in msg or "already" in msg:
                        logger.info("Migration skipped (already applied): %s", query)
                        continue
                    logger.warning("Migration query failed: %s (%s)", query, exc)
                    raise
            await cur.execute(
                "INSERT INTO schema_migrations (version, applied_at) VALUES (%s, %s)",
                (version, int(time.time())),
            )

    async def _execute(self, query: str, params: Iterable = ()):  # type: ignore
        async with self.pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(query, params)
                if cur.description:
                    return await cur.fetchall()
        return ()

    async def _execute_write(self, query: str, params: Iterable = ()) -> int:  # type: ignore
        async with self.pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(query, params)
                return int(cur.rowcount)

    async def _in_transaction(self, handler):  # type: ignore
        for attempt in range(3):
            async with self.pool.acquire() as conn:
                try:
                    await conn.begin()
                    result = await handler(conn)
                    await conn.commit()
                    return result
                except Exception as exc:
                    await conn.rollback()
                    msg = str(exc).lower()
                    if "deadlock" in msg or "lock wait timeout" in msg:
                        await asyncio.sleep(0.2 * (attempt + 1))
                        continue
                    raise

    async def ensure_chat(self, chat_id: int) -> None:
        await self._execute(
            """
            INSERT INTO chats (chat_id)
            VALUES (%s) ON DUPLICATE KEY UPDATE chat_id = chat_id
            """,
            (chat_id,),
        )
        await self._execute(
            "INSERT IGNORE INTO chat_prefixes (chat_id, prefix) VALUES (%s, %s)", (chat_id, DEFAULT_PREFIXES[0])
        )

    async def register_users(self, chat_id: int, users: Iterable[Tuple[int, str]]) -> None:
        """Bulk upsert users into balances with zero balance to prime lookups."""

        users = tuple(users)
        if not users:
            return
        await self.ensure_chat(chat_id)
        values = ",".join(["(%s, %s, %s, 0)"] * len(users))
        flat_params: list = []
        for uid, username in users:
            flat_params.extend([chat_id, uid, username])

        query = (
            "INSERT INTO balances (chat_id, user_id, username, balance) "
            f"VALUES {values} AS new_val "
            "ON DUPLICATE KEY UPDATE balances.username = new_val.username"
        )
        await self._execute(query, flat_params)

    async def register_user(self, chat_id: int, user_id: int, username: str | None = None) -> None:
        """Upsert a single user into balances (lightweight helper)."""

        await self.register_users(chat_id, ((user_id, username or str(user_id)),))

    async def user_seen_anywhere(self, user_id: int) -> bool:
        rows = await self._execute("SELECT 1 FROM user_plans WHERE user_id=%s LIMIT 1", (user_id,))
        if rows:
            return True
        rows = await self._execute("SELECT 1 FROM balances WHERE user_id=%s LIMIT 1", (user_id,))
        return bool(rows)

    async def is_update_processed(self, update_id: int) -> bool:
        rows = await self._execute(
            "SELECT 1 FROM processed_updates WHERE update_id=%s LIMIT 1",
            (update_id,),
        )
        return bool(rows)

    async def mark_update_processed(self, update_id: int) -> None:
        await self._execute(
            "INSERT INTO processed_updates (update_id, processed_at) VALUES (%s, %s)",
            (update_id, int(time.time())),
        )

    async def record_metric(self, key: str, value: int = 1) -> None:
        await self._execute(
            """
            INSERT INTO bot_metrics (metric_key, value)
            VALUES (%s, %s) AS new_val
            ON DUPLICATE KEY UPDATE value = bot_metrics.value + new_val.value
            """,
            (key, value),
        )

    async def record_daily_metric(self, key: str, value: int = 1, *, date_key: str | None = None) -> None:
        date_key = date_key or time.strftime("%Y-%m-%d", time.gmtime())
        await self._execute(
            """
            INSERT INTO daily_metrics (metric_date, metric_key, value)
            VALUES (%s, %s, %s) AS new_val
            ON DUPLICATE KEY UPDATE value = daily_metrics.value + new_val.value
            """,
            (date_key, key, value),
        )

    async def set_daily_metric(self, key: str, value: int, *, date_key: str | None = None) -> None:
        date_key = date_key or time.strftime("%Y-%m-%d", time.gmtime())
        await self._execute(
            """
            INSERT INTO daily_metrics (metric_date, metric_key, value)
            VALUES (%s, %s, %s) AS new_val
            ON DUPLICATE KEY UPDATE value = new_val.value
            """,
            (date_key, key, value),
        )

    async def get_daily_metric(self, key: str, *, date_key: str | None = None) -> Optional[int]:
        date_key = date_key or time.strftime("%Y-%m-%d", time.gmtime())
        rows = await self._execute(
            "SELECT value FROM daily_metrics WHERE metric_date=%s AND metric_key=%s",
            (date_key, key),
        )
        if not rows:
            return None
        return int(rows[0][0])

    async def record_command_usage(
        self,
        chat_id: int,
        user_id: int | None,
        *,
        timestamp: int | None = None,
        date_key: str | None = None,
    ) -> None:
        ts = int(timestamp or time.time())
        date_key = date_key or time.strftime("%Y-%m-%d", time.gmtime(ts))
        await self._execute(
            """
            INSERT INTO command_usage (stat_date, chat_id, user_id, command_count, last_ts)
            VALUES (%s, %s, %s, 1, %s) AS new_val
            ON DUPLICATE KEY UPDATE
                command_count = command_usage.command_count + new_val.command_count,
                last_ts = GREATEST(command_usage.last_ts, VALUES(last_ts))
            """,
            (date_key, chat_id, user_id or 0, ts),
        )

    async def daily_command_totals(self, date_key: str) -> dict:
        rows = await self._execute(
            """
            SELECT
                COALESCE(SUM(command_count), 0) AS total,
                COALESCE(COUNT(DISTINCT user_id), 0) AS users,
                COALESCE(COUNT(DISTINCT chat_id), 0) AS chats
            FROM command_usage
            WHERE stat_date=%s
            """,
            (date_key,),
        )
        total, users, chats = rows[0] if rows else (0, 0, 0)
        return {"total": int(total or 0), "users": int(users or 0), "chats": int(chats or 0)}

    async def command_totals_since(self, since_ts: int) -> dict:
        rows = await self._execute(
            """
            SELECT
                COALESCE(SUM(command_count), 0) AS total,
                COALESCE(COUNT(DISTINCT user_id), 0) AS users,
                COALESCE(COUNT(DISTINCT chat_id), 0) AS chats
            FROM command_usage
            WHERE last_ts >= %s
            """,
            (since_ts,),
        )
        total, users, chats = rows[0] if rows else (0, 0, 0)
        return {"total": int(total or 0), "users": int(users or 0), "chats": int(chats or 0)}

    async def count_known_users(self) -> int:
        rows = await self._execute(
            """
            SELECT COUNT(*) FROM (
                SELECT DISTINCT user_id FROM balances
                UNION
                SELECT DISTINCT user_id FROM user_plans
            ) AS all_users
            """
        )
        return int(rows[0][0]) if rows else 0

    async def count_active_users_since(self, since_ts: int) -> int:
        rows = await self._execute(
            "SELECT COUNT(DISTINCT user_id) FROM command_usage WHERE last_ts >= %s",
            (since_ts,),
        )
        return int(rows[0][0]) if rows else 0

    async def count_chats(self) -> int:
        rows = await self._execute("SELECT COUNT(*) FROM chats")
        return int(rows[0][0]) if rows else 0

    async def count_premium_users(self) -> int:
        rows = await self._execute(
            "SELECT COUNT(*) FROM user_plans WHERE plan != %s",
            (PLAN_BASIC,),
        )
        return int(rows[0][0]) if rows else 0

    async def check_cooldown(self, key: str, ttl_seconds: int) -> bool:
        now = int(time.time())
        rows = await self._execute(
            "SELECT expires_at FROM cooldowns WHERE cooldown_key=%s",
            (key,),
        )
        if rows and int(rows[0][0]) > now:
            return True
        await self._execute(
            """
            INSERT INTO cooldowns (cooldown_key, expires_at)
            VALUES (%s, %s) AS new_val
            ON DUPLICATE KEY UPDATE expires_at = new_val.expires_at
            """,
            (key, now + ttl_seconds),
        )
        return False

    async def set_cooldown(self, key: str, ttl_seconds: int) -> None:
        now = int(time.time())
        await self._execute(
            """
            INSERT INTO cooldowns (cooldown_key, expires_at)
            VALUES (%s, %s) AS new_val
            ON DUPLICATE KEY UPDATE expires_at = new_val.expires_at
            """,
            (key, now + ttl_seconds),
        )

    async def clear_cooldown(self, key: str) -> None:
        await self._execute("DELETE FROM cooldowns WHERE cooldown_key=%s", (key,))

    async def clear_chat_cooldowns(self, chat_id: int) -> int:
        """Remove cooldowns tied to a specific chat."""
        return await self._execute(
            "DELETE FROM cooldowns WHERE cooldown_key LIKE %s", (f"%:{chat_id}%",)
        )

    async def cooldown_remaining(self, key: str) -> int:
        now = int(time.time())
        rows = await self._execute(
            "SELECT expires_at FROM cooldowns WHERE cooldown_key=%s",
            (key,),
        )
        if not rows:
            return 0
        expires_at = int(rows[0][0])
        if expires_at <= now:
            await self._execute("DELETE FROM cooldowns WHERE cooldown_key=%s", (key,))
            return 0
        return expires_at - now

    async def clear_cooldown(self, key: str) -> None:
        await self._execute("DELETE FROM cooldowns WHERE cooldown_key=%s", (key,))

    async def set_tax_holiday(self, chat_id: int, ttl_seconds: int) -> None:
        await self.set_cooldown(f"tax_holiday:{chat_id}", ttl_seconds)

    async def tax_holiday_remaining(self, chat_id: int) -> int:
        return await self.cooldown_remaining(f"tax_holiday:{chat_id}")

    async def set_luck_ticket(self, chat_id: int, user_id: int, ttl_seconds: int) -> None:
        await self.set_cooldown(f"luck_ticket:{chat_id}:{user_id}", ttl_seconds)

    async def luck_ticket_remaining(self, chat_id: int, user_id: int) -> int:
        return await self.cooldown_remaining(f"luck_ticket:{chat_id}:{user_id}")

    async def set_instant_work(self, chat_id: int, user_id: int, ttl_seconds: int) -> None:
        await self.set_cooldown(f"instant_work:{chat_id}:{user_id}", ttl_seconds)

    async def instant_work_remaining(self, chat_id: int, user_id: int) -> int:
        return await self.cooldown_remaining(f"instant_work:{chat_id}:{user_id}")

    async def set_pending_transfer(
        self,
        user_id: int,
        plan_code: str,
        amount: int,
        method: str,
        *,
        file_id: str | None = None,
        prompt_id: int | None = None,
        ttl_seconds: int = 600,
    ) -> None:
        expires_at = int(time.time()) + ttl_seconds
        await self._execute(
            """
            INSERT INTO pending_transfers (user_id, plan_code, amount, file_id, method, prompt_id, expires_at)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE
                plan_code=VALUES(plan_code),
                amount=VALUES(amount),
                file_id=VALUES(file_id),
                method=VALUES(method),
                prompt_id=VALUES(prompt_id),
                expires_at=VALUES(expires_at)
            """,
            (user_id, plan_code, amount, file_id, method, prompt_id, expires_at),
        )

    async def get_pending_transfer(self, user_id: int) -> Optional[Dict[str, Any]]:
        now = int(time.time())
        rows = await self._execute(
            """
            SELECT plan_code, amount, file_id, method, prompt_id, expires_at
            FROM pending_transfers
            WHERE user_id=%s
            """,
            (user_id,),
        )
        if not rows:
            return None
        plan_code, amount, file_id, method, prompt_id, expires_at = rows[0]
        if int(expires_at) <= now:
            await self._execute("DELETE FROM pending_transfers WHERE user_id=%s", (user_id,))
            return None
        return {
            "plan": str(plan_code),
            "amount": int(amount),
            "file_id": file_id,
            "method": method,
            "prompt_id": int(prompt_id) if prompt_id is not None else None,
        }

    async def clear_pending_transfer(self, user_id: int) -> None:
        await self._execute("DELETE FROM pending_transfers WHERE user_id=%s", (user_id,))

    async def set_pending_item_edit(
        self,
        *,
        prompt_id: int,
        chat_id: int,
        index: int,
        field: str,
        owner_id: int,
        ttl_seconds: int = 900,
    ) -> None:
        expires_at = int(time.time()) + ttl_seconds
        await self._execute(
            """
            INSERT INTO pending_item_edits (prompt_id, chat_id, item_index, field, owner_id, expires_at)
            VALUES (%s, %s, %s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE
                chat_id=VALUES(chat_id),
                item_index=VALUES(item_index),
                field=VALUES(field),
                owner_id=VALUES(owner_id),
                expires_at=VALUES(expires_at)
            """,
            (prompt_id, chat_id, index, field, owner_id, expires_at),
        )

    async def get_pending_item_edit(self, prompt_id: int) -> Optional[Dict[str, Any]]:
        now = int(time.time())
        rows = await self._execute(
            """
            SELECT chat_id, item_index, field, owner_id, expires_at
            FROM pending_item_edits
            WHERE prompt_id=%s
            """,
            (prompt_id,),
        )
        if not rows:
            return None
        chat_id, item_index, field, owner_id, expires_at = rows[0]
        if int(expires_at) <= now:
            await self._execute("DELETE FROM pending_item_edits WHERE prompt_id=%s", (prompt_id,))
            return None
        return {
            "chat_id": int(chat_id),
            "index": int(item_index),
            "field": str(field),
            "owner": int(owner_id),
        }

    async def clear_pending_item_edit(self, prompt_id: int) -> None:
        await self._execute("DELETE FROM pending_item_edits WHERE prompt_id=%s", (prompt_id,))

    async def set_pending_escript(
        self,
        *,
        prompt_id: int,
        chat_id: int,
        user_id: int,
        script_id: Optional[int] = None,
        name: Optional[str] = None,
    ) -> None:
        created_at = int(time.time())
        await self._execute(
            """
            INSERT INTO pending_escripts (prompt_id, chat_id, user_id, script_id, name, created_at)
            VALUES (%s, %s, %s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE chat_id=VALUES(chat_id), user_id=VALUES(user_id),
                script_id=VALUES(script_id), name=VALUES(name), created_at=VALUES(created_at)
            """,
            (prompt_id, chat_id, user_id, script_id, name, created_at),
        )

    async def get_pending_escript(self, prompt_id: int) -> Optional[Dict[str, Any]]:
        rows = await self._execute(
            "SELECT prompt_id, chat_id, user_id, script_id, name, created_at FROM pending_escripts WHERE prompt_id=%s",
            (prompt_id,),
        )
        if not rows:
            return None
        prompt_id, chat_id, user_id, script_id, name, created_at = rows[0]
        return {
            "prompt_id": int(prompt_id),
            "chat_id": int(chat_id),
            "user_id": int(user_id),
            "script_id": int(script_id) if script_id is not None else None,
            "name": name,
            "created_at": int(created_at),
        }

    async def clear_pending_escript(self, prompt_id: int) -> None:
        await self._execute("DELETE FROM pending_escripts WHERE prompt_id=%s", (prompt_id,))

    async def add_escript(
        self,
        *,
        chat_id: int,
        name: str,
        filename: str,
        author_id: int,
        author_username: Optional[str],
        active: bool,
        errors: int,
        warnings: int,
        log_path: Optional[str],
    ) -> int:
        now = int(time.time())
        await self._execute(
            """
            INSERT INTO escripts
            (chat_id, name, filename, author_id, author_username, active, errors, warnings, created_at, updated_at, last_compiled_at, last_log_path)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """,
            (
                chat_id,
                name,
                filename,
                author_id,
                author_username,
                int(active),
                int(errors),
                int(warnings),
                now,
                now,
                now,
                log_path,
            ),
        )
        rows = await self._execute("SELECT LAST_INSERT_ID()")
        return int(rows[0][0]) if rows else 0

    async def list_escripts(self, chat_id: int) -> Tuple[Tuple[Any, ...], ...]:
        rows = await self._execute(
            """
            SELECT id, name, filename, author_id, author_username, active, errors, warnings, created_at, updated_at, last_compiled_at, last_log_path
            FROM escripts
            WHERE chat_id=%s
            ORDER BY created_at ASC
            """,
            (chat_id,),
        )
        return rows

    async def get_escript(self, chat_id: int, script_id: int) -> Optional[Dict[str, Any]]:
        rows = await self._execute(
            """
            SELECT id, name, filename, author_id, author_username, active, errors, warnings, created_at, updated_at, last_compiled_at, last_log_path
            FROM escripts
            WHERE chat_id=%s AND id=%s
            LIMIT 1
            """,
            (chat_id, script_id),
        )
        if not rows:
            return None
        (
            script_id,
            name,
            filename,
            author_id,
            author_username,
            active,
            errors,
            warnings,
            created_at,
            updated_at,
            last_compiled_at,
            last_log_path,
        ) = rows[0]
        return {
            "id": int(script_id),
            "name": name,
            "filename": filename,
            "author_id": int(author_id),
            "author_username": author_username,
            "active": bool(active),
            "errors": int(errors),
            "warnings": int(warnings),
            "created_at": int(created_at),
            "updated_at": int(updated_at),
            "last_compiled_at": int(last_compiled_at),
            "last_log_path": last_log_path,
        }

    async def update_escript_status(self, chat_id: int, script_id: int, active: bool) -> None:
        now = int(time.time())
        await self._execute(
            "UPDATE escripts SET active=%s, updated_at=%s WHERE chat_id=%s AND id=%s",
            (int(active), now, chat_id, script_id),
        )

    async def update_escript_meta(
        self,
        *,
        chat_id: int,
        script_id: int,
        filename: Optional[str] = None,
        errors: Optional[int] = None,
        warnings: Optional[int] = None,
        log_path: Optional[str] = None,
        active: Optional[bool] = None,
    ) -> None:
        updates: list[str] = []
        params: list[Any] = []
        if filename is not None:
            updates.append("filename=%s")
            params.append(filename)
        if errors is not None:
            updates.append("errors=%s")
            params.append(int(errors))
        if warnings is not None:
            updates.append("warnings=%s")
            params.append(int(warnings))
        if log_path is not None:
            updates.append("last_log_path=%s")
            params.append(log_path)
        if active is not None:
            updates.append("active=%s")
            params.append(int(active))
        updates.append("updated_at=%s")
        updates.append("last_compiled_at=%s")
        now = int(time.time())
        params.extend([now, now, chat_id, script_id])
        await self._execute(
            f"UPDATE escripts SET {', '.join(updates)} WHERE chat_id=%s AND id=%s",
            tuple(params),
        )

    async def delete_escript(self, chat_id: int, script_id: int) -> None:
        await self._execute("DELETE FROM escripts WHERE chat_id=%s AND id=%s", (chat_id, script_id))
        await self._execute("DELETE FROM escript_errors WHERE chat_id=%s AND script_id=%s", (chat_id, script_id))
        await self._execute("DELETE FROM escript_runs WHERE chat_id=%s AND script_id=%s", (chat_id, script_id))

    async def record_escript_error(self, chat_id: int, script_id: int, message: str) -> None:
        await self._execute(
            "INSERT INTO escript_errors (chat_id, script_id, created_at, message) VALUES (%s, %s, %s, %s)",
            (chat_id, script_id, int(time.time()), message),
        )

    async def count_escript_errors_since(self, chat_id: int, script_id: int, since: int) -> int:
        rows = await self._execute(
            "SELECT COUNT(*) FROM escript_errors WHERE chat_id=%s AND script_id=%s AND created_at >= %s",
            (chat_id, script_id, since),
        )
        return int(rows[0][0]) if rows else 0

    async def get_escript_run(self, chat_id: int, script_id: int, event_key: str) -> int:
        rows = await self._execute(
            "SELECT last_run FROM escript_runs WHERE chat_id=%s AND script_id=%s AND event_key=%s",
            (chat_id, script_id, event_key),
        )
        if not rows:
            return 0
        return int(rows[0][0] or 0)

    async def set_escript_run(self, chat_id: int, script_id: int, event_key: str, last_run: int) -> None:
        await self._execute(
            """
            INSERT INTO escript_runs (chat_id, script_id, event_key, last_run)
            VALUES (%s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE last_run=VALUES(last_run)
            """,
            (chat_id, script_id, int(last_run)),
        )

    async def set_escript_kv(
        self, chat_id: int, script_id: int, user_id: int, key: str, value: str
    ) -> None:
        await self._execute(
            """
            INSERT INTO escript_kv (chat_id, script_id, user_id, kv_key, kv_value)
            VALUES (%s, %s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE kv_value=VALUES(kv_value)
            """,
            (chat_id, script_id, user_id, key, value),
        )

    async def get_escript_kv(self, chat_id: int, script_id: int, user_id: int, key: str) -> Optional[str]:
        rows = await self._execute(
            "SELECT kv_value FROM escript_kv WHERE chat_id=%s AND script_id=%s AND user_id=%s AND kv_key=%s",
            (chat_id, script_id, user_id, key),
        )
        if not rows:
            return None
        return rows[0][0]

    async def set_escript_kv_global(self, chat_id: int, script_id: int, key: str, value: str) -> None:
        await self._execute(
            """
            INSERT INTO escript_kv_global (chat_id, script_id, kv_key, kv_value)
            VALUES (%s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE kv_value=VALUES(kv_value)
            """,
            (chat_id, script_id, key, value),
        )

    async def get_escript_kv_global(self, chat_id: int, script_id: int, key: str) -> Optional[str]:
        rows = await self._execute(
            "SELECT kv_value FROM escript_kv_global WHERE chat_id=%s AND script_id=%s AND kv_key=%s",
            (chat_id, script_id, key),
        )
        if not rows:
            return None
        return rows[0][0]

    async def set_nuke_shield(self, chat_id: int, user_id: int, ttl_seconds: int = 3600) -> None:
        expires_at = int(time.time()) + ttl_seconds
        await self._execute(
            """
            INSERT INTO nuke_shields (chat_id, user_id, expires_at)
            VALUES (%s, %s, %s)
            ON DUPLICATE KEY UPDATE expires_at=VALUES(expires_at)
            """,
            (chat_id, user_id, expires_at),
        )

    async def consume_nuke_shield(self, chat_id: int, user_id: int) -> bool:
        now = int(time.time())
        rows = await self._execute(
            "SELECT expires_at FROM nuke_shields WHERE chat_id=%s AND user_id=%s",
            (chat_id, user_id),
        )
        if not rows:
            return False
        expires_at = int(rows[0][0])
        if expires_at <= now:
            await self._execute("DELETE FROM nuke_shields WHERE chat_id=%s AND user_id=%s", (chat_id, user_id))
            return False
        await self._execute("DELETE FROM nuke_shields WHERE chat_id=%s AND user_id=%s", (chat_id, user_id))
        return True

    async def user_identity(self, user_id: int) -> Optional[Tuple[int, str]]:
        """Return a stored identity for a user if present anywhere in balances/user_plans."""

        rows = await self._execute(
            "SELECT user_id, COALESCE(username, user_id) FROM balances WHERE user_id=%s LIMIT 1",
            (user_id,),
        )
        if rows:
            uid, uname = rows[0]
            return int(uid), str(uname)
        rows = await self._execute(
            "SELECT user_id FROM user_plans WHERE user_id=%s LIMIT 1",
            (user_id,),
        )
        if rows:
            return int(user_id), str(user_id)
        return None

    async def find_user_by_username(self, username: str) -> Optional[Tuple[int, str]]:
        """Resolve a username to a user id from any chat balances."""

        rows = await self._execute(
            """
            SELECT user_id, COALESCE(username, user_id)
            FROM balances
            WHERE LOWER(username)=LOWER(%s)
            ORDER BY chat_id
            LIMIT 1
            """,
            (username,),
        )
        if rows:
            uid, uname = rows[0]
            return int(uid), str(uname)
        return None

    async def random_chat_user(self, chat_id: int, exclude: Iterable[int] | None = None) -> Optional[Tuple[int, str]]:
        """Return a random registered user (id, username) for the chat."""

        exclude = set(exclude or [])
        placeholders = ",".join(["%s"] * len(exclude)) if exclude else ""
        params: list[Any] = [chat_id]
        where_exclude = ""
        if exclude:
            params.extend(list(exclude))
            where_exclude = f"AND user_id NOT IN ({placeholders})"
        count_rows = await self._execute(
            f"SELECT COUNT(*) FROM balances WHERE chat_id=%s {where_exclude}",
            tuple(params),
        )
        total = int(count_rows[0][0]) if count_rows else 0
        if total <= 0:
            return None
        offset = random.randint(0, total - 1)
        rows = await self._execute(
            f"SELECT user_id, COALESCE(username, user_id) FROM balances WHERE chat_id=%s {where_exclude} LIMIT 1 OFFSET %s",
            tuple(params + [offset]),
        )
        if not rows:
            return None
        uid, name = rows[0]
        return int(uid), str(name)

    async def list_chat_users(self, chat_id: int) -> list[tuple[int, str]]:
        """Return all registered users for the chat with their latest known usernames."""

        rows = await self._execute(
            "SELECT user_id, COALESCE(username, user_id) FROM balances WHERE chat_id=%s",
            (chat_id,),
        )
        return [(int(uid), str(uname)) for uid, uname in rows]

    async def set_chat_owner(self, chat_id: int, owner_id: int) -> None:
        await self.ensure_chat(chat_id)
        await self._execute(
            "INSERT INTO chat_owners (chat_id, owner_id) VALUES (%s, %s) ON DUPLICATE KEY UPDATE owner_id=VALUES(owner_id)",
            (chat_id, owner_id),
        )

    async def chat_owner(self, chat_id: int) -> Optional[int]:
        rows = await self._execute("SELECT owner_id FROM chat_owners WHERE chat_id=%s LIMIT 1", (chat_id,))
        if rows:
            return int(rows[0][0])
        return None

    async def chats_by_owner(self, owner_id: int) -> tuple[int, ...]:
        rows = await self._execute("SELECT chat_id FROM chat_owners WHERE owner_id=%s", (owner_id,))
        return tuple(int(r[0]) for r in rows)

    async def count_chats_by_owner(self, owner_id: int) -> int:
        rows = await self._execute("SELECT COUNT(*) FROM chat_owners WHERE owner_id=%s", (owner_id,))
        return int(rows[0][0]) if rows else 0

    async def get_user_plan_raw(self, user_id: int) -> dict:
        rows = await self._execute(
            "SELECT plan, expires_at, remind_at FROM user_plans WHERE user_id=%s LIMIT 1", (user_id,)
        )
        if not rows:
            return {"plan": PLAN_BASIC, "expires_at": 0, "remind_at": 0}
        plan, expires_at, remind_at = rows[0]
        return {
            "plan": plan,
            "expires_at": int(expires_at or 0),
            "remind_at": int(remind_at or 0),
        }

    async def get_user_plan(self, user_id: int) -> dict:
        plan = await self.get_user_plan_raw(user_id)
        now = int(time.time())
        if plan.get("expires_at", 0) and plan["expires_at"] < now and plan.get("plan") != PLAN_BASIC:
            await self._execute(
                "UPDATE user_plans SET plan=%s, expires_at=0, remind_at=0 WHERE user_id=%s",
                (PLAN_BASIC, user_id),
            )
            return {"plan": PLAN_BASIC, "expires_at": 0, "remind_at": 0, "expired": True}
        plan["expired"] = False
        return plan

    async def set_user_plan(self, user_id: int, plan: str, months: int = 1, *, weeks: int = 0, days: int = 0) -> dict:
        now = int(time.time())
        duration_seconds = (
            max(0, months) * 30 * 24 * 3600
            + max(0, weeks) * 7 * 24 * 3600
            + max(0, days) * 24 * 3600
        )
        lifetime = duration_seconds == 0
        if plan == PLAN_BASIC:
            expires_at = 0
            remind_at = 0
        elif lifetime:
            expires_at = 0
            remind_at = 0
        else:
            duration_seconds = duration_seconds or 30 * 24 * 3600
            expires_at = now + duration_seconds
            remind_at = max(now, expires_at - 3 * 24 * 3600)
        await self._execute(
            """
            INSERT INTO user_plans (user_id, plan, expires_at, remind_at)
            VALUES (%s,%s,%s,%s)
            ON DUPLICATE KEY UPDATE plan=VALUES(plan), expires_at=VALUES(expires_at), remind_at=VALUES(remind_at)
            """,
            (user_id, plan, expires_at, remind_at),
        )
        return {"plan": plan, "expires_at": expires_at, "remind_at": remind_at}

    async def update_plan_reminder(self, user_id: int, remind_at: int) -> None:
        await self._execute(
            "UPDATE user_plans SET remind_at=%s WHERE user_id=%s",
            (remind_at, user_id),
        )

    async def ensure_plan(self, user_id: int) -> dict:
        plan = await self.get_user_plan(user_id)
        if not plan:
            plan = {"plan": PLAN_BASIC, "expires_at": 0, "remind_at": 0}
        return plan

    async def list_user_plans(self) -> list[dict]:
        rows = await self._execute("SELECT user_id, plan, expires_at, remind_at FROM user_plans")
        return [
            {
                "user_id": int(r[0]),
                "plan": r[1],
                "expires_at": int(r[2] or 0),
                "remind_at": int(r[3] or 0),
            }
            for r in rows
        ]

    async def promo_redeemed(self, user_id: int, code: str) -> bool:
        rows = await self._execute(
            "SELECT 1 FROM promo_redemptions WHERE user_id=%s AND code=%s LIMIT 1", (user_id, code)
        )
        return bool(rows)

    async def mark_promo_redeemed(self, user_id: int, code: str) -> None:
        await self._execute(
            "INSERT INTO promo_redemptions (user_id, code, redeemed_at) VALUES (%s,%s,%s)",
            (user_id, code, int(time.time())),
        )

    async def upsert_limits(
        self, chat_id: int, user_id: int, *, day: Optional[int] = None, transfer: int = 0, credit: int = 0
    ) -> dict:
        day_val = day if day is not None else int(time.time() // 86400)
        await self._execute(
            """
            INSERT INTO user_limits (chat_id, user_id, day, transfer_total, credit_total)
            VALUES (%s,%s,%s,%s,%s) AS new_val
            ON DUPLICATE KEY UPDATE
                transfer_total = user_limits.transfer_total + new_val.transfer_total,
                credit_total = user_limits.credit_total + new_val.credit_total
            """,
            (chat_id, user_id, day_val, transfer, credit),
        )
        return await self.get_limits(chat_id, user_id, day_val)

    async def get_limits(self, chat_id: int, user_id: int, day: Optional[int] = None) -> dict:
        day_val = day if day is not None else int(time.time() // 86400)
        rows = await self._execute(
            "SELECT transfer_total, credit_total FROM user_limits WHERE chat_id=%s AND user_id=%s AND day=%s",
            (chat_id, user_id, day_val),
        )
        if not rows:
            return {"transfer": 0, "credit": 0}
        return {"transfer": int(rows[0][0]), "credit": int(rows[0][1])}

    async def chat_currency(self, chat_id: int) -> Dict:
        await self.ensure_chat(chat_id)
        rows = await self._execute(
            """
            SELECT currency_name, currency_icon, rate, shop_type, auto_declension, case_one, case_few, case_many, daily_reward, tax_rate, blocked, treasury, free_mode
            FROM chats WHERE chat_id=%s
            """,
            (chat_id,),
        )
        if not rows:
            return DEFAULT_CURRENCY
        (
            name,
            icon,
            rate,
            shop_type,
            auto_declension,
            case_one,
            case_few,
            case_many,
            daily_reward,
            tax_rate,
            blocked,
            treasury,
            free_mode,
        ) = rows[0]
        return {
            "name": name,
            "icon": icon,
            "rate": int(rate),
            "shop_type": shop_type or "fixed",
            "auto_declension": bool(auto_declension),
            "cases": {"one": case_one, "few": case_few, "many": case_many},
            "daily_reward": int(daily_reward),
            "tax_rate": int(tax_rate),
            "blocked": bool(blocked),
            "treasury": int(treasury),
            "free_mode": bool(free_mode),
        }

    async def chat_shop_type(self, chat_id: int) -> str:
        await self.ensure_chat(chat_id)
        rows = await self._execute("SELECT shop_type FROM chats WHERE chat_id=%s", (chat_id,))
        if not rows:
            return "fixed"
        value = rows[0][0] or "fixed"
        return str(value)

    async def set_shop_type(self, chat_id: int, shop_type: str) -> None:
        await self.ensure_chat(chat_id)
        normalized = "normal" if shop_type == "normal" else "fixed"
        await self._execute("UPDATE chats SET shop_type=%s WHERE chat_id=%s", (normalized, chat_id))

    async def chat_prefixes(self, chat_id: int) -> tuple[str, ...]:
        await self.ensure_chat(chat_id)
        rows = await self._execute(
            "SELECT prefix FROM chat_prefixes WHERE chat_id=%s ORDER BY LENGTH(prefix) DESC, prefix", (chat_id,)
        )
        if not rows:
            return DEFAULT_PREFIXES
        return tuple(r[0] for r in rows)

    async def set_prefixes(self, chat_id: int, prefixes: Iterable[str]) -> None:
        await self.ensure_chat(chat_id)
        seen: list[str] = []
        for prefix in prefixes:
            if not prefix:
                continue
            pref = prefix.strip()
            if not pref or pref in seen:
                continue
            seen.append(pref)
        clean = tuple(seen) or DEFAULT_PREFIXES
        async with self.pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute("DELETE FROM chat_prefixes WHERE chat_id=%s", (chat_id,))
                values = ",".join(["(%s,%s)"] * len(clean))
                params: list[Any] = []
                for p in clean:
                    params.extend([chat_id, p])
                await cur.execute(f"INSERT INTO chat_prefixes (chat_id, prefix) VALUES {values}", params)

    async def set_currency_name(self, chat_id: int, name: str) -> None:
        await self.ensure_chat(chat_id)
        await self._execute("UPDATE chats SET currency_name=%s WHERE chat_id=%s", (name, chat_id))

    async def set_currency_icon(self, chat_id: int, icon: str) -> None:
        await self.ensure_chat(chat_id)
        await self._execute("UPDATE chats SET currency_icon=%s WHERE chat_id=%s", (icon, chat_id))

    async def set_currency_rate(self, chat_id: int, rate: int) -> None:
        await self.ensure_chat(chat_id)
        await self._execute("UPDATE chats SET rate=%s WHERE chat_id=%s", (rate, chat_id))

    async def set_cases(self, chat_id: int, one: str, few: str, many: str) -> None:
        await self.ensure_chat(chat_id)
        await self._execute(
            "UPDATE chats SET case_one=%s, case_few=%s, case_many=%s WHERE chat_id=%s",
            (one, few, many, chat_id),
        )

    async def set_auto_declension(self, chat_id: int, enabled: bool) -> None:
        await self.ensure_chat(chat_id)
        await self._execute("UPDATE chats SET auto_declension=%s WHERE chat_id=%s", (enabled, chat_id))

    async def set_daily_reward(self, chat_id: int, amount: int) -> None:
        await self.ensure_chat(chat_id)
        await self._execute("UPDATE chats SET daily_reward=%s WHERE chat_id=%s", (amount, chat_id))

    async def set_tax_rate(self, chat_id: int, rate: int) -> None:
        await self.ensure_chat(chat_id)
        await self._execute("UPDATE chats SET tax_rate=%s WHERE chat_id=%s", (rate, chat_id))

    async def set_blocked(self, chat_id: int, blocked: bool) -> None:
        await self.ensure_chat(chat_id)
        await self._execute("UPDATE chats SET blocked=%s WHERE chat_id=%s", (blocked, chat_id))

    async def is_blocked(self, chat_id: int) -> bool:
        await self.ensure_chat(chat_id)
        rows = await self._execute("SELECT blocked FROM chats WHERE chat_id=%s", (chat_id,))
        return bool(rows[0][0]) if rows else False

    async def set_free_mode(self, chat_id: int, enabled: bool) -> None:
        await self.ensure_chat(chat_id)
        await self._execute("UPDATE chats SET free_mode=%s WHERE chat_id=%s", (enabled, chat_id))

    async def is_free_mode(self, chat_id: int) -> bool:
        await self.ensure_chat(chat_id)
        rows = await self._execute("SELECT free_mode FROM chats WHERE chat_id=%s", (chat_id,))
        return bool(rows[0][0]) if rows else False

    async def delete_chat(self, chat_id: int) -> None:
        tables = (
            "chat_prefixes",
            "balances",
            "permissions",
            "banned_users",
            "daily_claims",
            "shop_items",
            "logs",
            "purchases",
            "jobs",
            "chats",
        )
        for table in tables:
            await self._execute(f"DELETE FROM {table} WHERE chat_id=%s", (chat_id,))

    async def get_treasury(self, chat_id: int) -> int:
        await self.ensure_chat(chat_id)
        rows = await self._execute("SELECT treasury FROM chats WHERE chat_id=%s", (chat_id,))
        return int(rows[0][0]) if rows else 0

    async def adjust_treasury(self, chat_id: int, delta: int, *, prevent_negative: bool = True) -> Optional[int]:
        await self.ensure_chat(chat_id)
        if prevent_negative and delta < 0:
            affected = await self._execute_write(
                "UPDATE chats SET treasury = treasury + %s WHERE chat_id=%s AND treasury >= %s",
                (delta, chat_id, -delta),
            )
            if affected == 0:
                return None
        else:
            await self._execute(
                "UPDATE chats SET treasury = treasury + %s WHERE chat_id=%s",
                (delta, chat_id),
            )
        return await self.get_treasury(chat_id)

    async def adjust_balance(
        self,
        chat_id: int,
        user_id: int,
        username: str | None,
        amount: int,
        *,
        prevent_negative: bool = True,
    ) -> int | None:
        await self.ensure_chat(chat_id)
        if amount < 0 and prevent_negative:
            affected = await self._execute_write(
                """
                UPDATE balances
                SET balance = balance + %s, username = COALESCE(%s, username)
                WHERE chat_id=%s AND user_id=%s AND balance >= %s
                """,
                (amount, username, chat_id, user_id, -amount),
            )
            if affected == 0:
                return None
        else:
            await self._execute(
                """
                INSERT INTO balances (chat_id, user_id, username, balance)
                VALUES (%s, %s, %s, %s) AS new_val
                ON DUPLICATE KEY UPDATE balances.balance = balances.balance + new_val.balance,
                balances.username = COALESCE(new_val.username, balances.username)
                """,
                (chat_id, user_id, username, amount),
            )
        return await self.get_balance(chat_id, user_id)

    async def transfer_balance(
        self,
        *,
        chat_id: int,
        sender_id: int,
        sender_username: str | None,
        receiver_id: int,
        receiver_username: str | None,
        amount: int,
        idempotency_key: str,
        day: int,
        metadata: dict | None = None,
    ) -> tuple[int, int] | None:
        async def handler(conn):
            async with conn.cursor() as cur:
                try:
                    await cur.execute(
                        """
                        INSERT INTO transactions (chat_id, operation_type, amount, from_user, to_user, metadata, idempotency_key, created_at)
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                        """,
                        (
                            chat_id,
                            "transfer",
                            amount,
                            sender_id,
                            receiver_id,
                            json.dumps(metadata or {}, ensure_ascii=False),
                            idempotency_key,
                            int(time.time()),
                        ),
                    )
                except Exception as exc:
                    if "duplicate" in str(exc).lower():
                        return None
                    raise
                await cur.execute(
                    """
                    UPDATE balances
                    SET balance = balance - %s, username = COALESCE(%s, username)
                    WHERE chat_id=%s AND user_id=%s AND balance >= %s
                    """,
                    (amount, sender_username, chat_id, sender_id, amount),
                )
                if cur.rowcount == 0:
                    raise ValueError("insufficient_funds")
                await cur.execute(
                    """
                    INSERT INTO balances (chat_id, user_id, username, balance)
                    VALUES (%s, %s, %s, %s) AS new_val
                    ON DUPLICATE KEY UPDATE
                        balances.balance = balances.balance + new_val.balance,
                        balances.username = COALESCE(new_val.username, balances.username)
                    """,
                    (chat_id, receiver_id, receiver_username, amount),
                )
                await cur.execute(
                    """
                    INSERT INTO user_limits (chat_id, user_id, day, transfer_total, credit_total)
                    VALUES (%s, %s, %s, %s, 0) AS new_val
                    ON DUPLICATE KEY UPDATE transfer_total = user_limits.transfer_total + new_val.transfer_total
                    """,
                    (chat_id, sender_id, day, amount),
                )
                await cur.execute(
                    "SELECT balance FROM balances WHERE chat_id=%s AND user_id=%s",
                    (chat_id, sender_id),
                )
                sender_balance = int((await cur.fetchone())[0])
                await cur.execute(
                    "SELECT balance FROM balances WHERE chat_id=%s AND user_id=%s",
                    (chat_id, receiver_id),
                )
                receiver_balance = int((await cur.fetchone())[0])
                return sender_balance, receiver_balance

        return await self._in_transaction(handler)

    async def set_balance(self, chat_id: int, user_id: int, username: str, amount: int) -> int:
        await self.ensure_chat(chat_id)
        await self._execute(
            """
            INSERT INTO balances (chat_id, user_id, username, balance)
            VALUES (%s, %s, %s, %s) AS new_val
            ON DUPLICATE KEY UPDATE balances.balance = new_val.balance, balances.username = new_val.username
            """,
            (chat_id, user_id, username, amount),
        )
        return await self.get_balance(chat_id, user_id)

    async def get_balance(self, chat_id: int, user_id: int) -> int:
        rows = await self._execute(
            "SELECT balance FROM balances WHERE chat_id=%s AND user_id=%s",
            (chat_id, user_id),
        )
        if not rows:
            return 0
        return int(rows[0][0])

    async def list_chats(self) -> Tuple[int, ...]:
        rows = await self._execute("SELECT chat_id FROM chats ORDER BY chat_id DESC")
        return tuple(int(row[0]) for row in rows)

    async def get_top(self, chat_id: int, limit: int = 10) -> Tuple[Tuple[int, str, int], ...]:
        rows = await self._execute(
            """
            SELECT user_id, COALESCE(username, user_id) as name, balance
            FROM balances
            WHERE chat_id=%s
            ORDER BY balance DESC
            LIMIT %s
            """,
            (chat_id, limit),
        )
        return tuple((int(row[0]), str(row[1]), int(row[2])) for row in rows)

    async def set_daily_claim(self, chat_id: int, user_id: int, timestamp: float) -> None:
        await self._execute(
            """
            INSERT INTO daily_claims (chat_id, user_id, last_claim)
            VALUES (%s, %s, %s) AS new_val
            ON DUPLICATE KEY UPDATE last_claim = new_val.last_claim
            """,
            (chat_id, user_id, int(timestamp)),
        )

    async def last_daily_claim(self, chat_id: int, user_id: int) -> float:
        rows = await self._execute(
            "SELECT last_claim FROM daily_claims WHERE chat_id=%s AND user_id=%s",
            (chat_id, user_id),
        )
        if not rows:
            return 0.0
        return float(rows[0][0])

    async def list_shop_items(self, chat_id: int):
        await self.ensure_chat(chat_id)
        rows = await self._execute(
            """
            SELECT id, title, price, author_id, author_username, quantity
            FROM shop_items
            WHERE chat_id=%s
            ORDER BY id ASC
            """,
            (chat_id,),
        )
        return tuple((int(r[0]), str(r[1]), int(r[2]), int(r[3]), r[4] or "", int(r[5])) for r in rows)

    async def purchase_shop_item(
        self,
        *,
        chat_id: int,
        index: int,
        buyer_id: int,
        buyer_username: str,
        tax_rate: int,
        idempotency_key: str,
        metadata: dict | None = None,
    ) -> dict | None:
        async def handler(conn):
            async with conn.cursor() as cur:
                try:
                    await cur.execute(
                        """
                        INSERT INTO transactions (chat_id, operation_type, amount, from_user, to_user, metadata, idempotency_key, created_at)
                        VALUES (%s, %s, 0, %s, NULL, %s, %s, %s)
                        """,
                        (
                            chat_id,
                            "shop_purchase",
                            buyer_id,
                            json.dumps(metadata or {}, ensure_ascii=False),
                            idempotency_key,
                            int(time.time()),
                        ),
                    )
                except Exception as exc:
                    if "duplicate" in str(exc).lower():
                        return None
                    raise
                await cur.execute(
                    """
                    SELECT id, title, price, author_id, author_username, quantity
                    FROM shop_items
                    WHERE chat_id=%s
                    ORDER BY id ASC
                    LIMIT 1 OFFSET %s
                    FOR UPDATE
                    """,
                    (chat_id, index - 1),
                )
                row = await cur.fetchone()
                if not row:
                    raise ValueError("item_not_found")
                item_id, title, price, author_id, author_username, quantity = row
                if price <= 0:
                    raise ValueError("invalid_price")
                if quantity is not None and quantity > 0:
                    new_qty = quantity - 1
                    if new_qty <= 0:
                        await cur.execute("DELETE FROM shop_items WHERE id=%s", (item_id,))
                    else:
                        await cur.execute("UPDATE shop_items SET quantity=%s WHERE id=%s", (new_qty, item_id))
                await cur.execute(
                    """
                    UPDATE balances
                    SET balance = balance - %s, username = COALESCE(%s, username)
                    WHERE chat_id=%s AND user_id=%s AND balance >= %s
                    """,
                    (price, buyer_username, chat_id, buyer_id, price),
                )
                if cur.rowcount == 0:
                    raise ValueError("insufficient_funds")
                tax_amount = price * tax_rate // 10000
                seller_gain = price - tax_amount
                await cur.execute(
                    """
                    INSERT INTO balances (chat_id, user_id, username, balance)
                    VALUES (%s, %s, %s, %s) AS new_val
                    ON DUPLICATE KEY UPDATE
                        balances.balance = balances.balance + new_val.balance,
                        balances.username = COALESCE(new_val.username, balances.username)
                    """,
                    (chat_id, author_id, author_username, seller_gain),
                )
                await cur.execute(
                    "UPDATE chats SET treasury = treasury + %s WHERE chat_id=%s",
                    (tax_amount, chat_id),
                )
                await cur.execute(
                    """
                    INSERT INTO purchases (chat_id, buyer_id, buyer_username, title, price, seller_username, seller_id, item_code, consumed, created_at)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, NULL, 0, %s)
                    """,
                    (chat_id, buyer_id, buyer_username, title, price, author_username, author_id, int(time.time())),
                )
                await cur.execute(
                    """
                    UPDATE transactions
                    SET amount=%s, to_user=%s, metadata=%s
                    WHERE idempotency_key=%s
                    """,
                    (
                        price,
                        author_id,
                        json.dumps(
                            {
                                "title": title,
                                "tax_amount": tax_amount,
                                "seller_gain": seller_gain,
                            },
                            ensure_ascii=False,
                        ),
                        idempotency_key,
                    ),
                )
                await cur.execute(
                    "SELECT balance FROM balances WHERE chat_id=%s AND user_id=%s",
                    (chat_id, buyer_id),
                )
                new_balance = int((await cur.fetchone())[0])
                return {
                    "title": str(title),
                    "price": int(price),
                    "author_id": int(author_id),
                    "author_username": author_username,
                    "tax_amount": int(tax_amount),
                    "seller_gain": int(seller_gain),
                    "new_balance": new_balance,
                }

        return await self._in_transaction(handler)

    async def purchase_fixed_item(
        self,
        *,
        chat_id: int,
        buyer_id: int,
        buyer_username: str,
        item_code: str,
        title: str,
        price: int,
        tax_rate: int,
        idempotency_key: str,
        consumed: bool = False,
        metadata: dict | None = None,
    ) -> dict | None:
        async def handler(conn):
            async with conn.cursor() as cur:
                try:
                    await cur.execute(
                        """
                        INSERT INTO transactions (chat_id, operation_type, amount, from_user, to_user, metadata, idempotency_key, created_at)
                        VALUES (%s, %s, %s, %s, NULL, %s, %s, %s)
                        """,
                        (
                            chat_id,
                            "fixed_purchase",
                            price,
                            buyer_id,
                            json.dumps(metadata or {}, ensure_ascii=False),
                            idempotency_key,
                            int(time.time()),
                        ),
                    )
                except Exception as exc:
                    if "duplicate" in str(exc).lower():
                        return None
                    raise
                await cur.execute(
                    """
                    UPDATE balances
                    SET balance = balance - %s, username = COALESCE(%s, username)
                    WHERE chat_id=%s AND user_id=%s AND balance >= %s
                    """,
                    (price, buyer_username, chat_id, buyer_id, price),
                )
                if cur.rowcount == 0:
                    raise ValueError("insufficient_funds")
                tax_amount = price * tax_rate // 10000
                await cur.execute(
                    "UPDATE chats SET treasury = treasury + %s WHERE chat_id=%s",
                    (tax_amount, chat_id),
                )
                await cur.execute(
                    """
                    INSERT INTO purchases (chat_id, buyer_id, buyer_username, title, price, seller_username, seller_id, item_code, consumed, created_at)
                    VALUES (%s, %s, %s, %s, %s, '', NULL, %s, %s, %s)
                    """,
                    (chat_id, buyer_id, buyer_username, title, price, item_code, 1 if consumed else 0, int(time.time())),
                )
                await cur.execute(
                    "SELECT balance FROM balances WHERE chat_id=%s AND user_id=%s",
                    (chat_id, buyer_id),
                )
                new_balance = int((await cur.fetchone())[0])
                return {
                    "price": price,
                    "tax_amount": tax_amount,
                    "new_balance": new_balance,
                }

        return await self._in_transaction(handler)

    async def add_shop_item(
        self,
        chat_id: int,
        title: str,
        price: int,
        author_id: int,
        author_username: str,
        quantity: int = 0,
    ) -> int:
        await self.ensure_chat(chat_id)
        async with self.pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "INSERT INTO shop_items (chat_id, title, price, author_id, author_username, quantity) VALUES (%s, %s, %s, %s, %s, %s)",
                    (chat_id, title, price, author_id, author_username, quantity),
                )
                inserted_id = cur.lastrowid
        rows = await self._execute("SELECT id FROM shop_items WHERE chat_id=%s ORDER BY id ASC", (chat_id,))
        ordered_ids = [r[0] for r in rows]
        return ordered_ids.index(inserted_id) + 1 if inserted_id in ordered_ids else len(ordered_ids)

    async def remove_shop_item(self, chat_id: int, index: int) -> bool:
        await self.ensure_chat(chat_id)
        rows = await self._execute("SELECT id FROM shop_items WHERE chat_id=%s ORDER BY id ASC", (chat_id,))
        if not rows or index < 1 or index > len(rows):
            return False
        item_id = rows[index - 1][0]
        await self._execute("DELETE FROM shop_items WHERE id=%s", (item_id,))
        return True

    async def get_shop_item_by_index(self, chat_id: int, index: int):
        rows = await self.list_shop_items(chat_id)
        if not rows or index < 1 or index > len(rows):
            return None
        return rows[index - 1]

    async def update_shop_item(
        self,
        chat_id: int,
        index: int,
        *,
        title: str | None = None,
        price: int | None = None,
        quantity: int | None = None,
    ) -> bool:
        item = await self.get_shop_item_by_index(chat_id, index)
        if not item:
            return False
        item_id = item[0]
        updates = []
        params = []
        if title is not None:
            updates.append("title=%s")
            params.append(title)
        if price is not None:
            updates.append("price=%s")
            params.append(price)
        if quantity is not None:
            updates.append("quantity=%s")
            params.append(quantity)
        if not updates:
            return True
        params.append(item_id)
        await self._execute(f"UPDATE shop_items SET {', '.join(updates)} WHERE id=%s", tuple(params))
        return True

    async def log_event(self, chat_id: int, entry: str) -> None:
        await self._execute(
            "INSERT INTO logs (chat_id, entry, created_at) VALUES (%s, %s, %s)",
            (chat_id, entry, int(time.time())),
        )

    async def list_logs_since(self, chat_id: int, since_timestamp: float):
        rows = await self._execute(
            "SELECT entry, created_at FROM logs WHERE chat_id=%s AND created_at >= %s ORDER BY created_at ASC",
            (chat_id, int(since_timestamp)),
        )
        return tuple((str(r[0]), int(r[1])) for r in rows)

    async def record_purchase(
        self,
        chat_id: int,
        buyer_id: int,
        buyer_username: str,
        title: str,
        price: int,
        seller_username: str,
        seller_id: int | None = None,
        *,
        item_code: str | None = None,
        consumed: bool = False,
    ) -> None:
        await self._execute(
            """
            INSERT INTO purchases (chat_id, buyer_id, buyer_username, title, price, seller_username, seller_id, item_code, consumed, created_at)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """,
            (chat_id, buyer_id, buyer_username, title, price, seller_username, seller_id, item_code, 1 if consumed else 0, int(time.time())),
        )
        rows = await self._execute(
            "SELECT id FROM purchases WHERE chat_id=%s AND buyer_id=%s ORDER BY created_at DESC",
            (chat_id, buyer_id),
        )
        if len(rows) > 20:
            to_remove = len(rows) // 2
            ids_to_delete = [row[0] for row in rows[to_remove:]]
            if ids_to_delete:
                placeholders = ",".join(["%s"] * len(ids_to_delete))
                await self._execute(
                    f"DELETE FROM purchases WHERE id IN ({placeholders})",
                    tuple(ids_to_delete),
                )

    async def purchases_count(self, chat_id: int, buyer_id: int, *, include_consumed: bool = False) -> int:
        clause = "" if include_consumed else "AND consumed=0"
        rows = await self._execute(
            f"SELECT COUNT(*) FROM purchases WHERE chat_id=%s AND buyer_id=%s {clause}",
            (chat_id, buyer_id),
        )
        return int(rows[0][0]) if rows else 0

    async def list_purchases(
        self,
        chat_id: int,
        buyer_id: int,
        *,
        limit: int,
        offset: int = 0,
        include_consumed: bool = False,
    ):
        clause = "" if include_consumed else "AND consumed=0"
        rows = await self._execute(
            f"""
            SELECT id, title, price, seller_username, seller_id, created_at, item_code, consumed
            FROM purchases
            WHERE chat_id=%s AND buyer_id=%s {clause}
            ORDER BY created_at DESC
            LIMIT %s OFFSET %s
            """,
            (chat_id, buyer_id, limit, offset),
        )
        return tuple((int(r[0]), str(r[1]), int(r[2]), r[3] or "", r[4], int(r[5]), r[6] or "", bool(r[7])) for r in rows)

    async def purchase_by_index(
        self, chat_id: int, buyer_id: int, index: int, *, include_consumed: bool = False
    ) -> Dict[str, Any] | None:
        per_page = 1
        offset = max(0, index - 1)
        rows = await self.list_purchases(
            chat_id, buyer_id, limit=per_page, offset=offset, include_consumed=include_consumed
        )
        if not rows:
            return None
        pid, title, price, seller_username, seller_id, created_at, item_code, consumed = rows[0]
        return {
            "id": pid,
            "title": title,
            "price": price,
            "seller_username": seller_username,
            "seller_id": seller_id,
            "created_at": created_at,
            "item_code": item_code,
            "consumed": consumed,
        }

    async def consume_purchase(self, purchase_id: int) -> None:
        await self._execute("UPDATE purchases SET consumed=1 WHERE id=%s", (purchase_id,))

    # Jobs
    async def get_job(self, chat_id: int, user_id: int) -> Dict[str, Any]:
        await self.ensure_chat(chat_id)
        rows = await self._execute(
            """
            SELECT job_code, job_name, base_salary, successes, failures, rating, job_rating, last_work, work_balance, quit_count, quit_window, job_blocked_until
            FROM jobs WHERE chat_id=%s AND user_id=%s
            """,
            (chat_id, user_id),
        )
        if not rows:
            return DEFAULT_JOB.copy()
        (
            job_code,
            job_name,
            base_salary,
            successes,
            failures,
            rating,
            job_rating,
            last_work,
            work_balance,
            quit_count,
            quit_window,
            job_blocked_until,
        ) = rows[0]
        return {
            "job_code": job_code,
            "job_name": job_name,
            "base_salary": int(base_salary or 0),
            "successes": int(successes or 0),
            "failures": int(failures or 0),
            "rating": float(rating or 0),
            "job_rating": float(job_rating or 0),
            "last_work": int(last_work or 0),
            "work_balance": int(work_balance or 0),
            "quit_count": int(quit_count or 0),
            "quit_window": int(quit_window or 0),
            "job_blocked_until": int(job_blocked_until or 0),
        }

    async def set_job(
        self,
        chat_id: int,
        user_id: int,
        *,
        job_code: str,
        job_name: str,
        base_salary: int,
    ) -> None:
        await self.ensure_chat(chat_id)
        await self._execute(
            """
            INSERT INTO jobs (chat_id, user_id, job_code, job_name, base_salary, successes, failures, rating, job_rating, last_work, work_balance, quit_count, quit_window, job_blocked_until)
            VALUES (%s,%s,%s,%s,%s,0,0,0,0,0,0,0,0,0)
            ON DUPLICATE KEY UPDATE job_code=VALUES(job_code), job_name=VALUES(job_name), base_salary=VALUES(base_salary)
            """,
            (chat_id, user_id, job_code, job_name, base_salary),
        )

    async def update_job_stats(
        self,
        chat_id: int,
        user_id: int,
        *,
        success: bool,
        payout: int = 0,
        tax_amount: int = 0,
    ) -> Dict[str, Any]:
        job = await self.get_job(chat_id, user_id)
        successes = job["successes"] + (1 if success else 0)
        failures = job["failures"] + (0 if success else 1)
        now = int(time.time())
        rating_delta = 0.1 if success else 0.0
        job_rating_delta = 0.1 if success else 0.0
        rating = max(0.0, min(10.0, job["rating"] + rating_delta))
        job_rating = max(0.0, min(20.0, job["job_rating"] + job_rating_delta))
        work_balance = job["work_balance"] + payout
        await self._execute(
            """
            INSERT INTO jobs (chat_id, user_id, job_code, job_name, base_salary, successes, failures, rating, job_rating, last_work, work_balance, quit_count, quit_window, job_blocked_until)
            VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
            ON DUPLICATE KEY UPDATE
                successes=VALUES(successes),
                failures=VALUES(failures),
                rating=VALUES(rating),
                job_rating=VALUES(job_rating),
                last_work=VALUES(last_work),
                work_balance=VALUES(work_balance),
                quit_count=VALUES(quit_count),
                quit_window=VALUES(quit_window),
                job_blocked_until=VALUES(job_blocked_until)
            """,
            (
                chat_id,
                user_id,
                job.get("job_code"),
                job.get("job_name"),
                job.get("base_salary", 0),
                successes,
                failures,
                rating,
                job_rating,
                now,
                work_balance,
                job.get("quit_count", 0),
                job.get("quit_window", 0),
                job.get("job_blocked_until", 0),
            ),
        )
        if tax_amount:
            await self.adjust_treasury(chat_id, tax_amount)
        return {
            **job,
            "successes": successes,
            "failures": failures,
            "rating": rating,
            "job_rating": job_rating,
            "last_work": now,
            "work_balance": work_balance,
        }

    async def update_job_rating(self, chat_id: int, user_id: int, *, delta: float, delta_job: float | None = None) -> None:
        job = await self.get_job(chat_id, user_id)
        job_delta = delta if delta_job is None else delta_job
        rating = max(0.0, min(10.0, job["rating"] + delta))
        job_rating = max(0.0, min(20.0, job["job_rating"] + job_delta))
        await self._execute(
            """
            INSERT INTO jobs (chat_id, user_id, job_code, job_name, base_salary, successes, failures, rating, job_rating, last_work, work_balance, quit_count, quit_window, job_blocked_until)
            VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
            ON DUPLICATE KEY UPDATE rating=VALUES(rating), job_rating=VALUES(job_rating), quit_count=VALUES(quit_count), quit_window=VALUES(quit_window), job_blocked_until=VALUES(job_blocked_until)
            """,
            (
                chat_id,
                user_id,
                job.get("job_code"),
                job.get("job_name"),
                job.get("base_salary", 0),
                job.get("successes", 0),
                job.get("failures", 0),
                rating,
                job_rating,
                job.get("last_work", 0),
                job.get("work_balance", 0),
                job.get("quit_count", 0),
                job.get("quit_window", 0),
                job.get("job_blocked_until", 0),
            ),
        )

    async def clear_job(self, chat_id: int, user_id: int, *, rating_drop: float = 0.3) -> Dict[str, Any]:
        job = await self.get_job(chat_id, user_id)
        now = int(time.time())
        rating = max(0.0, min(10.0, job.get("rating", 0.0) - rating_drop))
        job_rating = max(0.0, min(20.0, job.get("job_rating", 0.0) - rating_drop))
        last_work = job.get("last_work") or now
        quit_window = job.get("quit_window", 0)
        quit_count = job.get("quit_count", 0)
        blocked_until = job.get("job_blocked_until", 0)
        if now - quit_window > 3600:
            quit_window = now
            quit_count = 0
        quit_count += 1
        penalty = False
        if quit_count > 3:
            rating = max(0.0, rating - 1.0)
            job_rating = max(0.0, job_rating - 1.0)
            blocked_until = max(blocked_until, now + 3600)
            quit_count = 3
            penalty = True
        await self._execute(
            """
            INSERT INTO jobs (chat_id, user_id, job_code, job_name, base_salary, successes, failures, rating, job_rating, last_work, work_balance, quit_count, quit_window, job_blocked_until)
            VALUES (%s,%s,NULL,NULL,0,0,0,%s,%s,%s,0,%s,%s,%s)
            ON DUPLICATE KEY UPDATE job_code=NULL, job_name=NULL, base_salary=0, successes=0, failures=0, rating=%s, job_rating=%s, last_work=%s, work_balance=0, quit_count=%s, quit_window=%s, job_blocked_until=%s
            """,
            (
                chat_id,
                user_id,
                rating,
                job_rating,
                last_work,
                quit_count,
                quit_window,
                blocked_until,
                rating,
                job_rating,
                last_work,
                quit_count,
                quit_window,
                blocked_until,
            ),
        )
        return {
            "rating": rating,
            "job_rating": job_rating,
            "blocked_until": blocked_until,
            "quit_count": quit_count,
            "penalty": penalty,
        }

    async def withdraw_work_balance(self, chat_id: int, user_id: int, amount: int) -> int:
        job = await self.get_job(chat_id, user_id)
        balance = job.get("work_balance", 0)
        amount = min(amount, balance)
        new_balance = balance - amount
        await self.set_work_balance(chat_id, user_id, new_balance)
        return amount

    async def set_work_balance(self, chat_id: int, user_id: int, amount: int) -> None:
        job = await self.get_job(chat_id, user_id)
        await self._execute(
            """
            INSERT INTO jobs (chat_id, user_id, job_code, job_name, base_salary, successes, failures, rating, job_rating, last_work, work_balance, quit_count, quit_window, job_blocked_until)
            VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
            ON DUPLICATE KEY UPDATE work_balance=VALUES(work_balance), quit_count=VALUES(quit_count), quit_window=VALUES(quit_window), job_blocked_until=VALUES(job_blocked_until)
            """,
            (
                chat_id,
                user_id,
                job.get("job_code"),
                job.get("job_name"),
                job.get("base_salary", 0),
                job.get("successes", 0),
                job.get("failures", 0),
                job.get("rating", 0.0),
                job.get("job_rating", 0.0),
                job.get("last_work", 0),
                amount,
                job.get("quit_count", 0),
                job.get("quit_window", 0),
                job.get("job_blocked_until", 0),
            ),
        )

    async def permissions(self, chat_id: int) -> Dict:
        rows = await self._execute("SELECT user_id, role FROM permissions WHERE chat_id=%s", (chat_id,))
        banned = await self.banned_users(chat_id)
        result = {"economy_admins": [], "allow_credit": [], "allow_debit": [], "banned": list(banned)}
        for user_id, role in rows:
            if role == "admin":
                result["economy_admins"].append(int(user_id))
            elif role == "credit":
                result["allow_credit"].append(int(user_id))
            elif role == "debit":
                result["allow_debit"].append(int(user_id))
        return result

    async def update_permissions(
        self,
        chat_id: int,
        *,
        economy_admins=None,
        allow_credit=None,
        allow_debit=None,
    ) -> None:
        owner_id = await self.chat_owner(chat_id)
        await self._execute("DELETE FROM permissions WHERE chat_id=%s", (chat_id,))
        entries = []
        if owner_id is not None:
            economy_admins = list(economy_admins or [])
            if owner_id not in economy_admins:
                economy_admins.append(owner_id)
        if economy_admins is not None:
            entries.extend([(int(uid), "admin") for uid in set(economy_admins)])
        if allow_credit is not None:
            entries.extend([(int(uid), "credit") for uid in set(allow_credit)])
        if allow_debit is not None:
            entries.extend([(int(uid), "debit") for uid in set(allow_debit)])

        if entries:
            values = ",".join(["(%s,%s,%s)"] * len(entries))
            params = []
            for uid, role in entries:
                params.extend([chat_id, uid, role])
            await self._execute(
                f"INSERT INTO permissions (chat_id, user_id, role) VALUES {values}",
                tuple(params),
            )

    async def ban_user(self, chat_id: int, user_id: int) -> None:
        """Mark user as banned and strip economy permissions."""

        await self._execute(
            "INSERT INTO banned_users (chat_id, user_id) VALUES (%s,%s) ON DUPLICATE KEY UPDATE user_id=user_id",
            (chat_id, user_id),
        )
        # remove any economy roles to avoid privilege leakage
        await self._execute("DELETE FROM permissions WHERE chat_id=%s AND user_id=%s", (chat_id, user_id))

    async def unban_user(self, chat_id: int, user_id: int) -> None:
        await self._execute("DELETE FROM banned_users WHERE chat_id=%s AND user_id=%s", (chat_id, user_id))

    async def clear_all_bans(self, chat_id: int) -> int:
        """Remove every banned user entry for the chat and return affected rows."""
        return await self._execute("DELETE FROM banned_users WHERE chat_id=%s", (chat_id,))

    async def is_banned(self, chat_id: int, user_id: int) -> bool:
        rows = await self._execute(
            "SELECT 1 FROM banned_users WHERE chat_id=%s AND user_id=%s LIMIT 1", (chat_id, user_id)
        )
        return bool(rows)

    async def banned_users(self, chat_id: int) -> set[int]:
        rows = await self._execute("SELECT user_id FROM banned_users WHERE chat_id=%s", (chat_id,))
        return {int(r[0]) for r in rows}

    async def dump_all(self) -> Dict[str, Any]:
        result: Dict[str, Any] = {}
        chats = await self._execute(
            "SELECT chat_id, currency_name, currency_icon, rate, shop_type, auto_declension, case_one, case_few, case_many, daily_reward, tax_rate, blocked, treasury, free_mode FROM chats"
        )
        result["chats"] = [
            {
                "chat_id": int(row[0]),
                "currency_name": row[1],
                "currency_icon": row[2],
                "rate": int(row[3]),
                "shop_type": row[4] or "fixed",
                "auto_declension": bool(row[5]),
                "case_one": row[6],
                "case_few": row[7],
                "case_many": row[8],
                "daily_reward": int(row[9]),
                "tax_rate": int(row[10]),
                "blocked": bool(row[11]),
                "treasury": int(row[12]),
                "free_mode": bool(row[13]),
            }
            for row in chats
        ]
        balances = await self._execute("SELECT chat_id, user_id, username, balance FROM balances")
        result["balances"] = [
            {
                "chat_id": int(r[0]),
                "user_id": int(r[1]),
                "username": r[2],
                "balance": int(r[3]),
            }
            for r in balances
        ]
        permissions = await self._execute("SELECT chat_id, user_id, role FROM permissions")
        result["permissions"] = [
            {"chat_id": int(r[0]), "user_id": int(r[1]), "role": r[2]} for r in permissions
        ]
        bans = await self._execute("SELECT chat_id, user_id FROM banned_users")
        result["bans"] = [
            {"chat_id": int(r[0]), "user_id": int(r[1])} for r in bans
        ]
        claims = await self._execute("SELECT chat_id, user_id, last_claim FROM daily_claims")
        result["daily_claims"] = [
            {"chat_id": int(r[0]), "user_id": int(r[1]), "last_claim": int(r[2])} for r in claims
        ]
        items = await self._execute(
            "SELECT id, chat_id, title, price, author_id, author_username, quantity FROM shop_items"
        )
        result["shop_items"] = [
            {
                "id": int(r[0]),
                "chat_id": int(r[1]),
                "title": r[2],
                "price": int(r[3]),
                "author_id": int(r[4]),
                "author_username": r[5],
                "quantity": int(r[6]),
            }
            for r in items
        ]
        purchases = await self._execute(
            "SELECT id, chat_id, buyer_id, buyer_username, title, price, seller_username, seller_id, created_at FROM purchases"
        )
        result["purchases"] = [
            {
                "id": int(r[0]),
                "chat_id": int(r[1]),
                "buyer_id": int(r[2]),
                "buyer_username": r[3],
                "title": r[4],
                "price": int(r[5]),
                "seller_username": r[6],
                "seller_id": int(r[7]) if r[7] is not None else None,
                "created_at": int(r[8]),
            }
            for r in purchases
        ]
        prefixes = await self._execute("SELECT chat_id, prefix FROM chat_prefixes")
        result["prefixes"] = [
            {"chat_id": int(r[0]), "prefix": r[1]} for r in prefixes
        ]
        jobs = await self._execute(
            "SELECT chat_id, user_id, job_code, job_name, base_salary, successes, failures, rating, job_rating, last_work, work_balance, quit_count, quit_window, job_blocked_until FROM jobs"
        )
        result["jobs"] = [
            {
                "chat_id": int(r[0]),
                "user_id": int(r[1]),
                "job_code": r[2],
                "job_name": r[3],
                "base_salary": int(r[4] or 0),
                "successes": int(r[5] or 0),
                "failures": int(r[6] or 0),
                "rating": float(r[7] or 0),
                "job_rating": float(r[8] or 0),
                "last_work": int(r[9] or 0),
                "work_balance": int(r[10] or 0),
                "quit_count": int(r[11] or 0),
                "quit_window": int(r[12] or 0),
                "job_blocked_until": int(r[13] or 0),
            }
            for r in jobs
        ]
        owners = await self._execute("SELECT chat_id, owner_id FROM chat_owners")
        result["chat_owners"] = [
            {"chat_id": int(r[0]), "owner_id": int(r[1])} for r in owners
        ]
        plans = await self._execute("SELECT user_id, plan, expires_at, remind_at FROM user_plans")
        result["user_plans"] = [
            {
                "user_id": int(r[0]),
                "plan": r[1],
                "expires_at": int(r[2] or 0),
                "remind_at": int(r[3] or 0),
            }
            for r in plans
        ]
        limits = await self._execute("SELECT chat_id, user_id, day, transfer_total, credit_total FROM user_limits")
        result["user_limits"] = [
            {
                "chat_id": int(r[0]),
                "user_id": int(r[1]),
                "day": int(r[2]),
                "transfer_total": int(r[3] or 0),
                "credit_total": int(r[4] or 0),
            }
            for r in limits
        ]
        redemptions = await self._execute("SELECT user_id, code, redeemed_at FROM promo_redemptions")
        result["promo_redemptions"] = [
            {"user_id": int(r[0]), "code": r[1], "redeemed_at": int(r[2])} for r in redemptions
        ]
        return result

    async def load_dump(self, data: Dict[str, Any]) -> None:
        if not data:
            return
        async with self.pool.acquire() as conn:
            async with conn.cursor() as cur:
                for table in (
                    "promo_redemptions",
                    "user_limits",
                    "user_plans",
                    "purchases",
                    "shop_items",
                    "jobs",
                    "daily_claims",
                    "permissions",
                    "banned_users",
                    "balances",
                    "chat_owners",
                    "chats",
                ):
                    await cur.execute(f"DELETE FROM {table}")

        for chat in data.get("chats", []):
            await self._execute(
                """
                INSERT INTO chats (chat_id, currency_name, currency_icon, rate, shop_type, auto_declension, case_one, case_few, case_many, daily_reward, tax_rate, blocked, treasury, free_mode)
                VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
                """,
                (
                    chat.get("chat_id"),
                    chat.get("currency_name"),
                    chat.get("currency_icon"),
                    chat.get("rate"),
                    chat.get("shop_type", "fixed"),
                    chat.get("auto_declension", True),
                    chat.get("case_one"),
                    chat.get("case_few"),
                    chat.get("case_many"),
                    chat.get("daily_reward", 10000),
                    chat.get("tax_rate", 500),
                    bool(chat.get("blocked", False)),
                    chat.get("treasury", 0),
                    bool(chat.get("free_mode", False)),
                ),
            )
        balances_data = data.get("balances", [])
        for row in balances_data:
            await self._execute(
                """
                INSERT INTO balances (chat_id, user_id, username, balance)
                VALUES (%s, %s, %s, %s)
                """,
                (row.get("chat_id"), row.get("user_id"), row.get("username"), row.get("balance", 0)),
            )
        for perm in data.get("permissions", []):
            await self._execute(
                "INSERT INTO permissions (chat_id, user_id, role) VALUES (%s,%s,%s)",
                (perm.get("chat_id"), perm.get("user_id"), perm.get("role")),
            )
        for row in data.get("bans", []):
            await self._execute(
                "INSERT INTO banned_users (chat_id, user_id) VALUES (%s,%s)",
                (row.get("chat_id"), row.get("user_id")),
            )
        for claim in data.get("daily_claims", []):
            await self._execute(
                "INSERT INTO daily_claims (chat_id, user_id, last_claim) VALUES (%s,%s,%s)",
                (claim.get("chat_id"), claim.get("user_id"), claim.get("last_claim", 0)),
            )
        for item in data.get("shop_items", []):
            await self._execute(
                """
                INSERT INTO shop_items (id, chat_id, title, price, author_id, author_username, quantity)
                VALUES (%s,%s,%s,%s,%s,%s,%s)
                """,
                (
                    item.get("id"),
                    item.get("chat_id"),
                    item.get("title"),
                    item.get("price"),
                    item.get("author_id"),
                    item.get("author_username"),
                    item.get("quantity", 0),
                ),
            )
        for purchase in data.get("purchases", []):
            await self._execute(
                """
                INSERT INTO purchases (id, chat_id, buyer_id, buyer_username, title, price, seller_username, seller_id, created_at)
                VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)
                """,
                (
                    purchase.get("id"),
                    purchase.get("chat_id"),
                    purchase.get("buyer_id"),
                    purchase.get("buyer_username"),
                    purchase.get("title"),
                    purchase.get("price"),
                    purchase.get("seller_username"),
                    purchase.get("seller_id"),
                    purchase.get("created_at", int(time.time())),
                ),
            )
        for job in data.get("jobs", []):
            await self._execute(
                """
                INSERT INTO jobs (chat_id, user_id, job_code, job_name, base_salary, successes, failures, rating, job_rating, last_work, work_balance, quit_count, quit_window, job_blocked_until)
                VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
                """,
                (
                    job.get("chat_id"),
                    job.get("user_id"),
                    job.get("job_code"),
                    job.get("job_name"),
                    job.get("base_salary", 0),
                    job.get("successes", 0),
                    job.get("failures", 0),
                    job.get("rating", 0.0),
                    job.get("job_rating", 0.0),
                    job.get("last_work", 0),
                    job.get("work_balance", 0),
                    job.get("quit_count", 0),
                    job.get("quit_window", 0),
                    job.get("job_blocked_until", 0),
                ),
            )
        for owner in data.get("chat_owners", []):
            await self._execute(
                "INSERT INTO chat_owners (chat_id, owner_id) VALUES (%s,%s) ON DUPLICATE KEY UPDATE owner_id=VALUES(owner_id)",
                (owner.get("chat_id"), owner.get("owner_id")),
            )
        for plan in data.get("user_plans", []):
            await self._execute(
                """
                INSERT INTO user_plans (user_id, plan, expires_at, remind_at)
                VALUES (%s,%s,%s,%s)
                ON DUPLICATE KEY UPDATE plan=VALUES(plan), expires_at=VALUES(expires_at), remind_at=VALUES(remind_at)
                """,
                (
                    plan.get("user_id"),
                    plan.get("plan", PLAN_BASIC),
                    plan.get("expires_at", 0),
                    plan.get("remind_at", 0),
                ),
            )
        for redemption in data.get("promo_redemptions", []):
            await self._execute(
                "INSERT INTO promo_redemptions (user_id, code, redeemed_at) VALUES (%s,%s,%s)",
                (
                    redemption.get("user_id"),
                    redemption.get("code"),
                    redemption.get("redeemed_at", int(time.time())),
                ),
            )
        for lim in data.get("user_limits", []):
            await self._execute(
                """
                INSERT INTO user_limits (chat_id, user_id, day, transfer_total, credit_total)
                VALUES (%s,%s,%s,%s,%s)
                ON DUPLICATE KEY UPDATE
                    transfer_total=VALUES(transfer_total),
                    credit_total=VALUES(credit_total)
                """,
                (
                    lim.get("chat_id"),
                    lim.get("user_id"),
                    lim.get("day"),
                    lim.get("transfer_total", 0),
                    lim.get("credit_total", 0),
                ),
            )
        prefixes = data.get("prefixes", [])
        if prefixes:
            await self._execute("DELETE FROM chat_prefixes")
            values = ",".join(["(%s,%s)"] * len(prefixes))
            flat: list[Any] = []
            for row in prefixes:
                flat.extend([row.get("chat_id"), row.get("prefix")])
            await self._execute(f"INSERT INTO chat_prefixes (chat_id, prefix) VALUES {values}", flat)


async def safe_gather(*coroutines):
    return await asyncio.gather(*coroutines, return_exceptions=True)
