import asyncio
import html
import random
import secrets
import time
from typing import Any, Dict, Optional

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.constants import ParseMode
from telegram.ext import ContextTypes

from .storage import PLAN_MEDIUM

try:  # Pokerlib (poker) is optional but preferred for accurate combo ordering
    from poker.card import Card as PokerCard
    from poker.card import Rank as PokerRank
except Exception:  # pragma: no cover - optional dependency
    PokerCard = None
    PokerRank = None


class CasinoManager:
    MIN_BET = 500
    BET_WINDOW_SECONDS = 60 * 60 * 2
    BET_WINDOW_LIMIT = 5

    def __init__(self, bot, format_currency_func) -> None:
        self.bot = bot
        self.format_currency = format_currency_func
        self.roulette_tasks: dict[str, asyncio.Task] = {}
        self.slot_tasks: dict[str, asyncio.Task] = {}
        self.blackjack_games: dict[str, dict[str, Any]] = {}
        self.poker_tables: dict[str, dict[str, Any]] = {}
        self.poker_join_codes: dict[str, str] = {}
        self.poker_timeouts: dict[str, asyncio.Task] = {}
        self.bet_history: dict[tuple[int, int], list[float]] = {}
        self.bet_window_limit = 10 if getattr(getattr(bot, "settings", None), "test_mode", False) else self.BET_WINDOW_LIMIT

    @staticmethod
    def _card_value(card: str) -> int:
        rank = card[:-1]
        if rank in {"J", "Q", "K"}:
            return 10
        if rank == "A":
            return 11
        return int(rank)

    def _hand_value(self, cards: list[str]) -> int:
        total = sum(self._card_value(card) for card in cards)
        aces = sum(1 for c in cards if c.startswith("A"))
        while total > 21 and aces:
            total -= 10
            aces -= 1
        return total

    @staticmethod
    def _card_display(cards: list[str]) -> str:
        return " ".join(cards) if cards else "-"

    def _blackjack_status_text(self, player: list[str], dealer: list[str], *, reveal: bool = False) -> str:
        dealer_cards = dealer if reveal else dealer[:1] + ["❓"] * (len(dealer) - 1)
        player_val = self._hand_value(player)
        dealer_val = self._hand_value(dealer_cards) if reveal else "?"
        return (
            f"<b>Блэкджек</b>\n"
            f"Ваши карты ({player_val}): {self._card_display(player)}\n"
            f"Карты дилера ({dealer_val}): {self._card_display(dealer_cards)}"
        )

    @staticmethod
    def _new_deck() -> list[str]:
        suits = ["♠", "♥", "♦", "♣"]
        ranks = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"]
        deck = [f"{r}{s}" for s in suits for r in ranks]
        secrets.SystemRandom().shuffle(deck)
        return deck

    def _casino_delta_text(self, delta: int, currency: Dict[str, Any]) -> str:
        sign = "+" if delta >= 0 else "-"
        amount = self.format_currency(abs(delta), currency)
        return f"{sign}{amount}"

    def _blackjack_result(self, bet: int, player: list[str], dealer: list[str]) -> tuple[str, int]:
        player_val = self._hand_value(player)
        dealer_val = self._hand_value(dealer)
        if player_val > 21:
            return "Перебор! Вы проиграли.", -bet
        if len(player) == 2 and player_val == 21 and dealer_val != 21:
            return "Блэкджек!", int(bet * 1.5)
        if dealer_val > 21:
            return "Дилер перебрал — победа!", bet
        if player_val > dealer_val:
            return "Вы победили!", bet
        if player_val < dealer_val:
            return "Проигрыш.", -bet
        return "Ничья. Ставка возвращена.", 0

    def _can_place_bet(self, chat_id: int, user_id: int) -> tuple[bool, float]:
        now = time.time()
        key = (chat_id, user_id)
        history = [ts for ts in self.bet_history.get(key, []) if now - ts < self.BET_WINDOW_SECONDS]
        self.bet_history[key] = history
        if len(history) >= self.bet_window_limit:
            remaining = self.BET_WINDOW_SECONDS - (now - history[0])
            return False, max(0.0, remaining)
        return True, 0.0

    def _record_bet(self, chat_id: int, user_id: int) -> None:
        key = (chat_id, user_id)
        self.bet_history.setdefault(key, []).append(time.time())

    @staticmethod
    def _hidden_mentions(users: list[tuple[int, str]]) -> str:
        if not users:
            return ""
        # Используем невидимые ссылки, чтобы вызвать уведомления, но не засорять чат.
        return "".join(f"<a href=\"tg://user?id={uid}\">\u2060</a>" for uid, _ in users)

    def _blackjack_buttons(self, session_id: str, *, finished: bool = False) -> InlineKeyboardMarkup | None:
        if finished:
            return None
        return InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton("Ещё", callback_data=f"casino:bj:hit:{session_id}"),
                    InlineKeyboardButton("Стоп", callback_data=f"casino:bj:stand:{session_id}"),
                ],
                [InlineKeyboardButton("Сдаться", callback_data=f"casino:bj:surrender:{session_id}")],
            ]
        )

    async def _payout(self, chat_id: int, user_id: int, username: str, amount: int) -> Optional[int]:
        return await self.bot.ensure_storage().adjust_balance(chat_id, user_id, username, amount)

    async def _finish_roulette(
        self,
        context: ContextTypes.DEFAULT_TYPE,
        *,
        task_key: str,
        chat_id: int,
        user_id: int,
        username: str,
        bet_value: int,
        bet_label: str,
        bet_type: str,
        currency: Dict[str, Any],
        is_creator: bool,
    ) -> None:
        try:
            await asyncio.sleep(60)
            win_chance = 0.7 if is_creator else 0.3
            win = random.random() < win_chance
            if bet_type == "number":
                number = int(bet_label)
                rolled = number if win else random.choice([i for i in range(1, 37) if i != number])
                payout = bet_value * 3 if win else 0
                result_label = f"число {rolled}"
            else:
                colors = {"красный": "красное", "черный": "чёрное", "чёрный": "чёрное"}
                bet_color = bet_label.lower()
                chosen_color = bet_color if win else ("красный" if bet_color.startswith("чер") else "черный")
                payout = bet_value * 2 if win else 0
                result_label = colors.get(chosen_color, chosen_color)
            delta = payout - bet_value
            if payout:
                await self._payout(chat_id, user_id, username, payout)
            result_text = (
                "Ставка сыграна!\n"
                f"Результат: {result_label}\n"
                f"Итог: {self._casino_delta_text(delta, currency)}"
            )
            await self.bot._safe_send_message(
                context,
                chat_id=chat_id,
                text=result_text,
                parse_mode=ParseMode.HTML,
            )
            await self.bot.ensure_storage().log_event(
                chat_id,
                f"Рулетка: {self.bot.log_handle(username=username)} поставил {bet_label} на {self.format_currency(bet_value, currency)}. Итог {delta}",
            )
        finally:
            self.roulette_tasks.pop(task_key, None)

    async def _finish_slots(
        self,
        context: ContextTypes.DEFAULT_TYPE,
        *,
        task_key: str,
        chat_id: int,
        user_id: int,
        username: str,
        bet_value: int,
        currency: Dict[str, Any],
        message_id: int,
        is_creator: bool,
        ) -> None:
        try:
            symbols = [
                {"emoji": "🍒", "triple": 1.5, "weight": 0.25},
                {"emoji": "🍋", "triple": 1.6, "weight": 0.2},
                {"emoji": "🔔", "triple": 2.5, "weight": 0.18},
                {"emoji": "🍉", "triple": 3.0, "weight": 0.14},
                {"emoji": "⭐", "triple": 5.0, "weight": 0.12},
                {"emoji": "💎", "triple": 8.0, "weight": 0.11},
            ]
            win_roll = random.random()
            win = win_roll < (0.7 if is_creator else 0.3)

            def weighted_choice() -> dict:
                bucket: list[dict] = []
                for item in symbols:
                    bucket.extend([item] * max(1, int(item.get("weight", 1) * 100)))
                return random.choice(bucket)

            multiplier = 0.0
            if win:
                chosen = weighted_choice()
                spin = [chosen["emoji"]] * 3
                multiplier = chosen["triple"]
            else:
                pool = [sym["emoji"] for sym in symbols]
                spin = [random.choice(pool) for _ in range(3)]
                # гарантируем отсутствие тройки, чтобы соблюсти шанс выигрыша
                while len(set(spin)) == 1:
                    spin = [random.choice(pool) for _ in range(3)]

            reveal = [".", ".", "."]
            for idx in range(3):
                await asyncio.sleep(2)
                reveal[idx] = spin[idx]
                await self.bot._safe_edit_message(
                    context,
                    chat_id,
                    message_id,
                    "Слоты запущены:\n\n" + " ".join(reveal),
                )

            payout = int(bet_value * multiplier) if win else 0
            delta = payout - bet_value
            if payout:
                await self._payout(chat_id, user_id, username, payout)
            await self.bot._safe_edit_message(
                context,
                chat_id,
                message_id,
                "Слоты запущены:\n\n" + " ".join(spin),
            )
            outcome_text = "Вы проиграли" if delta < 0 else "Вы выиграли" if delta > 0 else "Ничья"
            await asyncio.sleep(3)
            await self.bot._safe_send_message(
                context,
                chat_id=chat_id,
                text=f"{outcome_text} {self._casino_delta_text(delta, currency)}",
                parse_mode=ParseMode.HTML,
            )
            await self.bot.ensure_storage().log_event(
                chat_id,
                f"Слоты: {self.bot.log_handle(username=username)} ставка {self.format_currency(bet_value, currency)} результат {delta}",
            )
        finally:
            self.slot_tasks.pop(task_key, None)

    async def _poker_broadcast(
        self,
        context: ContextTypes.DEFAULT_TYPE,
        session: dict[str, Any],
        text: str,
        *,
        exclude: Optional[set[int]] = None,
    ) -> None:
        exclude = exclude or set()
        for uid in session.get("players", {}):
            if uid in exclude:
                continue
            try:
                await context.bot.send_message(chat_id=uid, text=text)
            except Exception:
                continue

    async def _poker_betting_round(
        self,
        context: ContextTypes.DEFAULT_TYPE,
        session_id: str,
        stage: str,
    ) -> bool:
        session = self.poker_tables.get(session_id)
        if not session or session.get("status") != "active":
            return False
        active_players = session.setdefault("active_players", set(session.get("players", {}).keys()))
        store = self.bot.ensure_storage()
        order = list(active_players)
        random.shuffle(order)
        base_raise = max(self.MIN_BET, session.get("bet", self.MIN_BET))
        session["round_bets"] = {uid: 0 for uid in active_players}
        session["current_bid"] = 0
        await self._poker_broadcast(
            context,
            session,
            f"Раунд ставок ({stage}). Банк: {self.format_currency(session.get('pot', 0), session['currency'])}",
        )

        async def remove_player(uid: int, player: dict[str, Any], *, reason: str, block_seconds: int) -> None:
            active_players.discard(uid)
            player["removed"] = True
            if block_seconds:
                await store.set_cooldown(f"poker_block:{session['chat_id']}:{uid}", block_seconds)
            session.setdefault("log", []).append(reason)
            await self._poker_broadcast(context, session, reason)

        prompt_meta = session.setdefault("prompt_meta", {})

        async def refresh_prompts(exclude: Optional[int] = None) -> None:
            for pid, msg_id in list(session.get("turn_messages", {}).items()):
                if exclude and pid == exclude:
                    continue
                if pid not in active_players:
                    continue
                round_bet = session.get("round_bets", {}).get(pid, 0)
                required_call = max(0, session.get("current_bid", 0) - round_bet)
                prompt_kind = prompt_meta.get(pid, "turn")
                try:
                    if prompt_kind == "confirm":
                        await context.bot.edit_message_text(
                            chat_id=pid,
                            message_id=msg_id,
                            text=(
                                "Принять ставку?\n"
                                f"Нужно поддержать: {self.format_currency(required_call, session['currency'])}"
                            ),
                            reply_markup=InlineKeyboardMarkup(
                                [
                                    [
                                        InlineKeyboardButton("Да", callback_data=f"casino:pkr:act:{session_id}:call"),
                                        InlineKeyboardButton("Нет", callback_data=f"casino:pkr:act:{session_id}:fold"),
                                        InlineKeyboardButton(
                                            "Повысить ещё", callback_data=f"casino:pkr:act:{session_id}:raise"
                                        ),
                                    ]
                                ]
                            ),
                        )
                    else:
                        updated_keyboard = [
                            [
                                InlineKeyboardButton("Поднять", callback_data=f"casino:pkr:act:{session_id}:raise"),
                                InlineKeyboardButton(
                                    "Поддержать" if required_call else "Чек",
                                    callback_data=f"casino:pkr:act:{session_id}:{'call' if required_call else 'check'}",
                                ),
                            ],
                            [InlineKeyboardButton("Вскрыться", callback_data=f"casino:pkr:act:{session_id}:fold")],
                        ]
                        await context.bot.edit_message_text(
                            chat_id=pid,
                            message_id=msg_id,
                            text=(
                                f"Ваш ход в раунде {stage}. Банка сейчас: {self.format_currency(session.get('pot', 0), session['currency'])}.\n"
                                f"Текущая ставка: {self.format_currency(session.get('current_bid', 0), session['currency'])}."
                                + (f" Нужно поддержать: {self.format_currency(required_call, session['currency'])}" if required_call else "")
                            ),
                            reply_markup=InlineKeyboardMarkup(updated_keyboard),
                        )
                except Exception:
                    continue

        queue = [uid for uid in order if uid in active_players]
        last_raiser: Optional[int] = None

        def append_action_log(msg: str) -> None:
            pot_label = self.format_currency(session.get("pot", 0), session["currency"])
            session.setdefault("log", []).append(f"{msg} (банк: {pot_label})")

        while queue and len(active_players) > 1:
            uid = queue.pop(0)
            if uid not in active_players:
                continue
            player = session["players"].get(uid)
            if not player:
                continue
            last_seen = session.setdefault("last_activity", {}).get(uid, time.time())
            if time.time() - last_seen > 300:
                await remove_player(
                    uid,
                    player,
                    reason=(
                        f"Игрок @{player['username']} выбыл за бездействие (5 минут). "
                        "Доступ к покеру ограничен на 6 часов."
                    ),
                    block_seconds=6 * 3600,
                )
                if len(active_players) <= 1:
                    return True
                continue
            current_bid = session.get("current_bid", 0)
            round_bet = session.get("round_bets", {}).get(uid, 0)
            required_call = max(0, current_bid - round_bet)
            event = asyncio.Event()
            session.setdefault("waiters", {})[uid] = event
            session.setdefault("decisions", {})
            default_keyboard = [
                [
                    InlineKeyboardButton("Поднять", callback_data=f"casino:pkr:act:{session_id}:raise"),
                    InlineKeyboardButton(
                        "Поддержать" if required_call else "Чек",
                        callback_data=f"casino:pkr:act:{session_id}:{'call' if required_call else 'check'}",
                    ),
                ],
                [InlineKeyboardButton("Вскрыться", callback_data=f"casino:pkr:act:{session_id}:fold")],
            ]
            needs_confirmation = required_call > 0 and round_bet < current_bid
            try:
                confirm_markup = InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton("Да", callback_data=f"casino:pkr:act:{session_id}:call"),
                            InlineKeyboardButton("Нет", callback_data=f"casino:pkr:act:{session_id}:fold"),
                            InlineKeyboardButton("Повысить ещё", callback_data=f"casino:pkr:act:{session_id}:raise"),
                        ]
                    ]
                )
                turn_message_id = None
                if needs_confirmation:
                    sent_confirm = await context.bot.send_message(
                        chat_id=uid,
                        text=(
                            "Принять ставку?\n"
                            f"Нужно поддержать: {self.format_currency(required_call, session['currency'])}"
                        ),
                        reply_markup=confirm_markup,
                    )
                    turn_message_id = sent_confirm.message_id
                    prompt_meta[uid] = "confirm"
                if not needs_confirmation or session.get("current_bid", 0) == 0:
                    sent = await context.bot.send_message(
                        chat_id=uid,
                        text=(
                            f"Ваш ход в раунде {stage}. Банка сейчас: {self.format_currency(session.get('pot', 0), session['currency'])}.\n"
                            f"Текущая ставка: {self.format_currency(session.get('current_bid', 0), session['currency'])}."
                            + (f" Нужно поддержать: {self.format_currency(required_call, session['currency'])}" if required_call else "")
                        ),
                        reply_markup=InlineKeyboardMarkup(default_keyboard),
                    )
                    turn_message_id = sent.message_id
                    prompt_meta[uid] = "turn"
                if turn_message_id:
                    session.setdefault("turn_messages", {})[uid] = turn_message_id
            except Exception:
                event.set()
            decision = None
            for _ in range(2):
                try:
                    await asyncio.wait_for(event.wait(), timeout=30)
                    decision = session.get("decisions", {}).pop(uid, "check")
                    break
                except asyncio.TimeoutError:
                    # Если игрок выбрал повышение, даём дополнительное время на ввод суммы.
                    if session.get("pending_raises", {}).get(uid):
                        continue
                    decision = "fold" if required_call > 0 else "check"
                    break
            if decision is None:
                decision = "fold" if required_call > 0 else "check"
            session.get("waiters", {}).pop(uid, None)
            session.get("turn_messages", {}).pop(uid, None)
            prompt_meta.pop(uid, None)

            if isinstance(decision, tuple):
                action, amount_value = decision
            else:
                action, amount_value = decision, None

            if action in {"fold", "auto_fold"}:
                reason = "не поддержал ставку и вскрылся" if action in {"auto_fold", "fold"} and required_call > 0 else "решил вскрыться и выбыл"
                await remove_player(uid, player, reason=f"Игрок @{player['username']} {reason}.", block_seconds=0)
            elif action == "raise":
                token_amount = amount_value
                token_is_all = False
                if isinstance(token_amount, str):
                    parsed_amount, token_is_all = self.bot.parse_amount_token(str(token_amount))
                    amount_value = parsed_amount
                min_total = max(base_raise, session.get("current_bid", 0) + (base_raise if session.get("current_bid", 0) else 0))
                if token_is_all:
                    balance_left = await store.get_balance(session["chat_id"], uid)
                    amount_value = max(min_total, min(balance_left + session.get("round_bets", {}).get(uid, 0), self.bot.MAX_TRANSACTION))
                amount_value = amount_value or min_total
                if amount_value <= session.get("current_bid", 0):
                    amount_value = session.get("current_bid", 0) + base_raise
                additional = amount_value - session.get("round_bets", {}).get(uid, 0)
                if additional <= 0:
                    additional = required_call
                updated = await store.adjust_balance(session["chat_id"], uid, player["username"], -additional)
                if updated is None:
                    await remove_player(
                        uid,
                        player,
                        reason=(
                            f"Игрок @{player['username']} вылетел: недостаточно средств для ставки. "
                            "Доступ к покеру заблокирован на сутки."
                        ),
                        block_seconds=24 * 3600,
                    )
                else:
                    session["pot"] = session.get("pot", 0) + additional
                    session.setdefault("round_bets", {})[uid] = amount_value
                    session["current_bid"] = max(session.get("current_bid", 0), amount_value)
                    action_name = "бет" if session.get("current_bid", 0) == amount_value and required_call == 0 and last_raiser is None else "рейз"
                    msg = (
                        f"Игрок @{player['username']} сделал {action_name} {self.format_currency(amount_value, session['currency'])}"
                        f" (to call {self.format_currency(session.get('current_bid', 0), session['currency'])})."
                    )
                    append_action_log(msg)
                    await self._poker_broadcast(context, session, msg)
                    session.setdefault("last_activity", {})[uid] = time.time()
                    last_raiser = uid
                    queue = [p for p in order if p in active_players and p != uid]
                    await refresh_prompts(exclude=uid)
            elif action in {"check", "call"}:
                if required_call > 0:
                    additional = required_call
                    updated = await store.adjust_balance(
                        session["chat_id"], uid, player["username"], -additional
                    )
                    if updated is None:
                        await remove_player(
                            uid,
                            player,
                            reason=(
                                f"Игрок @{player['username']} выбыл: не хватило средств для поддержки ставки. "
                                "Доступ к покеру заблокирован на сутки."
                            ),
                            block_seconds=24 * 3600,
                        )
                    else:
                        session["pot"] = session.get("pot", 0) + additional
                        session.setdefault("round_bets", {})[uid] = session.get("current_bid", 0)
                        msg = (
                            f"Игрок @{player['username']} сделал колл {self.format_currency(session.get('current_bid', 0), session['currency'])}"
                            f" (to call {self.format_currency(required_call, session['currency'])})."
                        )
                        append_action_log(msg)
                        await self._poker_broadcast(context, session, msg)
                        session.setdefault("last_activity", {})[uid] = time.time()
                else:
                    append_action_log(f"Игрок @{player['username']} сделал чек.")
                    session.setdefault("last_activity", {})[uid] = time.time()
            if len(active_players) <= 1:
                return True
            if not queue and last_raiser is None:
                break
            if not queue and last_raiser is not None:
                # все уравняли ставку после последнего рейза
                break
        session.setdefault("log", []).append(
            f"Раунд {stage} завершён. Банк: {self.format_currency(session.get('pot', 0), session['currency'])}"
        )
        return False
    async def _poker_timeout(self, context: ContextTypes.DEFAULT_TYPE, session_id: str) -> None:
        await asyncio.sleep(300)
        session = self.poker_tables.get(session_id)
        if not session or session.get("status") != "search":
            return
        players = session.get("players", {})
        joined = len(players)
        if joined >= 3:
            session["max_players"] = min(session.get("max_players", joined), joined)
            await self.bot._safe_send_message(
                context,
                chat_id=session["chat_id"],
                text=f"Набрано {joined} игрока/ов. Стартуем через 30 секунд.",
                parse_mode=ParseMode.HTML,
            )
            await self._start_poker_countdown(context, session_id)
            return

        session["status"] = "closed"
        store = self.bot.ensure_storage()
        for uid, player in players.items():
            await store.adjust_balance(session["chat_id"], uid, player["username"], session["bet"])
        await self._poker_clear_invite(context, session)
        await self.bot._safe_send_message(
            context,
            chat_id=session["chat_id"],
            text="Набор в покер не завершён за 5 минут. Игра отменена (Закрыт).",
            parse_mode=ParseMode.HTML,
        )
        self.poker_tables.pop(session_id, None)
        self.poker_join_codes = {code: sid for code, sid in self.poker_join_codes.items() if sid != session_id}

    async def _start_poker_countdown(self, context: ContextTypes.DEFAULT_TYPE, session_id: str) -> None:
        session = self.poker_tables.get(session_id)
        if not session or session.get("status") != "search":
            return
        session["status"] = "countdown"
        await self.bot._safe_send_message(
            context,
            chat_id=session["chat_id"],
            text="Игра начнется через 30 секунд.",
            parse_mode=ParseMode.HTML,
        )
        await self._poker_broadcast(context, session, "Игра скоро начнется (30 секунд). Готовьте решения!")
        await asyncio.sleep(30)
        if session.get("status") != "countdown":
            return
        await self._launch_poker_round(context, session_id)

    def _poker_hand_score(
        self, hand: list[str], community: list[str]
    ) -> tuple[tuple[int, ...], str, list[str], list[str]]:
        from itertools import combinations

        def normalize(card: str) -> str:
            card = card.strip()
            rank, suit = card[:-1], card[-1]
            if rank == "10":
                rank = "T"
            return f"{rank}{suit}"

        def rank_val(card: str) -> int:
            rank = card[:-1]
            mapping = {"J": 11, "Q": 12, "K": 13, "A": 14, "T": 10}
            if PokerRank:
                try:
                    return PokerRank(rank).value[1] if isinstance(PokerRank(rank).value, tuple) else int(PokerRank(rank).value)
                except Exception:
                    pass
            return mapping.get(rank, int(rank) if rank.isdigit() else 0)

        def evaluate(cards: tuple[str, ...]) -> tuple[tuple[int, ...], dict[str, Any]]:
            values = sorted([rank_val(c) for c in cards], reverse=True)
            suits = [c[-1] for c in cards]
            counts: dict[int, int] = {}
            for v in values:
                counts[v] = counts.get(v, 0) + 1
            ordered = sorted(counts.items(), key=lambda x: (-x[1], -x[0]))
            is_flush = len(set(suits)) == 1

            uniq_values = sorted(set(values), reverse=True)
            straight_high = 0
            for i in range(len(uniq_values) - 4 + 1):
                window = uniq_values[i : i + 5]
                if len(window) < 5:
                    continue
                if window[0] - window[-1] == 4:
                    straight_high = window[0]
                    break
            if {14, 5, 4, 3, 2}.issubset(set(values)):
                straight_high = max(straight_high, 5)
            is_straight = straight_high > 0

            royal = is_flush and is_straight and {14, 13, 12, 11, 10}.issubset(set(values))
            if royal:
                score = (9,)
                payload = {"label": "флеш-рояль"}
            elif is_flush and is_straight:
                score = (8, straight_high)
                payload = {"label": "стрит-флеш", "high": straight_high}
            elif ordered[0][1] == 4:
                quad = ordered[0][0]
                kicker = max(v for v in values if v != quad)
                score = (7, quad, kicker)
                payload = {"label": "каре", "quad": quad, "kickers": [kicker]}
            elif ordered[0][1] == 3 and ordered[1][1] >= 2:
                triples = [val for val, cnt in ordered if cnt == 3]
                pairs = [val for val, cnt in ordered if cnt >= 2 and val not in triples]
                triple = max(triples)
                pair = max(pairs)
                score = (6, triple, pair)
                payload = {"label": "фулл-хаус", "triple": triple, "pair": pair}
            elif is_flush:
                score = (5, *values)
                payload = {"label": "флэш", "kickers": values}
            elif is_straight:
                score = (4, straight_high)
                payload = {"label": "стрит", "high": straight_high}
            elif ordered[0][1] == 3:
                triple = ordered[0][0]
                kickers = [v for v in values if v != triple][:2]
                score = (3, triple, *kickers)
                payload = {"label": "трипс", "triple": triple, "kickers": kickers}
            elif ordered[0][1] == 2 and ordered[1][1] == 2:
                high_pair, low_pair = ordered[0][0], ordered[1][0]
                kicker = max(v for v in values if v not in {high_pair, low_pair})
                score = (2, high_pair, low_pair, kicker)
                payload = {"label": "две пары", "pairs": [high_pair, low_pair], "kickers": [kicker]}
            elif ordered[0][1] == 2:
                pair = ordered[0][0]
                kickers = [v for v in values if v != pair][:3]
                score = (1, pair, *kickers)
                payload = {"label": "пара", "pair": pair, "kickers": kickers}
            else:
                score = (0, *values)
                payload = {"label": "старшая карта", "kickers": values}
            payload["counts"] = counts
            payload["cards"] = cards
            return score, payload

        all_cards = [normalize(c) for c in hand + community if c]
        parsed_cards = []
        hand_normalized = {normalize(c) for c in hand if c}
        for c in all_cards:
            if PokerCard:
                try:
                    parsed_cards.append(str(PokerCard(c)))
                    continue
                except Exception:
                    pass
            parsed_cards.append(c)

        best_score: tuple[int, ...] = (-1,)
        best_label = "старшая карта"
        best_combo: list[str] = []
        best_payload: dict[str, Any] = {}
        for combo in combinations(parsed_cards, 5):
            score, payload = evaluate(combo)
            if score > best_score:
                best_score = score
                best_label = payload.get("label", "старшая карта")
                best_combo = list(combo)
                best_payload = payload
        display_combo = []
        for card in best_combo:
            rank, suit = card[:-1], card[-1]
            if rank == "T":
                rank = "10"
            display_combo.append(f"{rank}{suit}")

        board_set = set(normalize(c) for c in community if c)
        combo_set = set(best_combo)
        only_board = combo_set.issubset(board_set)
        def display_rank(value: int) -> str:
            mapping = {11: "J", 12: "Q", 13: "K", 14: "A", 10: "10"}
            return mapping.get(value, str(value))

        kicker_values = best_payload.get("kickers", [])
        kicker_names = [display_rank(v) for v in kicker_values]

        # уточняем сет/трипс
        if best_payload.get("label") == "трипс":
            triple_rank = best_payload.get("triple")
            pocket_count = sum(1 for c in hand if rank_val(normalize(c)) == triple_rank)
            if pocket_count == 2:
                best_label = "сет"
            else:
                best_label = "трипс"

        pair_label = None
        if best_payload.get("label") == "пара":
            pair_rank = best_payload.get("pair")
            pair_cards = [c for c in best_combo if rank_val(normalize(c)) == pair_rank]
            pair_from_hand = any(normalize(c) in hand_normalized for c in pair_cards)
            pair_label = "пара с руки" if pair_from_hand else "пара на борде"
            pair_name = display_rank(pair_rank)
            best_label = f"{pair_label}: {pair_name}"
        elif best_payload.get("label") == "две пары":
            pairs = [display_rank(v) for v in best_payload.get("pairs", [])]
            best_label = f"две пары: {' и '.join(pairs)}"
        elif best_payload.get("label") == "каре":
            quad = display_rank(best_payload.get("quad"))
            best_label = f"каре {quad}"
        elif best_payload.get("label") == "фулл-хаус":
            best_label = f"фулл-хаус: {display_rank(best_payload.get('triple'))} фулл {display_rank(best_payload.get('pair'))}"
        elif best_payload.get("label") == "трипс" or best_label == "сет":
            best_label = f"{best_label}: {display_rank(best_payload.get('triple'))}"
        elif best_payload.get("label") == "стрит":
            best_label = f"стрит до {display_rank(best_payload.get('high'))}"
        elif best_payload.get("label") == "стрит-флеш":
            best_label = f"стрит-флеш до {display_rank(best_payload.get('high'))}"
        elif best_payload.get("label") == "флеш":
            best_label = "флеш"
        elif best_payload.get("label") == "старшая карта":
            best_label = f"старшая карта: {display_rank(kicker_values[0])}" if kicker_values else best_label

        if only_board and best_label != "флеш-рояль":
            best_label = f"борд играет — {best_label}"

        if kicker_names:
            best_label = f"{best_label}, кикер{'ы' if len(kicker_names) > 1 else ''} {' '.join(kicker_names)}"
        return best_score, best_label, display_combo, kicker_names

    async def _poker_clear_invite(self, context: ContextTypes.DEFAULT_TYPE, session: dict[str, Any]) -> None:
        chat_id = session.get("chat_id")
        invite_id = session.pop("invite_message_id", None)
        if chat_id and invite_id:
            try:
                await context.bot.unpin_chat_message(chat_id, invite_id)
            except Exception:
                pass
            try:
                await context.bot.delete_message(chat_id, invite_id)
            except Exception:
                pass

    async def _launch_poker_round(self, context: ContextTypes.DEFAULT_TYPE, session_id: str) -> None:
        session = self.poker_tables.get(session_id)
        if not session or session.get("status") not in {"countdown", "search"}:
            return
        players = session.get("players", {})
        if len(players) < 2:
            session["status"] = "closed"
            await self._poker_clear_invite(context, session)
            await self.bot._safe_send_message(
                context,
                chat_id=session["chat_id"],
                text="Покер не состоялся: не хватило игроков.",
            )
            for uid, player in players.items():
                await self.bot.ensure_storage().adjust_balance(session["chat_id"], uid, player["username"], session["bet"])
            self.poker_tables.pop(session_id, None)
            self.poker_join_codes = {code: sid for code, sid in self.poker_join_codes.items() if sid != session_id}
            return

        deck = self._new_deck()
        session["status"] = "active"
        session["deck"] = deck
        session["log"] = ["Начало игры."]
        session["reveals"] = {}
        session["active_players"] = set(players.keys())
        session["waiters"] = {}
        session["decisions"] = {}
        session["community"] = []
        session["last_activity"] = {uid: time.time() for uid in players}
        session["pinned_cards"] = {}
        await self._poker_clear_invite(context, session)

        for uid, player in players.items():
            if len(deck) < 2:
                break
            hand = [deck.pop(), deck.pop()]
            player["hand"] = hand
            await context.bot.send_message(chat_id=uid, text="<i>Подбор карт...</i>", parse_mode=ParseMode.HTML)
            await asyncio.sleep(3)
            cards_line = f"{hand[0]} {hand[1]}"
            dealt = await context.bot.send_message(
                chat_id=uid,
                text=f"<b>Ваши карты</b>\n<code>{cards_line}</code>",
                parse_mode=ParseMode.HTML,
            )
            session.setdefault("pinned_cards", {})[uid] = dealt.message_id
            try:
                await context.bot.pin_chat_message(chat_id=uid, message_id=dealt.message_id)
            except Exception:
                pass

        # Раунд ставок перед флопом
        finished = await self._poker_betting_round(context, session_id, "префлоп")
        if finished:
            await self._finish_poker(context, session_id)
            return

        async def deal_cards(count: int, label: str) -> bool:
            community = session.setdefault("community", [])
            cards = []
            for _ in range(count):
                if not deck:
                    break
                cards.append(deck.pop())
            community.extend(cards)
            card_line = " ".join(cards)
            session.setdefault("log", []).append(f"{label}: {card_line}")
            await self._poker_broadcast(
                context,
                session,
                f"{label}: {card_line}. Общие карты: {' '.join(community)}",
            )
            finished_stage = await self._poker_betting_round(context, session_id, label.lower())
            return finished_stage

        if await deal_cards(3, "Флоп"):
            await self._finish_poker(context, session_id)
            return
        if await deal_cards(1, "Тёрн"):
            await self._finish_poker(context, session_id)
            return
        await deal_cards(1, "Ривер")
        await self._finish_poker(context, session_id)

    async def _publish_poker_log_later(self, context: ContextTypes.DEFAULT_TYPE, session_id: str) -> None:
        await asyncio.sleep(30)
        await self._publish_poker_log(context, session_id)

    async def _finish_poker(self, context: ContextTypes.DEFAULT_TYPE, session_id: str) -> None:
        session = self.poker_tables.get(session_id)
        if not session or session.get("status") == "finished":
            return
        session["status"] = "finished"
        players = session.get("players", {})
        active_players = session.get("active_players", set(players.keys()))
        community = session.get("community", [])
        log_lines = session.setdefault("log", [])

        scores: dict[int, tuple[tuple[int, ...], str, list[str], list[str]]] = {}
        best_score = (-1,)
        winners: list[int] = []
        for uid in active_players:
            player = players.get(uid)
            if not player:
                continue
            result = self._poker_hand_score(player.get("hand", []), community)
            scores[uid] = result
            score_tuple = result[0]
            if score_tuple > best_score:
                best_score = score_tuple
                winners = [uid]
            elif score_tuple == best_score:
                winners.append(uid)

        pot = session.get("pot", 0)
        winner_lines = []
        if winners:
            share = pot // len(winners) if pot else 0
            remainder = pot - share * len(winners)
            for idx, uid in enumerate(winners):
                player = players.get(uid)
                if not player:
                    continue
                _, combo_label, _, _ = scores.get(uid, ((-1,), "", [], []))
                label_suffix = f" ({combo_label})" if combo_label and combo_label != "старшая карта" else ""
                winner_lines.append(f"@{player['username']}{label_suffix}")
                payout_share = share + (remainder if idx == 0 else 0)
                if payout_share:
                    await self._payout(session["chat_id"], uid, player["username"], payout_share)
            log_lines.append(
                f"Победил {', '.join(winner_lines)} и забрал банк {self.format_currency(pot, session['currency'])}"
            )
            await self.bot.ensure_storage().log_event(
                session["chat_id"],
                f"Покер: {', '.join(winner_lines)} выиграл(и) банк {self.format_currency(pot, session['currency'])}",
            )
        else:
            log_lines.append("Банк остался без победителя.")
        session["winner"] = winners[0] if winners else None
        session["hand_scores"] = scores
        board_line = " ".join(community) if community else "-"
        winners_text = ", ".join(winner_lines) if winner_lines else "—"
        for uid, player in players.items():
            personal = scores.get(uid)
            combo_desc = personal[1] if personal else "-"
            try:
                await context.bot.send_message(
                    chat_id=uid,
                    text=(
                        "<b>Итоги покера</b>\n"
                        f"Общие карты: <code>{html.escape(board_line)}</code>\n"
                        f"Ваша комбинация: <b>{html.escape(combo_desc)}</b>\n"
                        f"Победитель: <b>{html.escape(winners_text)}</b>\n"
                        f"Банк: {self.format_currency(pot, session['currency'])}"
                    ),
                    parse_mode=ParseMode.HTML,
                )
            except Exception:
                continue
        reveal_keyboard = InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton("Да", callback_data=f"casino:pkr:reveal:{session_id}:yes"),
                    InlineKeyboardButton("Нет", callback_data=f"casino:pkr:reveal:{session_id}:no"),
                ]
            ]
        )
        for uid in players:
            try:
                await context.bot.send_message(
                    chat_id=uid,
                    text="Хотите ли вы отобразить ваши карты?",
                    reply_markup=reveal_keyboard,
                )
            except Exception:
                continue
        self.poker_timeouts[session_id] = asyncio.create_task(self._publish_poker_log_later(context, session_id))

    async def _publish_poker_log(self, context: ContextTypes.DEFAULT_TYPE, session_id: str) -> None:
        session = self.poker_tables.get(session_id)
        if not session or session.get("status") != "finished":
            return
        players = session.get("players", {})
        reveals = session.setdefault("reveals", {})
        for uid in players:
            reveals.setdefault(uid, True)
        pinned_cards = session.get("pinned_cards", {})
        for uid, pinned_id in pinned_cards.items():
            try:
                await context.bot.unpin_chat_message(chat_id=uid, message_id=pinned_id)
            except Exception:
                continue
        log_lines = list(session.get("log", []))
        community = session.get("community", [])
        if community and not any(line.startswith("Общие карты:") for line in log_lines):
            log_lines.append(f"Общие карты: {' '.join(community)}")
        log_lines.append("Карты игроков:")
        for uid, player in players.items():
            reveal = session.get("reveals", {}).get(uid)
            cards = player.get("hand", [])
            combo_info = session.get("hand_scores", {}).get(uid)
            combo_label = combo_info[1] if combo_info else None
            if reveal:
                cards_text = " ".join(cards) if cards else "-"
            else:
                cards_text = "Игрок предпочел скрыть свои карты"
            suffix = f" ({combo_label})" if combo_label else ""
            log_lines.append(f"Карты @{player['username']}: {cards_text}{suffix}")
        text = "\n".join(log_lines)
        await self.bot._safe_send_message(context, chat_id=session["chat_id"], text=text, parse_mode=ParseMode.HTML)
        self.poker_tables.pop(session_id, None)
        self.poker_join_codes = {code: sid for code, sid in self.poker_join_codes.items() if sid != session_id}
        timeout_task = self.poker_timeouts.pop(session_id, None)
        if timeout_task:
            timeout_task.cancel()

    async def _poker_reveal(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE, *, session_id: str, choice: str
    ) -> None:
        session = self.poker_tables.get(session_id)
        if not session or session.get("status") != "finished":
            return
        user = update.effective_user
        if not user:
            return
        players = session.get("players", {})
        if user.id not in players:
            await update.callback_query.answer("Вы не участвуете в этой игре", show_alert=True)
            return
        session.setdefault("reveals", {})[user.id] = choice == "yes"
        await update.callback_query.edit_message_text(
            "Ваш выбор сохранён." + (" Ваши карты будут отображены в логах." if choice == "yes" else ""),
        )
        if len(session.get("reveals", {})) == len(players):
            await self._publish_poker_log(context, session_id)

    async def _poker_action(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE, *, session_id: str, action: str
    ) -> None:
        session = self.poker_tables.get(session_id)
        if not session or session.get("status") != "active":
            return
        user = update.effective_user
        if not user:
            return
        waiters = session.get("waiters", {})
        if user.id not in waiters:
            await update.callback_query.answer("Сейчас не ваш ход", show_alert=True)
            return
        if action == "raise":
            min_raise = max(session.get("bet", self.MIN_BET), session.get("current_bid", 0))
            prompt_id = session.get("turn_messages", {}).get(user.id)
            session.setdefault("pending_raises", {})[user.id] = {
                "event": waiters.get(user.id),
                "session": session_id,
                "prompt_id": prompt_id,
                "min_raise": min_raise,
            }
            self.bot.pending_actions[user.id] = {
                "action": "poker_raise",
                "session_id": session_id,
                "prompt_id": prompt_id,
                "min_raise": min_raise,
            }
            await update.callback_query.edit_message_text(
                f"Укажи сумму повышения (не меньше {self.format_currency(min_raise, session['currency'])}). "
                "Ответь на это сообщение числом.",
            )
            return
        session.setdefault("decisions", {})[user.id] = action
        waiter = waiters.get(user.id)
        if waiter:
            waiter.set()
        await update.callback_query.edit_message_text(
            f"Действие принято: {action}",
        )

    async def _join_poker(
        self,
        context: ContextTypes.DEFAULT_TYPE,
        *,
        session_id: str,
        user,
        username: str,
    ) -> tuple[bool, str]:
        session = self.poker_tables.get(session_id)
        if not session or session.get("status") not in {"search", "countdown"}:
            return False, "Игра закрыта."
        players = session.setdefault("players", {})
        if user.id in players:
            return True, "Вы уже участвуете в этой игре."
        if len(players) >= session.get("max_players", 6):
            return False, "Свободных мест нет."
        store = self.bot.ensure_storage()
        ok, remaining = self._can_place_bet(session["chat_id"], user.id)
        if not ok:
            minutes = int(remaining // 60) + 1
            return False, f"Достигнут лимит ставок. Подожди ~{minutes} мин."
        remaining_block = await store.cooldown_remaining(f"poker_block:{session['chat_id']}:{user.id}")
        if remaining_block > 0:
            minutes = max(1, remaining_block // 60)
            return False, f"Доступ к покеру заблокирован на {minutes} мин."
        bet = session.get("bet", self.MIN_BET)
        updated = await store.adjust_balance(session["chat_id"], user.id, username, -bet)
        if updated is None:
            return False, "Недостаточно средств для ставки."
        players[user.id] = {"username": username, "hand": [], "reveal": None}
        session["pot"] = session.get("pot", 0) + bet
        self._record_bet(session["chat_id"], user.id)
        joined = len(players)
        total = session.get("max_players", 0)
        await context.bot.send_message(
            chat_id=user.id,
            text=f"Вы присоединились к игре. {joined}/{total}",
        )
        await self._poker_broadcast(
            context,
            session,
            f"Игрок @{username} присоединился ({joined}/{total})",
            exclude={user.id},
        )
        session.setdefault("last_activity", {})[user.id] = time.time()
        if session.get("status") == "search" and joined >= total:
            asyncio.create_task(self._start_poker_countdown(context, session_id))
        return True, "Вы в игре"

    async def join_poker_from_private(
        self, context: ContextTypes.DEFAULT_TYPE, *, code: str, user
    ) -> bool:
        session_id = self.poker_join_codes.get(code)
        if not session_id:
            return False
        username = user.username or user.full_name or str(user.id)
        ok, reason = await self._join_poker(context, session_id=session_id, user=user, username=username)
        if not ok:
            await context.bot.send_message(chat_id=user.id, text=reason)
        return ok

    async def handle_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        query = update.callback_query
        self.bot._remember_thread(update)
        if not query or not query.data:
            return
        if update.effective_chat and update.effective_chat.type != "private":
            if not self.bot._is_group_unlocked(update.effective_chat.id):
                return
        if await self.bot._should_skip_update(update):
            return
        await self.bot._mark_update_processed(update)
        await query.answer()
        parts = query.data.split(":")
        if len(parts) < 3:
            return
        game_code = parts[1]
        if game_code == "pkr":
            if parts[2] == "reveal" and len(parts) >= 5:
                session_id = ":".join(parts[3:-1])
                choice = parts[-1]
                await self._poker_reveal(update, context, session_id=session_id, choice=choice)
            elif parts[2] == "act" and len(parts) >= 5:
                session_id = ":".join(parts[3:-1])
                action = parts[-1]
                await self._poker_action(update, context, session_id=session_id, action=action)
            return
        if game_code != "bj":
            return
        action = parts[2]
        session_id = ":".join(parts[3:])
        session = self.blackjack_games.get(session_id)
        if not session:
            await query.answer("Игра завершена", show_alert=True)
            return
        chat_id = session["chat_id"]
        if update.effective_chat and update.effective_chat.id != chat_id:
            return
        store = self.bot.ensure_storage()
        if await store.is_blocked(chat_id) and not self.bot.ensure_creator(update):
            await query.answer(
                "Ваша группа неожиданно разорвала соединение с ботом. Код ошибки: POSHEL_NAHUY",
                show_alert=True,
            )
            return
        if await store.is_banned(chat_id, query.from_user.id):
            await query.answer("Команда не распознана. Попробуй !!poshel naxui", show_alert=True)
            return
        if query.from_user.id != session["user_id"] and not self.bot.ensure_creator(update):
            await query.answer("Эта игра не для вас", show_alert=True)
            return
        player = session["player"]
        dealer = session["dealer"]
        deck = session["deck"]
        currency = session["currency"]
        bet = session["bet"]
        message_id = session["message_id"]
        finished = False

        if action == "hit":
            if not deck:
                deck.extend(self._new_deck())
            player.append(deck.pop())
            status = self._blackjack_status_text(player, dealer, reveal=False)
            if self._hand_value(player) >= 21:
                finished = True
        elif action == "stand":
            while self._hand_value(dealer) < 17:
                dealer.append(deck.pop())
            status = self._blackjack_status_text(player, dealer, reveal=True)
            finished = True
        elif action == "surrender":
            status = self._blackjack_status_text(player, dealer, reveal=True)
            delta = -(bet // 2)
            await self.bot._safe_send_message(
                context,
                chat_id=chat_id,
                text=f"Вы сдались. Итог: {self._casino_delta_text(delta, currency)}",
                parse_mode=ParseMode.HTML,
            )
            await store.log_event(
                chat_id,
                f"Блэкджек: {self.bot.log_handle(username=session['username'])} сдался. Итог {delta}",
            )
            self.blackjack_games.pop(session_id, None)
            await self.bot._safe_edit_message(
                context,
                chat_id,
                message_id,
                status + "\n\nИгра завершена",
                markup=None,
            )
            return
        else:
            return

        delta = 0
        if finished:
            status = self._blackjack_status_text(player, dealer, reveal=True)
            result_text, delta = self._blackjack_result(bet, player, dealer)
            if delta > 0:
                await self._payout(chat_id, session["user_id"], session["username"], bet + delta)
            elif delta == 0:
                await self._payout(chat_id, session["user_id"], session["username"], bet)
            status += f"\n\n{result_text}"
            self.blackjack_games.pop(session_id, None)
        markup = self._blackjack_buttons(session_id, finished=finished)
        await self.bot._safe_edit_message(context, chat_id, message_id, status, markup=markup)
        if finished:
            await store.log_event(
                chat_id,
                f"Блэкджек: {self.bot.log_handle(username=session['username'])} завершил игру. Итог {delta}",
            )
            await self.bot._safe_send_message(
                context,
                chat_id=chat_id,
                text=f"Итог: {self._casino_delta_text(delta, currency)}",
                parse_mode=ParseMode.HTML,
            )

    async def handle_command(
        self,
        *,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
        chat_id: int,
        user,
        args: list[str],
        prefix: str,
        store,
        currency: Dict[str, Any],
        is_creator: bool,
        plan_code: str,
        reply,
        message,
    ) -> bool:
        sub = args[0].lower() if args else None
        def require_plan(required: str) -> bool:
            if self.bot._plan_allowed(plan_code, required):
                return True
            asyncio.create_task(reply("Эта игра доступна от плана Медиум."))
            return False
        if not sub:
            await reply(
                "<b>Казино</b> — выбери игру:\n"
                "• рулетка {красный/черный/число 1-36} {ставка}\n"
                "• слоты {ставка}\n"
                "• блэкджек {ставка} (от Медиум)\n"
                "• покер {игроки} {ставка} (от Медиум)\n"
                "• монетка орел/решка {ставка}\n"
                "• кости {ставка}",
            )
            return True
        if sub == "рулетка":
            if len(args) != 3:
                await reply(f"Используй {prefix}казино рулетка {{красный/черный/число}} {{ставка}}")
                return True
            bet_token = args[1].lower()
            bet_label = None
            bet_type = None
            if bet_token.isdigit() and 1 <= int(bet_token) <= 36:
                bet_label = bet_token
                bet_type = "number"
            elif bet_token in {"красный", "red", "красное"}:
                bet_label = "красный"
                bet_type = "color"
            elif bet_token in {"черный", "чёрный", "black", "черное"}:
                bet_label = "черный"
                bet_type = "color"
            if not bet_type:
                await reply("Укажи цвет (красный/чёрный) или число 1-36 для ставки.")
                return True
            amount_value, is_all = self.bot.parse_amount_token(args[2])
            if amount_value is None and not is_all:
                await reply(f"Укажи ставку от {self.MIN_BET} до {self.bot.MAX_TRANSACTION} или all.")
                return True
            if is_all:
                amount_value = min(await store.get_balance(chat_id, user.id), self.bot.MAX_TRANSACTION)
            if not amount_value or amount_value < self.MIN_BET:
                await reply(f"Ставка должна быть не меньше {self.MIN_BET}.")
                return True
            ok, remaining = self._can_place_bet(chat_id, user.id)
            if not ok:
                minutes = int(remaining // 60) + 1
                await reply(
                    f"Достигнут лимит: не более {self.bet_window_limit} ставок за 2 часа. Подожди ~{minutes} мин."
                )
                return True
            balance = await store.get_balance(chat_id, user.id)
            if amount_value > balance:
                await reply("Недостаточно средств для ставки.")
                return True
            updated = await store.adjust_balance(chat_id, user.id, user.username or user.full_name, -amount_value)
            if updated is None:
                await reply("Недостаточно средств для ставки.")
                return True
            self._record_bet(chat_id, user.id)
            await reply(f"Вы поставили на {bet_label}\nСумма: {self.format_currency(amount_value, currency)}")
            task_key = f"{chat_id}:{user.id}:{int(time.time() * 1000)}"
            self.roulette_tasks[task_key] = asyncio.create_task(
                self._finish_roulette(
                    context,
                    task_key=task_key,
                    chat_id=chat_id,
                    user_id=user.id,
                    username=user.username or user.full_name or str(user.id),
                    bet_value=amount_value,
                    bet_label=bet_label,
                    bet_type=bet_type,
                    currency=currency,
                    is_creator=is_creator,
                )
            )
            return True
        if sub == "слоты":
            if len(args) != 2:
                await reply(f"Используй {prefix}казино слоты {{ставка}}")
                return True
            amount_token = args[1]
            amount_value, is_all = self.bot.parse_amount_token(amount_token)
            if amount_value is None and not is_all:
                await reply(f"Укажи ставку от {self.MIN_BET} до {self.bot.MAX_TRANSACTION} или all.")
                return True
            if is_all:
                amount_value = min(await store.get_balance(chat_id, user.id), self.bot.MAX_TRANSACTION)
            if not amount_value or amount_value < self.MIN_BET:
                await reply(f"Ставка должна быть не меньше {self.MIN_BET}.")
                return True
            ok, remaining = self._can_place_bet(chat_id, user.id)
            if not ok:
                minutes = int(remaining // 60) + 1
                await reply(
                    f"Достигнут лимит: не более {self.bet_window_limit} ставок за 2 часа. Подожди ~{minutes} мин."
                )
                return True
            updated = await store.adjust_balance(chat_id, user.id, user.username or user.full_name, -amount_value)
            if updated is None:
                await reply("Недостаточно средств для ставки.")
                return True
            self._record_bet(chat_id, user.id)
            await reply(f"Ставка принята! Ставка: {self.format_currency(amount_value, currency)}")

            async def start_slots() -> None:
                await asyncio.sleep(1)
                thread_id = self.bot.chat_threads.get(chat_id)
                try:
                    spin_message = await context.bot.send_message(
                        chat_id=chat_id,
                        text="Слоты запущены:\n\n...",
                        parse_mode=ParseMode.HTML,
                        message_thread_id=thread_id,
                    )
                except Exception:
                    return
                task_key = f"{chat_id}:{user.id}:{int(time.time() * 1000)}"
                self.slot_tasks[task_key] = asyncio.create_task(
                    self._finish_slots(
                        context,
                        task_key=task_key,
                        chat_id=chat_id,
                        user_id=user.id,
                        username=user.username or user.full_name or str(user.id),
                        bet_value=amount_value,
                        currency=currency,
                        message_id=spin_message.message_id,
                        is_creator=is_creator,
                    )
                )

            asyncio.create_task(start_slots())
            return True
        if sub == "монетка":
            if len(args) != 3:
                await reply(f"Используй {prefix}казино монетка орел/решка {{ставка}}")
                return True
            choice = args[1].lower()
            if choice not in {"орел", "орёл", "решка"}:
                await reply("Выбери: орел или решка.")
                return True
            amount_value, is_all = self.bot.parse_amount_token(args[2])
            if amount_value is None and not is_all:
                await reply(f"Укажи ставку от {self.MIN_BET} до {self.bot.MAX_TRANSACTION} или all.")
                return True
            if is_all:
                amount_value = min(await store.get_balance(chat_id, user.id), self.bot.MAX_TRANSACTION)
            if not amount_value or amount_value < self.MIN_BET:
                await reply(f"Ставка должна быть не меньше {self.MIN_BET}.")
                return True
            ok, remaining = self._can_place_bet(chat_id, user.id)
            if not ok:
                minutes = int(remaining // 60) + 1
                await reply(
                    f"Достигнут лимит: не более {self.bet_window_limit} ставок за 2 часа. Подожди ~{minutes} мин."
                )
                return True
            updated = await store.adjust_balance(chat_id, user.id, user.username or user.full_name, -amount_value)
            if updated is None:
                await reply("Недостаточно средств для ставки.")
                return True
            self._record_bet(chat_id, user.id)
            win_chance = 0.7 if is_creator else 0.3
            win = random.random() < win_chance
            flip = "орёл" if choice.startswith("ор") else "решка"
            if not win:
                flip = "решка" if flip == "орёл" else "орёл"
            payout = amount_value * 2 if win else 0
            delta = payout - amount_value
            if payout:
                await self._payout(chat_id, user.id, user.username or user.full_name, payout)
            await reply(
                f"Монетка ({choice}): {flip}. Итог: {self._casino_delta_text(delta, currency)}",
            )
            await store.log_event(
                chat_id,
                f"Монетка: {self.bot.log_handle(user)} ставка {self.format_currency(amount_value, currency)} итог {delta}",
            )
            return True
        if sub == "кости":
            if len(args) != 2:
                await reply(f"Используй {prefix}казино кости {{ставка}}")
                return True
            amount_value, is_all = self.bot.parse_amount_token(args[1])
            if amount_value is None and not is_all:
                await reply(f"Укажи ставку от {self.MIN_BET} до {self.bot.MAX_TRANSACTION} или all.")
                return True
            if is_all:
                amount_value = min(await store.get_balance(chat_id, user.id), self.bot.MAX_TRANSACTION)
            if not amount_value or amount_value < self.MIN_BET:
                await reply(f"Ставка должна быть не меньше {self.MIN_BET}.")
                return True
            ok, remaining = self._can_place_bet(chat_id, user.id)
            if not ok:
                minutes = int(remaining // 60) + 1
                await reply(
                    f"Достигнут лимит: не более {self.bet_window_limit} ставок за 2 часа. Подожди ~{minutes} мин."
                )
                return True
            updated = await store.adjust_balance(chat_id, user.id, user.username or user.full_name, -amount_value)
            if updated is None:
                await reply("Недостаточно средств для ставки.")
                return True
            self._record_bet(chat_id, user.id)
            win_chance = 0.7 if is_creator else 0.3
            player_roll, dealer_roll = 0, 0
            if random.random() < win_chance:
                player_roll = random.randint(8, 12)
                dealer_roll = random.randint(2, max(7, player_roll - 1))
            else:
                dealer_roll = random.randint(8, 12)
                player_roll = random.randint(2, max(7, dealer_roll - 1))
                if random.random() < 0.1:
                    player_roll = dealer_roll
            result_text = f"Вы бросили {player_roll}, дилер — {dealer_roll}."
            if player_roll > dealer_roll:
                payout = amount_value * 2
                delta = payout - amount_value
                await self._payout(chat_id, user.id, user.username or user.full_name, payout)
                result_text += " Победа!"
            elif player_roll == dealer_roll:
                payout = amount_value
                delta = 0
                await self._payout(chat_id, user.id, user.username or user.full_name, payout)
                result_text += " Ничья."
            else:
                payout = 0
                delta = -amount_value
                result_text += " Проигрыш."
            result_text += f" Итог: {self._casino_delta_text(delta, currency)}"
            await reply(result_text)
            await store.log_event(
                chat_id,
                f"Кости: {self.bot.log_handle(user)} ставка {self.format_currency(amount_value, currency)} итог {delta}",
            )
            return True
        if sub == "блэкджек":
            if not require_plan(PLAN_MEDIUM):
                return True
            if len(args) != 2:
                await reply(f"Используй {prefix}казино блэкджек {{ставка}}")
                return True
            amount_value, is_all = self.bot.parse_amount_token(args[1])
            if amount_value is None and not is_all:
                await reply(f"Укажи ставку от {self.MIN_BET} до {self.bot.MAX_TRANSACTION} или all.")
                return True
            if is_all:
                amount_value = min(await store.get_balance(chat_id, user.id), self.bot.MAX_TRANSACTION)
            if not amount_value or amount_value < self.MIN_BET:
                await reply(f"Ставка должна быть не меньше {self.MIN_BET}.")
                return True
            ok, remaining = self._can_place_bet(chat_id, user.id)
            if not ok:
                minutes = int(remaining // 60) + 1
                await reply(
                    f"Достигнут лимит: не более {self.bet_window_limit} ставок за 2 часа. Подожди ~{minutes} мин."
                )
                return True
            updated = await store.adjust_balance(chat_id, user.id, user.username or user.full_name, -amount_value)
            if updated is None:
                await reply("Недостаточно средств для ставки.")
                return True
            self._record_bet(chat_id, user.id)
            deck = self._new_deck()
            player = [deck.pop(), deck.pop()]
            dealer = [deck.pop(), deck.pop()]
            session_id = f"{chat_id}:{user.id}:{int(time.time() * 1000)}"
            text = self._blackjack_status_text(player, dealer, reveal=False) + "\n\nВыберите действие:"
            markup = self._blackjack_buttons(session_id)
            sent = await message.reply_text(
                text,
                reply_markup=markup,
                parse_mode=ParseMode.HTML,
                message_thread_id=self.bot.chat_threads.get(chat_id),
            )
            self.blackjack_games[session_id] = {
                "chat_id": chat_id,
                "user_id": user.id,
                "username": user.username or user.full_name or str(user.id),
                "bet": amount_value,
                "deck": deck,
                "player": player,
                "dealer": dealer,
                "currency": currency,
                "message_id": sent.message_id,
            }
            await store.log_event(
                chat_id,
                f"Блэкджек: {self.bot.log_handle(user)} ставка {self.format_currency(amount_value, currency)}",
            )
            return True
        if sub == "покер":
            if not require_plan(PLAN_MEDIUM):
                return True
            if len(args) != 3:
                await reply(f"Используй {prefix}казино покер {{кол-во игроков}} {{ставка}}")
                return True
            existing = [
                sid
                for sid, sess in self.poker_tables.items()
                if sess.get("chat_id") == chat_id and sess.get("status") not in {"finished", "closed"}
            ]
            if existing:
                await reply("В этом чате уже есть активный стол покера. Дождитесь окончания игры.")
                return True
            try:
                players_count = max(2, min(10, int(args[1])))
            except ValueError:
                await reply("Укажи число игроков от 2 до 10.")
                return True
            amount_value, is_all = self.bot.parse_amount_token(args[2])
            if amount_value is None and not is_all:
                await reply(f"Укажи ставку от {self.MIN_BET} до {self.bot.MAX_TRANSACTION} или all.")
                return True
            if is_all:
                amount_value = min(await store.get_balance(chat_id, user.id), self.bot.MAX_TRANSACTION)
            if not amount_value or amount_value < self.MIN_BET:
                await reply(f"Ставка должна быть не меньше {self.MIN_BET}.")
                return True
            ok, remaining = self._can_place_bet(chat_id, user.id)
            if not ok:
                minutes = int(remaining // 60) + 1
                await reply(
                    f"Достигнут лимит: не более {self.bet_window_limit} ставок за 2 часа. Подожди ~{minutes} мин."
                )
                return True
            session_id = f"{chat_id}:{int(time.time() * 1000)}"
            join_code = secrets.token_hex(4)
            bot_username = context.bot_data.get("bot_username")
            if not bot_username:
                bot_username = (await context.bot.get_me()).username
                context.bot_data["bot_username"] = bot_username
            session = {
                "chat_id": chat_id,
                "owner_id": user.id,
                "max_players": players_count,
                "bet": amount_value,
                "currency": currency,
                "players": {},
                "status": "search",
                "pot": 0,
                "join_code": join_code,
            }
            self.poker_tables[session_id] = session
            self.poker_join_codes[join_code] = session_id
            mentions = await store.list_chat_users(chat_id)
            summon_text = "Поиск игроков..." + self._hidden_mentions(mentions)
            await message.reply_text(summon_text, parse_mode=ParseMode.HTML)
            join_markup = InlineKeyboardMarkup(
                [[InlineKeyboardButton("Начать", url=f"https://t.me/{bot_username}?start=poker-{join_code}")]]
            )
            invite = await message.reply_text(
                "Присоединиться к игре",
                reply_markup=join_markup,
            )
            session["invite_message_id"] = invite.message_id
            try:
                await context.bot.pin_chat_message(chat_id=chat_id, message_id=invite.message_id)
            except Exception:
                pass
            ok, reason = await self._join_poker(
                context,
                session_id=session_id,
                user=user,
                username=user.username or user.full_name or str(user.id),
            )
            if not ok:
                await reply(reason)
                return True
            self.poker_timeouts[session_id] = asyncio.create_task(self._poker_timeout(context, session_id))
            await reply(
                f"Покер запущен. Ожидаем {players_count} игроков по ставке {self.format_currency(amount_value, currency)} (макс 10 игроков).",
            )
            return True
        return False
