import html
import re
from typing import Any, Iterable, Optional

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.constants import ParseMode

from economy.formatters import format_currency


class NormalShop:
    def __init__(self, bot: Any) -> None:
        self.bot = bot

    def build_shop_keyboard(
        self,
        chat_id: int,
        items: Iterable[tuple],
        currency_icon: str,
        page: int = 0,
    ) -> Optional[InlineKeyboardMarkup]:
        items = tuple(items)
        if not items:
            return None
        page_size = getattr(self.bot, "SHOP_PAGE_SIZE", 5)
        start = page * page_size
        end = start + page_size
        current = items[start:end]
        buttons = []
        for idx, (_, title, price, *_rest, quantity) in enumerate(current, start=start + 1):
            stock_label = "∞" if quantity == 0 else f"x{quantity}"
            buttons.append(
                [
                    InlineKeyboardButton(
                        f"[{idx}] {title}: {format_currency(price, {'icon': currency_icon})} ({stock_label})",
                        callback_data=f"shop:view:{chat_id}:{page}:{idx}",
                    )
                ]
            )
        nav_row = []
        total_pages = max(1, (len(items) + page_size - 1) // page_size)
        if page > 0:
            nav_row.append(InlineKeyboardButton("←", callback_data=f"shop:open:{chat_id}:{page-1}"))
        if page < total_pages - 1:
            nav_row.append(InlineKeyboardButton("→", callback_data=f"shop:open:{chat_id}:{page+1}"))
        if nav_row:
            buttons.append(nav_row)
        return InlineKeyboardMarkup(buttons)

    @staticmethod
    def render_shop_menu_text() -> str:
        return "Магазин. Выбери товар:"

    def render_item_text(
        self,
        title: str,
        price: float,
        currency: dict,
        author_id: int,
        author_username: str | None,
        quantity: int,
    ) -> str:
        if author_username:
            safe = html.escape(author_username.lstrip("@"))
            author = f"<a href=\"https://t.me/{safe}\">{safe}</a>"
        else:
            author = f"id{author_id}"
        stock = "∞" if quantity == 0 else str(quantity)
        return (
            f"<b>{html.escape(title)}</b>\n"
            f"Цена: {format_currency(price, currency)}\n"
            f"Автор: {author}\n"
            f"В наличии: {stock}"
        )

    async def send_shop(self, chat_id: int, message, currency: dict) -> None:
        items = await self.bot.ensure_storage().list_shop_items(chat_id)
        keyboard = self.build_shop_keyboard(chat_id, items, currency.get("icon", "💰"))
        text = self.render_shop_menu_text() if items else "Магазин пуст. Добавьте товары через !!товар добавить."
        await message.reply_text(text, reply_markup=keyboard, parse_mode=ParseMode.HTML)

    async def handle_shop_callback(self, update: Update, context) -> None:
        query = update.callback_query
        if not query:
            return
        await query.answer()
        parts = query.data.split(":")
        if len(parts) < 3:
            return
        action = parts[1]
        chat_id = int(parts[2])
        page = int(parts[3]) if len(parts) > 3 else 0
        index = int(parts[4]) if len(parts) > 4 else None
        session_key = None
        if query.message:
            session_key = f"{query.message.chat_id}:{query.message.message_id}"
        store = self.bot.ensure_storage()
        if await store.is_blocked(chat_id) and not self.bot.ensure_creator(update):
            await query.answer("Ваша группа неожиданно разорвала соединение с ботом. Код ошибки: POSHEL_NAHUY", show_alert=True)
            return
        if await store.is_banned(chat_id, query.from_user.id):
            await query.answer("Команда не распознана. Попробуй !!poshel naxui", show_alert=True)
            return
        currency = await store.chat_currency(chat_id)
        items = await store.list_shop_items(chat_id)
        total_pages = max(1, (len(items) + self.bot.SHOP_PAGE_SIZE - 1) // self.bot.SHOP_PAGE_SIZE)
        page = max(0, min(page, total_pages - 1))
        keyboard = self.build_shop_keyboard(chat_id, items, currency.get("icon", "💰"), page=page)
        if action == "open":
            if session_key:
                self.bot.shop_sessions.pop(session_key, None)
            text = self.render_shop_menu_text() if items else "Магазин пуст. Добавьте товары через !!товар добавить."
            await query.edit_message_text(text, reply_markup=keyboard, parse_mode=ParseMode.HTML)
            return
        if action == "view" and index:
            if not items or index < 1 or index > len(items):
                await query.edit_message_text("Товар не найден.")
                return
            _, title, price, author_id, author_username, quantity = items[index - 1]
            await query.edit_message_text(
                self.render_item_text(title, price, currency, author_id, author_username, quantity),
                reply_markup=InlineKeyboardMarkup(
                    [
                        [InlineKeyboardButton("Приобрести", callback_data=f"shop:confirm:{chat_id}:{page}:{index}")],
                        [InlineKeyboardButton("Назад", callback_data=f"shop:open:{chat_id}:{page}")],
                    ]
                ),
                parse_mode=ParseMode.HTML,
            )
            return
        if action == "confirm" and index:
            if session_key:
                if self.bot.shop_sessions.get(session_key) == query.data:
                    await query.answer("Покупка уже обработана", show_alert=True)
                    return
                self.bot.shop_sessions[session_key] = query.data
            buyer = query.from_user
            buyer_name = buyer.username or buyer.full_name
            tax_rate = max(0, min(10000, int(currency.get("tax_rate", 500))))
            if await store.tax_holiday_remaining(chat_id) > 0:
                tax_rate = 0
            idem_key = f"shop:{chat_id}:{query.message.message_id}:{buyer.id}:{index}"
            try:
                result = await store.purchase_shop_item(
                    chat_id=chat_id,
                    index=index,
                    buyer_id=buyer.id,
                    buyer_username=buyer_name,
                    tax_rate=tax_rate,
                    idempotency_key=idem_key,
                    metadata={"message_id": query.message.message_id},
                )
            except ValueError:
                await query.edit_message_text(
                    "Недостаточно средств для покупки.",
                    reply_markup=InlineKeyboardMarkup(
                        [[InlineKeyboardButton("Назад", callback_data=f"shop:open:{chat_id}:{page}")]]
                    ),
                )
                return
            if result is None:
                await query.edit_message_text("Покупка уже обработана.")
                return
            title = result["title"]
            price_value = result["price"]
            seller_gain = result["seller_gain"]
            await store.log_event(
                chat_id,
                f"Пользователь {self.bot.log_handle(buyer)} купил '{title}' за {format_currency(price_value, currency)} (налог {tax_rate / 100:.2f}%): продавцу зачтено {format_currency(seller_gain, currency)}",
            )
            await query.edit_message_text(
                f"<b>Транзакция завершена!</b> Вы купили <b>{html.escape(title)}</b> за {format_currency(price_value, currency)}."
                f" Баланс: {format_currency(result['new_balance'], currency)}",
                reply_markup=InlineKeyboardMarkup(
                    [[InlineKeyboardButton("Назад", callback_data=f"shop:open:{chat_id}:{page}")]]
                ),
                parse_mode=ParseMode.HTML,
            )
            return

    async def handle_shop_settings_callback(self, update: Update, context) -> None:
        query = update.callback_query
        if not query:
            return
        await query.answer()
        parts = query.data.split(":")
        if len(parts) < 4:
            return
        action = parts[1]
        chat_id = int(parts[2])
        index = int(parts[3])
        store = self.bot.ensure_storage()
        if await store.is_blocked(chat_id) and not self.bot.ensure_creator(update):
            await query.answer("Ваша группа неожиданно разорвала соединение с ботом. Код ошибки: POSHEL_NAHUY", show_alert=True)
            return
        if await store.is_banned(chat_id, query.from_user.id):
            await query.answer("Команда не распознана. Попробуй !!poshel naxui", show_alert=True)
            return
        item = await store.get_shop_item_by_index(chat_id, index)
        if not item:
            await query.edit_message_text("Товар не найден или был удалён.")
            return
        _, title, _price, author_id, _author_username, _quantity = item
        perms = await store.permissions(chat_id)
        user_id = query.from_user.id
        is_creator = self.bot.ensure_creator(update)
        allowed = is_creator or user_id == author_id or user_id in perms.get("economy_admins", [])
        if not allowed:
            await query.answer("Доступ запрещен", show_alert=True)
            return
        if action == "open":
            await store.clear_pending_item_edit(query.message.message_id)
            buttons = [
                [InlineKeyboardButton("Название", callback_data=f"shopcfg:set:{chat_id}:{index}:title")],
                [InlineKeyboardButton("Цена", callback_data=f"shopcfg:set:{chat_id}:{index}:price")],
                [InlineKeyboardButton("Количество", callback_data=f"shopcfg:set:{chat_id}:{index}:quantity")],
                [InlineKeyboardButton("К меню магазина", callback_data=f"shop:open:{chat_id}:0")],
            ]
            await query.edit_message_text(
                f"Настройки товара {title}",
                reply_markup=InlineKeyboardMarkup(buttons),
            )
            return
        if action == "set" and len(parts) >= 5:
            field = parts[4]
            prompts = {
                "title": "Введите новое название товара (ответом на это сообщение):",
                "price": f"Введите новую цену (от {self.bot.MIN_TRANSACTION} до {self.bot.MAX_TRANSACTION}) ответом на сообщение:",
                "quantity": "Введите количество товаров (0 - бесконечно) ответом на это сообщение:",
            }
            await store.set_pending_item_edit(
                prompt_id=query.message.message_id,
                chat_id=chat_id,
                index=index,
                field=field,
                owner_id=user_id,
            )
            await query.edit_message_text(
                prompts.get(field, "Введите новое значение"),
                reply_markup=InlineKeyboardMarkup(
                    [[InlineKeyboardButton("Назад", callback_data=f"shopcfg:open:{chat_id}:{index}")]]
                ),
            )

    async def handle_goods_command(
        self,
        chat_id: int,
        message,
        user,
        args: list[str],
        currency: dict,
        is_creator: bool,
        perms: dict,
        prefix: str,
    ) -> bool:
        if not args:
            return False
        store = self.bot.ensure_storage()
        sub_command = args[0].lower()
        if sub_command == "добавить":
            payload_text = " ".join(args[1:]).strip()
            if not payload_text:
                await message.reply_text(f"Укажи название в кавычках и цену: {prefix}товар добавить \"Название\" 100")
                return True
            match = re.match(r'^["“”]?(.+?)["“”]?\s+([0-9.,]+)(?:\s+([0-9]+))?$', payload_text)
            if not match:
                await message.reply_text(f"Формат: {prefix}товар добавить \"Название\" 100 [количество]")
                return True
            title, price_raw, qty_raw = match.groups()
            price = self.bot.validate_amount(self.bot.parse_amount(price_raw))
            if price is None:
                await message.reply_text(f"Цена должна быть от {self.bot.MIN_TRANSACTION} до {self.bot.MAX_TRANSACTION}.")
                return True
            quantity = int(qty_raw) if qty_raw and qty_raw.isdigit() else 0
            index = await store.add_shop_item(chat_id, title, price, user.id, user.username or user.full_name, quantity)
            await store.log_event(
                chat_id,
                f"Создан товар [{index}] '{title}' за {format_currency(price, currency)} автором {self.bot.log_handle(user)} (кол-во: {quantity if quantity else '∞'})",
            )
            await message.reply_text(f"Товар с индексом [{index}] создан и добавлен!")
            return True
        if sub_command == "удалить":
            if len(args) < 2 or not args[1].isdigit():
                await message.reply_text(f"Формат: {prefix}товар удалить {{индекс}}")
                return True
            idx = int(args[1])
            item = await store.get_shop_item_by_index(chat_id, idx)
            if not item:
                await message.reply_text("Товар с таким индексом не найден.")
                return True
            _, title, _, author_id, _, _ = item
            allowed = is_creator or user.id == author_id or user.id in perms.get("economy_admins", [])
            if not allowed:
                await message.reply_text("Доступ запрещен")
                return True
            removed = await store.remove_shop_item(chat_id, idx)
            if removed:
                await store.log_event(chat_id, f"Удалён товар [{idx}] '{title}' по инициативе {self.bot.log_handle(user)}")
            await message.reply_text("Товар удален." if removed else "Товар с таким индексом не найден.")
            return True
        if sub_command == "настроить":
            if len(args) < 2 or not args[1].isdigit():
                await message.reply_text(f"Формат: {prefix}товар настроить {{индекс}}")
                return True
            idx = int(args[1])
            item = await store.get_shop_item_by_index(chat_id, idx)
            if not item:
                await message.reply_text("Товар не найден.")
                return True
            _, title, _, author_id, _, _ = item
            allowed = is_creator or user.id == author_id or user.id in perms.get("economy_admins", [])
            if not allowed:
                await message.reply_text("Доступ запрещен")
                return True
            buttons = [
                [InlineKeyboardButton("Открыть настройки", callback_data=f"shopcfg:open:{chat_id}:{idx}")],
                [InlineKeyboardButton("Назад в магазин", callback_data=f"shop:open:{chat_id}:0")],
            ]
            await message.reply_text(
                f"Настройки товара {title}",
                reply_markup=InlineKeyboardMarkup(buttons),
            )
            return True
        await message.reply_text(f"Команда не распознана. Напиши {prefix}помощь.")
        return True
