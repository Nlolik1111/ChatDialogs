"""Lightweight e-script engine facade with utility builtins."""
from __future__ import annotations

import asyncio
import json
import math
import random
import re
import time
import uuid
import traceback
import logging
from pathlib import Path
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Iterable, List, Optional

from zoneinfo import ZoneInfo
from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from telegram.constants import ParseMode

from .stdlib import execute_function, parse_function_name
from .compiler import EScriptCompiler

UNDEFINED = object()
logger = logging.getLogger(__name__)


class ScriptError(Exception):
    """Base runtime error with code/message/stack payload."""

    def __init__(self, code: str | Exception, message: str | None = None, *, stack: list[str] | None = None) -> None:
        if isinstance(code, Exception):
            message = message or str(code)
            code = code.__class__.__name__
        super().__init__(message or str(code))
        self.code = str(code)
        self.message = message or str(code)
        self.stack = stack or traceback.format_stack()[:-1]


class ReturnSignal(Exception):
    def __init__(self, value: Any) -> None:
        super().__init__("return")
        self.value = value


class LoopBreak(Exception):
    pass


class LoopContinue(Exception):
    pass


class _Namespace:
    """Proxy that forwards attribute lookups to runtime methods with a prefix.

    Example: namespace("message").send -> runtime.message_send
    """

    def __init__(self, runtime: "EScriptRuntime", prefix: str) -> None:
        self._runtime = runtime
        self._prefix = prefix

    def __getattr__(self, name: str):  # noqa: D401 - small helper
        dotted = f"{self._prefix}.{name}"
        parsed = parse_function_name(dotted)
        if parsed:
            return lambda *args: execute_function(dotted, list(args))
        target = f"{self._prefix}_{name}"
        if hasattr(self._runtime, target):
            return getattr(self._runtime, target)
        raise AttributeError(name)


class ModuleNamespace:
    def __init__(self, runtime: "EScriptRuntime", script: Any, prefix: str) -> None:
        self._runtime = runtime
        self._script = script
        self._prefix = prefix

    def __getattr__(self, name: str):
        if name in getattr(self._script, "consts", {}):
            return self._runtime.globals.get(name, self._script.consts[name])
        async def _runner(*args):
            return await self._runtime._call_module_function(self._script, name, list(args))

        return _runner


class EScriptRuntime:
    def __init__(self, bot: Any | None = None, *, chat_id: int | None = None, script_id: int | None = None, storage: Any | None = None) -> None:
        # allow legacy positional construction ``EScriptRuntime(bot)`` while
        # keeping the explicit keyword arguments used by the newer call sites
        self.bot = bot
        self._chat_id = chat_id or 0
        self.script_id = script_id or 0
        self.storage = storage
        self.globals: Dict[str, Any] = {}
        self.scopes: list[Dict[str, Any]] = [self.globals]
        self.error_state: Dict[str, Any] = {}
        self.scheduled: Dict[str, Dict[str, Any]] = {}
        self._locks: Dict[str, Dict[str, float]] = {}
        self._rate_limits: Dict[str, list[float]] = {}
        self.current_script = None
        self._namespaces: dict[str, _Namespace] = {}
        self._active_update = None
        self._active_context = None
        self._user_cache: dict[str, dict[str, str]] = {}
        self._chat_cache: dict[str, dict[str, str]] = {}
        self.http_allowlist: list[str] = ["localhost", "127.0.0.1"]
        self.webhook_endpoints: dict[str, str] = {}
        self._module_cache: dict[str, Any] = {}
        self._module_loading: set[str] = set()
        self.modules: dict[str, Any] = {}
        self.schedule_root = Path(__file__).resolve().parents[2] / "escripts" / "schedules"
        self._schedule_loaded_chat: int | None = None
        self._mock_time: int | None = None
        self._mock_http: list[dict[str, Any]] = []
        self._mock_form_responses: list[dict[str, Any]] = []
        self._forms: dict[str, dict] = {}

        
        # aliases for reserved words in scripts
        setattr(self, "assert", self.assert_)
        setattr(self, "break", self.break_loop)
        setattr(self, "continue", self.continue_loop)
        setattr(self, "try", self.try_catch)

        # user-facing namespaces to mirror documented prefixes
        for prefix in (
            "json",
            "array",
            "map",
            "text",
            "math",
            "command",
            "user",
            "chat",
            "permissions",
            "members",
            "ui",
            "message",
            "pin",
            "thread",
            "time",
            "schedule",
            "balance",
            "economy",
            "treasury",
            "kv",
            "persist",
            "db",
            "http",
            "crypto",
            "webhook",
        ):
            ns = _Namespace(self, prefix)
            self._namespaces[prefix] = ns
            setattr(self, prefix, ns)

    @property
    def active_chat_id(self) -> int:
        return self._chat_id

    @active_chat_id.setter
    def active_chat_id(self, value: int) -> None:
        self._chat_id = value

    # region variables
    def var_unset(self, value_ref: str) -> None:
        for scope in reversed(self.scopes):
            if value_ref in scope:
                del scope[value_ref]
                return

    def var_exists(self, value_ref: str) -> bool:
        for scope in reversed(self.scopes):
            if value_ref in scope and scope[value_ref] is not UNDEFINED:
                return True
        return False

    def type_of(self, value: Any) -> str:
        if value is UNDEFINED:
            return "undefined"
        if value is None:
            return "null"
        if isinstance(value, bool):
            return "bool"
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            return "number"
        if isinstance(value, str):
            return "string"
        if isinstance(value, list):
            return "array"
        if isinstance(value, dict):
            return "object"
        return "object"

    def to_number(self, value: Any, default: float | None = None) -> float | None:
        if value is None or value is UNDEFINED:
            return default
        if isinstance(value, bool):
            return 1.0 if value else 0.0
        if isinstance(value, (int, float)):
            return float(value)
        try:
            if isinstance(value, str) and value.strip():
                return float(value.replace(" ", ""))
        except Exception:
            return default
        return default

    def to_string(self, value: Any) -> str:
        if value is UNDEFINED:
            return "undefined"
        if value is None:
            return "null"
        if isinstance(value, bool):
            return "true" if value else "false"
        return str(value)

    def to_bool(self, value: Any) -> bool:
        if value is UNDEFINED or value is None:
            return False
        if isinstance(value, bool):
            return value
        if isinstance(value, (int, float)):
            return value != 0
        if isinstance(value, str):
            val = value.strip().lower()
            if val in {"0", "false", "no", "off"}:
                return False
            return val in {"1", "true", "yes", "y", "on"}
        return True

    # endregion

    # region json helpers
    def json_parse(self, text: str) -> Any:
        try:
            return json.loads(text)
        except Exception as exc:  # noqa: BLE001
            self.error_state["last"] = {"code": "json_parse", "message": str(exc)}
            return None

    def json_stringify(self, value: Any, pretty: bool = False) -> str:
        return json.dumps(value, ensure_ascii=False, indent=2 if pretty else None)

    # endregion

    # region arrays
    def array_new(self, *values: Any) -> list[Any]:
        return list(values)

    def array_push(self, arr_ref: list, value: Any) -> int:
        arr_ref.append(value)
        return len(arr_ref)

    def array_pop(self, arr_ref: list, default: Any = None) -> Any:
        return arr_ref.pop() if arr_ref else default

    def array_get(self, arr: list, index: int, default: Any = None) -> Any:
        try:
            return arr[index]
        except Exception:
            try:
                if index < 0:
                    return arr[len(arr) + index]
            except Exception:
                pass
        return default

    def array_set(self, arr_ref: list, index: int, value: Any) -> None:
        if index < 0:
            index = max(len(arr_ref) + index, 0)
        while len(arr_ref) <= index:
            arr_ref.append(None)
        arr_ref[index] = value

    def array_len(self, arr: list) -> int:
        return len(arr)

    def array_slice(self, arr: list, from_idx: int = 0, to: Optional[int] = None) -> list:
        return arr[from_idx : (len(arr) if to is None else to)]

    def array_join(self, arr: list, sep: str = ",") -> str:
        return sep.join(self.to_string(v) for v in arr)

    def array_unique(self, arr: list) -> list:
        seen = []
        for item in arr:
            if item not in seen:
                seen.append(item)
        return seen

    def array_shuffle(self, arr_ref: list, seed: float | None = None) -> list:
        rng = random.Random(seed)
        rng.shuffle(arr_ref)
        return arr_ref

    def array_contains(self, arr: list, value: Any) -> bool:
        return value in arr

    # endregion

    # region maps
    def map_new(self, pairs: Optional[list] = None) -> dict:
        result = {}
        if pairs:
            for k, v in pairs:
                result[k] = v
        return result

    def map_get(self, obj: dict, key: str, default: Any = None) -> Any:
        return obj.get(key, default)

    def map_set(self, obj_ref: dict, key: str, value: Any) -> None:
        obj_ref[key] = value

    def map_del(self, obj_ref: dict, key: str) -> bool:
        return obj_ref.pop(key, UNDEFINED) is not UNDEFINED

    def map_keys(self, obj: dict) -> list[str]:
        return list(obj.keys())

    def map_values(self, obj: dict) -> list[Any]:
        return list(obj.values())

    def map_has(self, obj: dict, key: str) -> bool:
        return key in obj

    def map_merge(self, a: dict, b: dict, mode: str = "overwrite") -> dict:
        result = dict(a)
        if mode == "keep":
            for k, v in b.items():
                result.setdefault(k, v)
        elif mode == "deep":
            for k, v in b.items():
                if k in result and isinstance(result[k], dict) and isinstance(v, dict):
                    result[k] = self.map_merge(result[k], v, mode="deep")
                else:
                    result[k] = v
        else:
            result.update(b)
        return result

    # endregion

    # region control flow
    async def switch(self, value: Any, cases: list[dict], default_actions: list | None = None) -> None:
        matched_actions = None
        for case in cases or []:
            when = case.get("when")
            if case.get("match_regex"):
                if isinstance(value, str) and re.search(str(when), value):
                    matched_actions = case.get("actions", [])
                    break
            elif value == when:
                matched_actions = case.get("actions", [])
                break
        if matched_actions is None:
            matched_actions = default_actions or []
        await self.run_actions(matched_actions)

    async def while_loop(self, condition, actions: list, max_iter: int = 1000) -> None:
        count = 0
        while self.to_bool(condition() if callable(condition) else condition):
            if count >= max_iter:
                raise ScriptError("loop_limit")
            try:
                await self.run_actions(actions)
            except LoopContinue:
                count += 1
                continue
            except LoopBreak:
                break
            count += 1

    async def for_loop(self, var_name: str, start: int, end: int, step: int = 1, actions: list | None = None, max_iter: int = 10000) -> None:
        if step == 0:
            raise ScriptError("step_zero")
        actions = actions or []
        iterations = 0
        value = start
        cmp = (lambda a, b: a <= b) if step > 0 else (lambda a, b: a >= b)
        while cmp(value, end):
            if iterations >= max_iter:
                raise ScriptError("loop_limit")
            self.globals[var_name] = value
            try:
                await self.run_actions(actions)
            except LoopContinue:
                iterations += 1
                value += step
                continue
            except LoopBreak:
                break
            iterations += 1
            value += step

    async def foreach(self, var_name: str, arr: list, actions: list | None = None, max_iter: int = 10000) -> None:
        actions = actions or []
        for idx, item in enumerate(arr):
            if idx >= max_iter:
                raise ScriptError("loop_limit")
            self.globals[var_name] = item
            try:
                await self.run_actions(actions)
            except LoopContinue:
                continue
            except LoopBreak:
                break

    def break_loop(self) -> None:
        raise LoopBreak()

    def break_(self) -> None:
        self.break_loop()

    def continue_loop(self) -> None:
        raise LoopContinue()

    def continue_(self) -> None:
        self.continue_loop()

    async def try_catch(self, actions: list, catch_var: str = "error", catch_actions: list | None = None) -> None:
        try:
            await self.run_actions(actions)
        except Exception as exc:  # noqa: BLE001
            if isinstance(exc, ScriptError):
                self.globals[catch_var] = {"code": exc.code, "message": exc.message, "stack": exc.stack}
            else:
                self.globals[catch_var] = {
                    "code": getattr(exc, "code", "runtime_error"),
                    "message": str(exc),
                    "stack": traceback.format_exc().splitlines(),
                }
            await self.run_actions(catch_actions or [])

    # endregion

    # region time helpers
    def time_now(self) -> int:
        return int(self._mock_time if self._mock_time is not None else time.time())

    def _resolve_tz(self, tz: str) -> timezone:
        try:
            return ZoneInfo(tz)
        except Exception:
            match = re.match(r"^(?:UTC|GMT)?([+-])(\d{1,2})(?::?(\d{2}))?$", tz)
            if match:
                sign, hours, minutes = match.group(1), int(match.group(2)), int(match.group(3) or 0)
                delta = timedelta(hours=hours, minutes=minutes)
                if sign == "-":
                    delta = -delta
                return timezone(delta)
            return timezone.utc

    def time_today(self, tz: str | None = None) -> int:
        base = self.time_now()
        tzinfo = self._resolve_tz(tz) if tz else timezone.utc
        dt = datetime.fromtimestamp(base, tz=tzinfo)
        return int(dt.replace(hour=0, minute=0, second=0, microsecond=0).timestamp() // 86400)

    def time_parse(self, text: str, tz: str | None = None) -> Optional[int]:
        try:
            dt = datetime.fromisoformat(text.replace("Z", "+00:00"))
            if tz:
                dt = dt.astimezone(self._resolve_tz(tz))
            return int(dt.timestamp())
        except Exception:
            return None

    def time_format(self, ts: int, fmt: str = "YYYY-MM-DD HH:mm", tz: str | None = None) -> str:
        fmt_py = fmt.replace("YYYY", "%Y").replace("DD", "%d").replace("HH", "%H").replace("mm", "%M")
        dt = datetime.fromtimestamp(ts, tz=ZoneInfo(tz) if tz else timezone.utc)
        return dt.strftime(fmt_py)

    def time_add_days(self, ts: int, days: int) -> int:
        return int((datetime.fromtimestamp(ts, tz=timezone.utc) + timedelta(days=days)).timestamp())

    def time_diff_days(self, a: int, b: int) -> int:
        return int((a - b) // 86400)

    # endregion

    # region scheduling (in-memory)
    def schedule_once(self, ts: int, actions: list, id: str | None = None) -> str:
        task_id = id or str(uuid.uuid4())
        self._ensure_schedule_loaded()
        self.scheduled[task_id] = {"ts": ts, "actions": actions, "cron": False}
        self._persist_schedule()
        return task_id

    def schedule_every(self, cron: str, actions: list, id: str | None = None, tz: str | None = None) -> str:
        task_id = id or str(uuid.uuid4())
        self._ensure_schedule_loaded()
        self.scheduled[task_id] = {"cron": True, "expr": cron, "actions": actions, "tz": tz}
        self._persist_schedule()
        return task_id

    def schedule_cancel(self, id: str) -> bool:
        self._ensure_schedule_loaded()
        removed = self.scheduled.pop(id, None) is not None
        if removed:
            self._persist_schedule()
        return removed

    def schedule_list(self, prefix: str | None = None) -> list:
        self._ensure_schedule_loaded()
        if prefix is None:
            return list(self.scheduled.keys())
        return [k for k in self.scheduled if str(k).startswith(prefix)]

    # endregion

    def _schedule_store_path(self) -> Path:
        chat_folder = self.schedule_root / str(self._chat_id or 0)
        chat_folder.mkdir(parents=True, exist_ok=True)
        return chat_folder / "tasks.json"

    def _persist_schedule(self) -> None:
        try:
            path = self._schedule_store_path()
            payload = {"chat_id": self._chat_id, "tasks": self.scheduled}
            path.write_text(json.dumps(payload), encoding="utf-8")
        except Exception as exc:  # noqa: BLE001
            logger.warning("Failed to persist schedule: %s", exc)

    def _ensure_schedule_loaded(self) -> None:
        if self._schedule_loaded_chat == self._chat_id:
            return
        try:
            path = self._schedule_store_path()
            if path.exists():
                data = json.loads(path.read_text(encoding="utf-8"))
                if data.get("chat_id") == self._chat_id:
                    self.scheduled.update(data.get("tasks", {}))
        except Exception as exc:  # noqa: BLE001
            logger.warning("Failed to load persisted schedule: %s", exc)
        self._schedule_loaded_chat = self._chat_id

    # region text helpers
    def text_lower(self, text: str) -> str:
        return text.lower()

    def text_upper(self, text: str) -> str:
        return text.upper()

    def text_trim(self, text: str) -> str:
        return text.strip()

    def text_replace(self, text: str, old: str | re.Pattern, new: str) -> str:
        if isinstance(old, re.Pattern):
            return old.sub(new, text)
        return text.replace(old, new)

    def text_split(self, text: str, sep: str | re.Pattern, limit: int | None = None) -> list[str]:
        if isinstance(sep, re.Pattern):
            parts = sep.split(text, maxsplit=limit or 0)
        else:
            parts = text.split(sep, maxsplit=limit or 0)
        return parts

    def text_regex_match(self, text: str, pattern: str, flags: str = "") -> Optional[dict]:
        compiled = re.compile(pattern, flags=self._regex_flags(flags))
        match = compiled.search(text)
        if not match:
            return None
        return {"groups": list(match.groups())}

    def text_regex_findall(self, text: str, pattern: str, flags: str = "") -> list:
        compiled = re.compile(pattern, flags=self._regex_flags(flags))
        return compiled.findall(text)

    def text_format(self, template: str, values: dict) -> str:
        result = template
        for key, value in values.items():
            result = result.replace("{" + key + "}", self.to_string(value))
        return result

    def _regex_flags(self, flags: str) -> int:
        mapping = {"i": re.IGNORECASE, "m": re.MULTILINE, "s": re.DOTALL}
        result = 0
        for ch in flags:
            result |= mapping.get(ch, 0)
        return result

    # endregion

    # region command helpers
    def command_args(self, raw_text: str | None = None) -> list[str]:
        import shlex

        if raw_text is None:
            message = getattr(self._active_update, "effective_message", None)
            raw_text = getattr(message, "text", None) or getattr(message, "caption", "") or ""
            tokens = raw_text.split(maxsplit=1)
            if tokens:
                # drop the command itself, keeping the argument tail
                raw_text = tokens[1] if len(tokens) > 1 else ""
        try:
            return shlex.split(raw_text)
        except ValueError:
            return raw_text.split()

    def command_arg(self, index: int, default: Any = None, raw_text: str | None = None) -> Any:
        args = self.command_args(raw_text)
        return args[index] if 0 <= index < len(args) else default

    def command_parse_amount(self, text: str, allow_all: bool = True) -> dict:
        text = (text or "").strip().lower()
        if allow_all and text in {"all", "всё", "все", "вс1"}:
            return {"kind": "all", "value": None}
        match = re.fullmatch(r"([0-9]+(?:\.[0-9]+)?)([km]?)", text)
        if not match:
            return {"kind": "invalid", "value": None}
        number = float(match.group(1))
        suffix = match.group(2)
        if suffix == "k":
            number *= 1_000
        elif suffix == "m":
            number *= 1_000_000
        return {"kind": "number", "value": number}

    def command_parse_user(self, text: str) -> Optional[str]:
        text = (text or "").strip()
        if not text and self._active_update:
            reply = getattr(getattr(self._active_update, "effective_message", None), "reply_to_message", None)
            if reply and getattr(reply, "from_user", None):
                return str(getattr(reply.from_user, "id", ""))
        if text.startswith("@"):  # username
            return text[1:]
        if text.isdigit():
            return text
        deep_link = re.search(r"id=(\d+)", text)
        if deep_link:
            return deep_link.group(1)
        return None

    # endregion

    def _remember_from_update(self, update: Any | None) -> None:
        if not update:
            return
        user = getattr(update, "effective_user", None)
        if user and getattr(user, "id", None) is not None:
            uid = str(user.id)
            name = getattr(user, "full_name", None) or getattr(user, "username", None) or uid
            mention = user.mention_html() if hasattr(user, "mention_html") else name
            self._user_cache[uid] = {"name": name, "mention": mention}
        chat = getattr(update, "effective_chat", None)
        if chat and getattr(chat, "id", None) is not None:
            chat_id = str(chat.id)
            title = getattr(chat, "title", None) or getattr(chat, "full_name", None) or chat_id
            self._chat_cache[chat_id] = {"title": title}

    # region placeholders for platform-specific helpers
    def user_id(self, ctx: Any) -> str:
        if ctx is None:
            ctx = self._active_update
        user = getattr(ctx, "effective_user", None) if ctx else None
        if user:
            return str(getattr(user, "id", ""))
        return str(getattr(ctx, "user_id", getattr(ctx, "from_user", None).id if getattr(ctx, "from_user", None) else ""))

    def user_name(self, user_id: str) -> str:
        uid = str(user_id)
        if uid in self._user_cache:
            return self._user_cache[uid].get("name", uid)
        user = getattr(self._active_update, "effective_user", None)
        if user and str(getattr(user, "id", "")) == uid:
            name = getattr(user, "full_name", None) or getattr(user, "username", None) or uid
            mention = user.mention_html() if hasattr(user, "mention_html") else name
            self._user_cache[uid] = {"name": name, "mention": mention}
            return name
        return uid

    def user_mention(self, user_id: str) -> str:
        uid = str(user_id)
        cached = self._user_cache.get(uid)
        if cached and cached.get("mention"):
            return cached["mention"]
        name = self.user_name(uid)
        mention = f"@{name}" if name and not name.startswith("@") else name
        self._user_cache.setdefault(uid, {}).setdefault("mention", mention)
        return mention

    def chat_id(self, ctx: Any) -> str:
        if ctx is None:
            ctx = self._active_update
        chat = getattr(ctx, "effective_chat", None) if ctx else None
        if chat and getattr(chat, "id", None) is not None:
            chat_id = str(chat.id)
            self._chat_cache.setdefault(chat_id, {})
            return chat_id
        return str(getattr(ctx, "chat_id", ""))

    def chat_title(self, ctx: Any) -> str:
        if ctx is None:
            ctx = self._active_update
        chat = getattr(ctx, "effective_chat", None) if ctx else None
        if chat:
            chat_id = str(getattr(chat, "id", ""))
            title = getattr(chat, "title", None) or getattr(chat, "full_name", None) or chat_id
            self._chat_cache.setdefault(chat_id, {"title": title})
            return title
        ctx_title = getattr(ctx, "title", None)
        if ctx_title:
            return str(ctx_title)
        return str(self._chat_cache.get(str(self._chat_id), {}).get("title", ""))

    def _resolve_permissions(self) -> dict:
        cached = self.globals.get("__permissions_cache")
        if cached is not None:
            return cached

        if self._active_context:
            for container_name in ("chat_data", "bot_data"):
                data = getattr(self._active_context, container_name, None) or {}
                if isinstance(data, dict):
                    perms = data.get("permissions") or data.get("economy_permissions")
                    if isinstance(perms, dict):
                        resolved = perms.get(self._chat_id) if isinstance(perms.get(self._chat_id), dict) else perms
                        if isinstance(resolved, dict):
                            self.globals["__permissions_cache"] = resolved
                            return resolved

        if self.storage and hasattr(self.storage, "permissions"):
            try:
                loop = asyncio.get_event_loop()
                if not loop.is_running():
                    resolved = loop.run_until_complete(self.storage.permissions(self._chat_id))
                    if isinstance(resolved, dict):
                        self.globals["__permissions_cache"] = resolved
                        return resolved
            except Exception as exc:  # noqa: BLE001
                logger.debug("Failed to preload permissions: %s", exc)

        return {}

    def user_role(self, user_id: str) -> str:
        perms = self._resolve_permissions()
        uid = int(user_id) if str(user_id).isdigit() else user_id
        if uid in set(perms.get("economy_admins", [])):
            return "admin"
        if uid in set(perms.get("allow_credit", [])):
            return "credit"
        if uid in set(perms.get("allow_debit", [])):
            return "debit"
        if uid in set(perms.get("banned", [])):
            return "banned"
        return "user"

    def permissions_has(self, user_id: str, perm: str) -> bool:
        role = self.user_role(user_id)
        if role == "admin":
            return True
        return perm in {role}

    def members_random(self, chat_id: str, count: int = 1, filter: dict | None = None) -> list[str]:
        sample = [f"member_{i}" for i in range(max(count, 1))]
        random.shuffle(sample)
        return sample[:count]

    def members_list(self, chat_id: str, filter: dict | None = None, limit: int = 200, cursor: str | None = None) -> dict:
        members = [f"member_{i}" for i in range(limit)]
        return {"members": members, "cursor": None}

    # endregion

    async def run_actions(
        self,
        actions: Iterable | None = None,
        *,
        script_id: int | None = None,
        script: Any | None = None,
        update: Any | None = None,
        context: Any | None = None,
        target: Any | None = None,
        variables: dict | None = None,
        chat_id_override: int | None = None,
        **_: Any,
    ) -> Any:
        self._active_update = update or self._active_update
        self._active_context = context or self._active_context
        self._remember_from_update(update)
        if chat_id_override is not None:
            self._chat_id = chat_id_override
        if script_id is not None:
            self.script_id = script_id
        if script is not None:
            self._prepare_script(script)
        if variables:
            self.scopes.append(dict(variables))
        try:
            result = await self._exec_block(list(actions or []), update=update, context=context, target=target)
        finally:
            if variables:
                self.scopes.pop()
        return result

    async def execute_command(
        self,
        command: Any,
        *,
        script: Any,
        args: list[str] | None = None,
        update: Any | None = None,
        context: Any | None = None,
        target: Any | None = None,
    ) -> Any:
        self._active_update = update or self._active_update
        self._active_context = context or self._active_context
        self._remember_from_update(update)
        if update and getattr(update, "effective_chat", None):
            try:
                self._chat_id = int(update.effective_chat.id)
            except Exception:
                pass
        self._prepare_script(script)
        call_args = args or []
        variables = self._bind_params(command.params, call_args)
        self.scopes.append(variables)
        try:
            return await self._exec_block(command.body, update=update, context=context, target=target)
        except ReturnSignal as ret:
            if command.returns and not self._type_matches(ret.value, command.returns):
                raise ScriptError(f"Возврат команды {command.name} не соответствует {command.returns}")
            return ret.value
        finally:
            self.scopes.pop()

    async def _exec_block(self, body: list, *, update=None, context=None, target=None) -> Any:
        result = None
        for node in body:
            result = await self._exec_node(node, update=update, context=context, target=target)
        return result

    async def _exec_node(self, node: dict, *, update=None, context=None, target=None) -> Any:
        op = node.get("op")
        if op == "let":
            value = self._eval_expr(node["expr"], update=update, context=context, target=target)
            if not self._type_matches(value, node["type"]):
                raise ScriptError(f"Тип {self.type_of(value)} не совпадает с {node['type']}")
            self.scopes[-1][node["name"]] = value
            return None
        if op == "set":
            value = self._eval_expr(node["expr"], update=update, context=context, target=target)
            for scope in reversed(self.scopes):
                if node["name"] in scope:
                    scope[node["name"]] = value
                    break
            else:
                self.globals[node["name"]] = value
            return None
        if op == "if":
            cond = self._eval_expr(node["cond"], update=update, context=context, target=target)
            branch = node["then"] if self.to_bool(cond) else node.get("else", [])
            return await self._exec_block(branch, update=update, context=context, target=target)
        if op == "while":
            count = 0
            while self.to_bool(self._eval_expr(node["cond"], update=update, context=context, target=target)):
                if count >= 1000:
                    raise ScriptError("loop_limit")
                try:
                    await self._exec_block(node.get("body", []), update=update, context=context, target=target)
                except LoopContinue:
                    count += 1
                    continue
                except LoopBreak:
                    break
                count += 1
            return None
        if op == "for":
            iterable = self._eval_expr(node["iter"], update=update, context=context, target=target)
            count = 0
            iterable_source = iterable.keys() if isinstance(iterable, dict) else iterable
            for item in iterable_source:
                if count >= 10000:
                    raise ScriptError("loop_limit")
                self.scopes[-1][node["var"]] = item
                try:
                    await self._exec_block(node.get("body", []), update=update, context=context, target=target)
                except LoopContinue:
                    count += 1
                    continue
                except LoopBreak:
                    break
                count += 1
            return None
        if op == "for_range":
            start_val = self.to_number(self._eval_expr(node["start"], update=update, context=context, target=target), 0) or 0
            end_val = self.to_number(self._eval_expr(node["end"], update=update, context=context, target=target), 0) or 0
            step_val = self.to_number(
                self._eval_expr(node.get("step", "1"), update=update, context=context, target=target), 1
            ) or 1
            if step_val == 0:
                raise ScriptError("loop_limit")
            current = start_val
            count = 0
            comparator = (lambda a, b: a <= b) if step_val > 0 else (lambda a, b: a >= b)
            while comparator(current, end_val):
                if count >= 10000:
                    raise ScriptError("loop_limit")
                self.scopes[-1][node["var"]] = current
                try:
                    await self._exec_block(node.get("body", []), update=update, context=context, target=target)
                except LoopContinue:
                    count += 1
                    current += step_val
                    continue
                except LoopBreak:
                    break
                current += step_val
                count += 1
            return None
        if op == "try":
            try:
                await self._exec_block(node.get("body", []), update=update, context=context, target=target)
            except Exception as exc:  # noqa: BLE001
                if isinstance(exc, ScriptError):
                    err_obj = {"code": exc.code, "message": exc.message, "stack": exc.stack}
                else:
                    err_obj = {
                        "code": getattr(exc, "code", "runtime_error"),
                        "message": str(exc),
                        "stack": traceback.format_exc().splitlines(),
                    }
                self.scopes[-1][node.get("catch_var", "error")] = err_obj
                await self._exec_block(node.get("catch", []), update=update, context=context, target=target)
            finally:
                if node.get("finally"):
                    await self._exec_block(node.get("finally", []), update=update, context=context, target=target)
            return None
        if op == "call":
            args = [self._eval_expr(arg, update=update, context=context, target=target) for arg in node.get("args", [])]
            func_name = node.get("func")
            return await self._invoke_function(func_name, args, update=update, context=context, target=target)
        if op == "return":
            value = self._eval_expr(node["expr"], update=update, context=context, target=target) if node.get("expr") else None
            raise ReturnSignal(value)
        if op == "throw":
            raise ScriptError(self._eval_expr(node["expr"], update=update, context=context, target=target))
        if op == "break":
            raise LoopBreak()
        if op == "continue":
            raise LoopContinue()
        return None

    def _coerce_literal(self, value: Any, expected: str) -> Any:
        if value is None:
            return None
        if isinstance(value, str):
            lowered = value.lower()
            if lowered == "null":
                return None
            if lowered == "true":
                return True
            if lowered == "false":
                return False
            if expected and "number" in expected and re.fullmatch(r"[-+]?[0-9]*\.?[0-9]+", value):
                try:
                    return float(value)
                except ValueError:
                    return value
        return value

    def _coerce_value(self, value: Any, expected: str) -> Any:
        coerced = self._coerce_literal(value, expected)
        if isinstance(coerced, str) and "number" in expected and coerced.isdigit():
            return float(coerced)
        return coerced

    def _bind_params(self, params: list[dict], args: list[Any]) -> dict:
        bound: dict[str, Any] = {}
        missing = object()
        if len(args) > len(params):
            raise ScriptError("too_many_args")
        for idx, param in enumerate(params):
            provided = args[idx] if idx < len(args) else missing
            if provided is missing:
                default = param.get("default")
                if default is not None or "null" in (param.get("type") or ""):
                    provided = self._coerce_literal(default, param["type"])
                else:
                    raise ScriptError(f"Требуется аргумент {param['name']}")
            value = self._coerce_value(provided, param["type"])
            if not self._type_matches(value, param["type"]):
                raise ScriptError(f"Аргумент {param['name']} должен быть типа {param['type']}")
            bound[param["name"]] = value
        return bound

    async def _invoke_function(self, func_name: str, args: list[Any], *, update=None, context=None, target=None):
        if self.current_script and func_name in getattr(self.current_script, "functions", {}):
            overload = self._select_overload(func_name, args)
            if overload is None:
                raise ScriptError(f"Не найдена подходящая функция {func_name}")
            bound = self._bind_params(overload.params, [self.to_string(a) if isinstance(a, str) else a for a in args])
            self.scopes.append(bound)
            try:
                result = await self._exec_block(overload.body, update=update, context=context, target=target)
            except ReturnSignal as ret:
                result = ret.value
            finally:
                self.scopes.pop()
            if overload.returns and not self._type_matches(result, overload.returns):
                raise ScriptError(f"Возврат {func_name} не соответствует {overload.returns}")
            return result
        module_callable = self._resolve_module_callable(func_name)
        if module_callable:
            result = module_callable(*args)
            if asyncio.iscoroutine(result):
                return await result
            return result
        target_func = self._resolve_callable(func_name)
        if target_func:
            result = target_func(*args)
            if asyncio.iscoroutine(result):
                return await result
            return result
        raise ScriptError(f"Неизвестная функция {func_name}")

    async def _call_module_function(self, module_script: Any, func_name: str, args: list[Any]):
        previous_script = self.current_script
        self.current_script = module_script
        self._load_consts()
        self._load_imports(module_script)
        overloads = getattr(module_script, "functions", {}).get(func_name, [])
        if not overloads:
            raise ScriptError(f"Функция {func_name} не найдена в модуле")
        overload = self._select_overload(func_name, args)
        if overload is None:
            overload = overloads[0]
        bound = self._bind_params(overload.params, [self.to_string(a) if isinstance(a, str) else a for a in args])
        self.scopes.append(bound)
        try:
            result = await self._exec_block(overload.body)
        except ReturnSignal as ret:
            result = ret.value
        finally:
            self.scopes.pop()
            self.current_script = previous_script
        return result

    def _select_overload(self, name: str, args: list[Any]):
        overloads = self.current_script.functions.get(name, []) if self.current_script else []
        best: tuple[int, Any] | None = None
        for fn in overloads:
            score = self._overload_score(fn, args)
            if score is None:
                continue
            if best is None or score > best[0]:
                best = (score, fn)
        if best:
            return best[1]
        return overloads[0] if overloads else None

    def _overload_score(self, fn: Any, args: list[Any]) -> int | None:
        try:
            bound = self._bind_params(fn.params, args)
        except ScriptError:
            return None
        score = 0
        for idx, param in enumerate(fn.params):
            provided = args[idx] if idx < len(args) else param.get("default")
            if provided is None:
                continue
            if self._type_matches(self._coerce_value(provided, param["type"]), param["type"]):
                score += 2
            else:
                score += 1
        score += len(bound)
        return score

    def _resolve_callable(self, name: str):
        parsed = parse_function_name(name)
        if parsed:
            return lambda *args: execute_function(name, list(args))
        if "." in name:
            obj_name, func_name = name.split(".", 1)
            obj = getattr(self, obj_name, None)
            if obj and hasattr(obj, func_name):
                return getattr(obj, func_name)
        return getattr(self, name.replace(".", "_"), None)

    def _resolve_module_callable(self, name: str):
        for module_name, compiled in self._module_cache.items():
            prefix = f"{module_name}."
            if not name.startswith(prefix):
                continue
            func_name = name[len(prefix) :]
            return lambda *args, _compiled=compiled, _fn=func_name: self._call_module_function(_compiled, _fn, list(args))
        if name in self.modules:
            return self.modules[name]
        return None

    def _load_consts(self) -> None:
        if not self.current_script:
            return
        for key, value in getattr(self.current_script, "consts", {}).items():
            try:
                self.globals.setdefault(key, self._eval_expr(value))
            except Exception:
                self.globals.setdefault(key, value)

    def _prepare_script(self, script: Any) -> None:
        self.current_script = script
        self._load_consts()
        self._load_imports(script)
        self._ensure_schedule_loaded()

    def _module_base_dir(self, script: Any) -> Path | None:
        path_text = getattr(script, "path", None)
        if not path_text:
            return None
        return Path(path_text).resolve().parent

    def _import_module(self, module: str, base_dir: Path | None) -> Any:
        if module in self._module_cache:
            return self._module_cache[module]
        if module in self._module_loading:
            raise ScriptError(f"Циклический импорт {module}")
        if base_dir is None:
            raise ScriptError(f"Неизвестный модуль {module}")
        target_path = base_dir / Path(*module.split("."))
        if target_path.suffix != ".escript":
            target_path = target_path.with_suffix(".escript")
        if not target_path.exists():
            raise ScriptError(f"Модуль {module} не найден по пути {target_path}")
        self._module_loading.add(module)
        try:
            compiler = EScriptCompiler(script_name=module)
            compiled = compiler.compile({"source": target_path.read_text(encoding="utf-8"), "path": str(target_path)}, script_id=0)
            if compiled is None:
                raise ScriptError("Ошибка компиляции модуля")
            self._module_cache[module] = compiled
            self._load_imports(compiled)
            return compiled
        finally:
            self._module_loading.discard(module)

    def _load_imports(self, script: Any) -> None:
        base_dir = self._module_base_dir(script)
        for module in getattr(script, "imports", []) or []:
            compiled = self._import_module(module, base_dir)
            if compiled:
                self.modules[module] = ModuleNamespace(self, compiled, module)

    def _eval_expr(self, expr: str, *, update=None, context=None, target=None):
        import ast

        expr = expr.strip()
        local_vars: dict[str, Any] = {}
        for scope in self.scopes:
            local_vars.update(scope)
        local_vars.update({"ctx": update, "context": context, "target": target})
        tree = ast.parse(expr, mode="eval")
        return self._eval_ast(tree.body, local_vars)

    def _eval_ast(self, node, env: dict[str, Any]):
        import ast
        import operator

        allowed_ops = {
            ast.Add: operator.add,
            ast.Sub: operator.sub,
            ast.Mult: operator.mul,
            ast.Div: operator.truediv,
            ast.Mod: operator.mod,
            ast.Pow: operator.pow,
        }
        compare_ops = {
            ast.Eq: operator.eq,
            ast.NotEq: operator.ne,
            ast.Lt: operator.lt,
            ast.LtE: operator.le,
            ast.Gt: operator.gt,
            ast.GtE: operator.ge,
        }
        unary_ops = {ast.UAdd: operator.pos, ast.USub: operator.neg, ast.Not: operator.not_}

        if isinstance(node, ast.Constant):
            return node.value
        if isinstance(node, ast.Name):
            return env.get(node.id, self._builtins_for_eval().get(node.id, UNDEFINED))
        if isinstance(node, ast.BinOp):
            if type(node.op) not in allowed_ops:
                raise ScriptError("Недопустимая операция")
            return allowed_ops[type(node.op)](self._eval_ast(node.left, env), self._eval_ast(node.right, env))
        if isinstance(node, ast.UnaryOp):
            if type(node.op) not in unary_ops:
                raise ScriptError("Недопустимый унарный оператор")
            return unary_ops[type(node.op)](self._eval_ast(node.operand, env))
        if isinstance(node, ast.BoolOp):
            if isinstance(node.op, ast.And):
                result = True
                for value in node.values:
                    result = bool(self._eval_ast(value, env))
                    if not result:
                        break
                return result
            if isinstance(node.op, ast.Or):
                result = False
                for value in node.values:
                    result = bool(self._eval_ast(value, env))
                    if result:
                        break
                return result
            raise ScriptError("Недопустимый логический оператор")
        if isinstance(node, ast.Compare):
            left = self._eval_ast(node.left, env)
            for op, comparator in zip(node.ops, node.comparators):
                if type(op) not in compare_ops:
                    raise ScriptError("Недопустимое сравнение")
                right = self._eval_ast(comparator, env)
                if not compare_ops[type(op)](left, right):
                    return False
                left = right
            return True
        if isinstance(node, ast.Attribute):
            value = self._eval_ast(node.value, env)
            if value is None:
                return None
            if isinstance(value, dict):
                return value.get(node.attr)
            return getattr(value, node.attr, None)
        if isinstance(node, ast.Subscript):
            target = self._eval_ast(node.value, env)
            if target is None:
                return None
            key = self._eval_ast(node.slice, env)
            try:
                return target[key]
            except Exception:
                return None
        if isinstance(node, ast.Index):
            return self._eval_ast(node.value, env)
        if isinstance(node, ast.Dict):
            return {self._eval_ast(k, env): self._eval_ast(v, env) for k, v in zip(node.keys, node.values)}
        if isinstance(node, ast.List):
            return [self._eval_ast(elt, env) for elt in node.elts]
        if isinstance(node, ast.Tuple):
            return tuple(self._eval_ast(elt, env) for elt in node.elts)
        if isinstance(node, ast.Call):
            func_expr = node.func
            func_obj = None
            if isinstance(func_expr, ast.Name):
                func_obj = env.get(func_expr.id) or self._resolve_callable(func_expr.id) or self._resolve_module_callable(
                    func_expr.id
                )
            elif isinstance(func_expr, ast.Attribute):
                target_obj = self._eval_ast(func_expr.value, env)
                func_obj = getattr(target_obj, func_expr.attr, None)
            if func_obj is None:
                raise ScriptError(f"Неизвестная функция {getattr(func_expr, 'id', 'unknown')}")
            args = [self._eval_ast(arg, env) for arg in node.args]
            if asyncio.iscoroutinefunction(func_obj):
                raise ScriptError("Асинхронные вызовы в выражениях запрещены")
            result = func_obj(*args)
            if asyncio.iscoroutine(result):
                raise ScriptError("Асинхронные вызовы в выражениях запрещены")
            return result
        raise ScriptError(f"Запрещенное выражение: {type(node).__name__}")

    def _builtins_for_eval(self) -> dict:
        builtins: dict[str, Any] = {
            "true": True,
            "false": False,
            "null": None,
            "len": len,
            "abs": abs,
            "int": int,
            "float": float,
            "str": str,
        }
        # expose all runtime callables plus namespace proxies to expression eval
        for name in dir(self):
            if name.startswith("_"):
                continue
            attr = getattr(self, name)
            if callable(attr):
                builtins[name] = attr
        builtins.update(self._namespaces)
        builtins.update(self.modules)
        return builtins

    def _type_matches(self, value: Any, expected: str) -> bool:
        if not expected:
            return True
        if "|" in expected:
            return any(self._type_matches(value, part.strip()) for part in expected.split("|"))
        if expected == "any":
            return True
        if expected == "null":
            return value is None
        if expected == "number":
            return isinstance(value, (int, float)) and not isinstance(value, bool)
        if expected == "string":
            return isinstance(value, str)
        if expected == "bool":
            return isinstance(value, bool)
        if expected == "array":
            return isinstance(value, list)
        if expected == "object":
            return isinstance(value, dict)
        return False

    # region balance/treasury/locks helpers
    async def balance_get(self, user_id: str) -> int:
        if self.storage and hasattr(self.storage, "get_balance"):
            try:
                return int(await self.storage.get_balance(self._chat_id, int(user_id)))
            except Exception as exc:  # noqa: BLE001
                self.error_state["last"] = {"code": "balance_get", "message": str(exc)}
        return int(self.globals.get(f"balance:{user_id}", 0))

    async def balance_can_remove(self, user_id: str, amount: int) -> bool:
        return await self.balance_get(user_id) >= amount

    async def balance_add(self, user_id: str, amount: int, reason: str | None = None) -> None:
        if self.storage and hasattr(self.storage, "adjust_balance"):
            try:
                await self.storage.adjust_balance(self._chat_id, int(user_id), None, int(amount))
                return
            except Exception as exc:  # noqa: BLE001
                self.error_state["last"] = {"code": "balance_add", "message": str(exc)}
        key = f"balance:{user_id}"
        self.globals[key] = int(self.globals.get(key, 0)) + int(amount)

    async def balance_remove(self, user_id: str, amount: int, reason: str | None = None) -> bool:
        if self.storage and hasattr(self.storage, "adjust_balance"):
            try:
                updated = await self.storage.adjust_balance(
                    self._chat_id,
                    int(user_id),
                    None,
                    -int(amount),
                    prevent_negative=True,
                )
                return updated is not None
            except Exception as exc:  # noqa: BLE001
                self.error_state["last"] = {"code": "balance_remove", "message": str(exc)}
                return False
        if not await self.balance_can_remove(user_id, amount):
            return False
        key = f"balance:{user_id}"
        self.globals[key] = int(self.globals.get(key, 0)) - int(amount)
        return True

    async def balance_transfer_atomic(self, from_id: str, to_id: str, amount: int, reason: str | None = None) -> bool:
        if self.storage and hasattr(self.storage, "transfer_balance"):
            try:
                result = await self.storage.transfer_balance(
                    chat_id=self._chat_id,
                    sender_id=int(from_id),
                    sender_username=None,
                    receiver_id=int(to_id),
                    receiver_username=None,
                    amount=int(amount),
                    idempotency_key=str(uuid.uuid4()),
                    day=int(time.time() // 86400),
                )
                return result is not None
            except Exception as exc:  # noqa: BLE001
                self.error_state["last"] = {"code": "balance_transfer", "message": str(exc)}
                return False
        if not await self.balance_can_remove(from_id, amount):
            return False
        await self.balance_remove(from_id, amount, reason=reason)
        await self.balance_add(to_id, amount, reason=reason)
        return True

    def economy_lock(self, scope: str, key: str, seconds: int = 5) -> bool:
        locks = self._locks.setdefault(scope, {})
        now = time.time()
        # prune expired
        expired = [k for k, exp in locks.items() if exp <= now]
        for k in expired:
            locks.pop(k, None)
        if key in locks:
            return False
        locks[key] = now + max(1, seconds)
        return True

    def economy_unlock(self, scope: str, key: str) -> None:
        self._locks.setdefault(scope, {}).pop(key, None)

    async def treasury_get(self) -> int:
        if self.storage and hasattr(self.storage, "get_treasury"):
            try:
                return int(await self.storage.get_treasury(self._chat_id))
            except Exception as exc:  # noqa: BLE001
                self.error_state["last"] = {"code": "treasury_get", "message": str(exc)}
        return int(self.globals.get("__treasury", 0))

    async def treasury_add(self, amount: int, reason: str | None = None) -> None:
        if self.storage and hasattr(self.storage, "adjust_treasury"):
            try:
                await self.storage.adjust_treasury(self._chat_id, int(amount), prevent_negative=False)
                return
            except Exception as exc:  # noqa: BLE001
                self.error_state["last"] = {"code": "treasury_add", "message": str(exc)}
        self.globals["__treasury"] = await self.treasury_get() + int(amount)

    async def treasury_remove(self, amount: int, reason: str | None = None) -> bool:
        if self.storage and hasattr(self.storage, "adjust_treasury"):
            try:
                updated = await self.storage.adjust_treasury(self._chat_id, -int(amount), prevent_negative=True)
                return updated is not None
            except Exception as exc:  # noqa: BLE001
                self.error_state["last"] = {"code": "treasury_remove", "message": str(exc)}
                return False
        current = await self.treasury_get()
        if current < amount:
            return False
        self.globals["__treasury"] = current - int(amount)
        return True

    # endregion

    # region kv/persist/db helpers (in-memory)
    def _kv_store(self) -> dict:
        return self.globals.setdefault("__kv", {})

    def _persist_store(self, user_id: str) -> dict:
        root = self.globals.setdefault("__persist", {})
        return root.setdefault(user_id, {})

    def kv_incr(self, key: str, delta: int = 1, init: int = 0) -> int:
        store = self._kv_store()
        store.setdefault(key, init)
        store[key] = int(store[key]) + int(delta)
        return int(store[key])

    def persist_incr(self, user_id: str, key: str, delta: int = 1, init: int = 0) -> int:
        store = self._persist_store(user_id)
        store.setdefault(key, init)
        store[key] = int(store[key]) + int(delta)
        return int(store[key])

    def kv_set_ttl(self, key: str, value: Any, seconds: int) -> None:
        store = self._kv_store()
        expires_at = time.time() + seconds
        store[key] = value
        store.setdefault("__ttl__", {})[key] = expires_at

    def kv_get_meta(self, key: str) -> dict:
        store = self._kv_store()
        ttl_map = store.get("__ttl__", {})
        expires_at = ttl_map.get(key)
        if expires_at and expires_at <= time.time():
            store.pop(key, None)
            ttl_map.pop(key, None)
        exists = key in store
        value = store.get(key)
        return {"exists": exists, "expires_at": expires_at, "type": self.type_of(value), "size": len(json.dumps(value)) if exists else 0}

    def kv_list(self, prefix: str, limit: int = 100, cursor: str | None = None) -> dict:
        store = self._kv_store()
        ttl_map = store.get("__ttl__", {})
        now = time.time()
        for k, exp in list(ttl_map.items()):
            if exp <= now:
                store.pop(k, None)
                ttl_map.pop(k, None)
        keys = [k for k in store.keys() if k.startswith(prefix) and k != "__ttl__"]
        return {"keys": keys[:limit], "cursor": None}

    def persist_list(self, user_id: str, prefix: str, limit: int = 100, cursor: str | None = None) -> dict:
        store = self._persist_store(user_id)
        keys = [k for k in store.keys() if k.startswith(prefix)]
        return {"keys": keys[:limit], "cursor": None}

    def db_transaction(self, ops: list[dict]) -> dict:
        results = []
        for op in ops:
            kind = op.get("op")
            key = op.get("key")
            if kind == "set":
                self._kv_store()[key] = op.get("value")
                results.append(True)
            elif kind == "del":
                results.append(self._kv_store().pop(key, None) is not None)
            elif kind == "incr":
                results.append(self.kv_incr(key, op.get("delta", 1), op.get("init", 0)))
            elif kind == "ttl":
                self.kv_set_ttl(key, self._kv_store().get(key), op.get("seconds", 0))
                results.append(True)
            else:
                results.append(False)
        return {"results": results}

    # endregion

    # region http/crypto/logging stubs
    def http_get(self, url: str, headers: dict | None = None, timeout_ms: int = 5000) -> dict:
        return self.http_request("GET", url, headers=headers, body=None, timeout_ms=timeout_ms)

    def http_post(self, url: str, json: Any, headers: dict | None = None, timeout_ms: int = 5000) -> dict:
        return self.http_request("POST", url, headers=headers, body=json, timeout_ms=timeout_ms)

    def http_request(self, method: str, url: str, headers: dict | None = None, body: Any = None, timeout_ms: int = 5000) -> dict:
        parsed_host = None
        try:
            from urllib.parse import urlparse

            parsed_host = urlparse(url).hostname
        except Exception:
            parsed_host = None
        if parsed_host and self.http_allowlist and parsed_host not in self.http_allowlist and "*" not in self.http_allowlist:
            raise ScriptError("http_forbidden", "domain_not_allowed")
        for idx, mock in enumerate(list(self._mock_http)):
            if mock.get("method", method).upper() == method.upper() and mock.get("url") == url:
                self._mock_http.pop(idx)
                return mock.get("response", {"status": 200, "headers": headers or {}, "body": None})
        try:
            import httpx

            with httpx.Client(timeout=timeout_ms / 1000) as client:
                resp = client.request(method, url, headers=headers, json=body if isinstance(body, (dict, list)) else None, content=None if isinstance(body, (dict, list)) else body)
                return {"status": resp.status_code, "headers": dict(resp.headers), "body": resp.text}
        except Exception as exc:  # noqa: BLE001
            raise ScriptError("http", str(exc), stack=traceback.format_exc().splitlines())

    def crypto_hmac_sha256(self, text: str, secret: str, output: str = "hex") -> str:
        import hmac
        import hashlib

        digest = hmac.new(secret.encode(), text.encode(), hashlib.sha256).digest()
        return digest.hex() if output == "hex" else digest

    def crypto_sha256(self, text: str, output: str = "hex") -> str:
        import hashlib

        digest = hashlib.sha256(text.encode()).digest()
        return digest.hex() if output == "hex" else digest

    def webhook_emit(self, event: str, payload: Any) -> bool:
        try:
            endpoint = self.webhook_endpoints.get(event)
            if not endpoint:
                self.error_state["last"] = {"code": "webhook", "message": "unknown_event"}
                return False
            self.http_post(endpoint, payload)
            return True
        except Exception:  # noqa: BLE001
            self.error_state["last"] = {"code": "webhook", "message": "emit_failed"}
            return False

    def rate_limit(self, key: str, per_seconds: int, limit: int) -> bool:
        window = self._rate_limits.setdefault(key, [])
        now = time.time()
        window[:] = [ts for ts in window if now - ts < per_seconds]
        if len(window) >= limit:
            return False
        window.append(now)
        return True

    def log(self, level: str, message: str, data: Any | None = None) -> None:
        self.globals.setdefault("__logs", []).append({"level": level, "message": message, "data": data})

    def assert_(self, condition: bool, message: str = "assert_failed") -> None:
        if not condition:
            raise ScriptError(message)

    def metrics_incr(self, name: str, value: int = 1, tags: dict | None = None) -> None:
        self.globals.setdefault("__metrics", []).append({"name": name, "value": value, "tags": tags or {}})

    def error_last(self) -> Any:
        return self.error_state.get("last")

    # endregion

    # region messaging/UI stubs
    def ui_form(self, fields: list, title: str = "") -> dict:
        form_id = str(uuid.uuid4())
        form = {"id": form_id, "fields": fields, "title": title}
        self._forms[form_id] = form
        if self._mock_form_responses:
            response = self._mock_form_responses.pop(0)
            self._record_form_submission(form_id, response)
        return form

    def ui_form_submit(self, form: dict | str, values: dict) -> bool:
        form_id = form if isinstance(form, str) else form.get("id")
        if not form_id or form_id not in self._forms:
            raise ScriptError("form_not_found", "Форма не зарегистрирована")
        self._record_form_submission(form_id, values)
        return True

    def _record_form_submission(self, form_id: str, values: dict) -> None:
        form = self._forms.get(form_id, {})
        cleaned = {}
        for field in form.get("fields", []):
            name = field.get("name")
            if name and name in values:
                cleaned[name] = values[name]
        self.globals.setdefault("__form_responses", {})[form_id] = cleaned
        self.globals["__last_form"] = {"id": form_id, "values": cleaned, "title": form.get("title")}

    def _snapshot_scope(self) -> dict:
        merged: dict[str, Any] = {}
        for scope in self.scopes:
            merged.update(scope)
        return merged

    def _build_keyboard(self, buttons: list | None) -> InlineKeyboardMarkup | None:
        if not buttons:
            return None
        rows: list[list[InlineKeyboardButton]] = []
        iterable = buttons if isinstance(buttons, list) else []
        for raw_row in iterable:
            row_items = raw_row if isinstance(raw_row, list) else [raw_row]
            row: list[InlineKeyboardButton] = []
            for btn in row_items:
                if isinstance(btn, dict):
                    text = str(btn.get("text") or btn.get("label") or "")
                    action_id = btn.get("action") or btn.get("callback") or btn.get("do")
                    url = btn.get("url")
                    if url:
                        row.append(InlineKeyboardButton(text, url=url))
                    elif action_id is not None:
                        callback = f"escriptbtn:{self.script_id}:{action_id}"
                        row.append(InlineKeyboardButton(text, callback_data=callback))
                    else:
                        continue
                else:
                    row.append(InlineKeyboardButton(str(btn), callback_data=f"escriptbtn:{self.script_id}:{btn}"))
            if row:
                rows.append(row)
        return InlineKeyboardMarkup(rows) if rows else None

    async def message_send(self, chat_id: str | None = None, text: str = "", buttons: list | None = None, reply_to: str | None = None) -> str:
        fallback_chat = None
        if self._active_update and getattr(self._active_update, "effective_chat", None):
            fallback_chat = getattr(self._active_update.effective_chat, "id", None)
        chat_target = chat_id or fallback_chat or self._chat_id

        if not chat_target or not self._active_context:
            msg_id = str(uuid.uuid4())
            self.globals.setdefault("__messages", {})[msg_id] = {"chat_id": chat_target, "text": text, "buttons": buttons, "reply_to": reply_to}
            return msg_id

        thread_id = None
        if self._active_update and getattr(self._active_update, "effective_message", None):
            thread_id = getattr(self._active_update.effective_message, "message_thread_id", None)
        if thread_id is None and getattr(self.bot, "chat_threads", None) is not None:
            try:
                thread_id = self.bot.chat_threads.get(int(chat_target))  # type: ignore[arg-type]
            except Exception:
                thread_id = None

        keyboard = self._build_keyboard(buttons)
        base_kwargs = {
            "chat_id": chat_target,
            "text": text,
            "reply_to_message_id": reply_to,
            "reply_markup": keyboard,
            "parse_mode": ParseMode.HTML,
        }
        if thread_id is not None:
            base_kwargs["message_thread_id"] = thread_id

        attempts = [base_kwargs]
        if thread_id is not None:
            without_thread = dict(base_kwargs)
            without_thread.pop("message_thread_id", None)
            attempts.append(without_thread)
        if fallback_chat is not None and fallback_chat != chat_target:
            fallback_kwargs = dict(base_kwargs, chat_id=fallback_chat)
            attempts.append(fallback_kwargs)
            if "message_thread_id" in fallback_kwargs:
                stripped = dict(fallback_kwargs)
                stripped.pop("message_thread_id", None)
                attempts.append(stripped)

        for send_kwargs in attempts:
            try:
                sent = await self._active_context.bot.send_message(**send_kwargs)
                if keyboard and getattr(self.bot, "escripts", None):
                    snapshot = self._snapshot_scope()
                    try:
                        self.bot.escripts.store_button_context(sent.message_id, snapshot)
                    except Exception:
                        pass
                return str(sent.message_id)
            except Exception as exc:  # noqa: BLE001
                logger.warning(
                    "Failed to send escript message (chat=%s thread=%s): %s",
                    send_kwargs.get("chat_id"),
                    send_kwargs.get("message_thread_id"),
                    exc,
                )

        msg_id = str(uuid.uuid4())
        self.globals.setdefault("__messages", {})[msg_id] = {"chat_id": chat_target, "text": text, "buttons": buttons, "reply_to": reply_to}
        return msg_id

    async def message_edit(self, message_id: str, text: str, buttons: list | None = None) -> bool:
        if not self._active_context or not self._active_update or not self._active_update.effective_chat:
            return False
        keyboard = self._build_keyboard(buttons)
        try:
            await self._active_context.bot.edit_message_text(
                chat_id=self._active_update.effective_chat.id,
                message_id=int(message_id),
                text=text,
                reply_markup=keyboard,
                parse_mode=ParseMode.HTML,
            )
            return True
        except Exception:
            return False

    async def message_delete(self, message_id: str) -> bool:
        if not self._active_context or not self._active_update or not self._active_update.effective_chat:
            return False
        try:
            await self._active_context.bot.delete_message(
                chat_id=self._active_update.effective_chat.id,
                message_id=int(message_id),
            )
            return True
        except Exception:
            return False

    def pin_set(self, chat_id: str, message_id: str) -> bool:
        self.globals["__pin"] = {"chat_id": chat_id, "message_id": message_id}
        return True

    def pin_clear(self, chat_id: str) -> bool:
        self.globals.pop("__pin", None)
        return True

    def pin_get(self, chat_id: str) -> str | None:
        pin = self.globals.get("__pin")
        return pin.get("message_id") if pin and pin.get("chat_id") == chat_id else None

    def thread_storage(self, scope_id: str, key: str, value: Any, ttl: int | None = None) -> None:
        self.globals.setdefault("__thread", {}).setdefault(scope_id, {})[key] = value

    def thread_storage_get(self, scope_id: str, key: str, default: Any = None) -> Any:
        return self.globals.get("__thread", {}).get(scope_id, {}).get(key, default)

    def thread_storage_del(self, scope_id: str, key: str) -> bool:
        return self.globals.get("__thread", {}).get(scope_id, {}).pop(key, None) is not None

    # endregion


class EScriptManager:
    def __init__(self, bot: Any) -> None:
        self.bot = bot
        self.scripts: dict[int, CompiledScript] = {}

    def script_path(self, chat_id: int, script_id: int) -> uuid.UUID | Any:
        from pathlib import Path

        path = Path("escripts") / str(chat_id)
        path.mkdir(parents=True, exist_ok=True)
        return path / f"{script_id}.escript"

    def log_path(self, chat_id: int, script_id: int) -> Any:
        from pathlib import Path

        path = Path("escripts") / str(chat_id)
        path.mkdir(parents=True, exist_ok=True)
        return path / f"{script_id}.log.txt"

    async def refresh_script(self, chat_id: int, script_id: int) -> None:
        path = self.script_path(chat_id, script_id)
        if not path.exists():
            self.scripts.pop(chat_id, None)
            return
        data = path.read_text(encoding="utf-8")
        compiler = EScriptCompiler(script_name=path.name)
        compiled = compiler.compile(data, script_id=script_id)
        if compiled:
            self.scripts.setdefault(chat_id, compiled)

    async def handle_command(
        self,
        chat_id: int,
        message: Any | None = None,
        command: str | None = None,
        args: list[str] | None = None,
        update: Any | None = None,
        context: Any | None = None,
        plan_code: str | None = None,
        override_only: bool = False,
    ) -> bool:
        """Execute a compiled e-script command if present.

        Extra keyword arguments like ``plan_code`` or ``override_only`` are accepted
        for compatibility with the bot core call sites; they are currently ignored
        by the runtime but allow the dispatcher to route commands without raising
        unexpected keyword errors.
        """

        script = self.scripts.get(chat_id)
        if not script or not command:
            return False
        for cmd in script.commands:
            if cmd.name == command:
                runtime = EScriptRuntime(
                    bot=self.bot,
                    chat_id=chat_id,
                    script_id=script.commands.index(cmd),
                    storage=self.bot.storage if hasattr(self.bot, "storage") else None,
                )
                await runtime.run_actions(cmd.actions)
                return True
        return False

    async def handle_button(self, chat_id: int, script_id: int, action_id: str, update: Any, context: Any) -> None:
        # Buttons can be mapped to commands by name
        await self.handle_command(chat_id, None, action_id, [], update, context)

    async def run_daily_events(self, chat_id: int, application: Any) -> None:
        script = self.scripts.get(chat_id)
        if not script:
            return
        for event in script.events:
            if isinstance(event, dict) and event.get("when") == "daily":
                runtime = EScriptRuntime(bot=self.bot, chat_id=chat_id, script_id=0, storage=self.bot.storage if hasattr(self.bot, "storage") else None)
                await runtime.run_actions(event.get("actions", []))

    async def active_commands(self, chat_id: int) -> list[tuple[str, str]]:
        script = self.scripts.get(chat_id)
        if not script:
            return []
        return [(cmd.name, cmd.when or "") for cmd in script.commands]
