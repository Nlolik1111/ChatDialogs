from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

import copy
from urllib.parse import urlparse

from .models import CompiledCommand, CompiledFunction, CompiledScript


@dataclass
class _Line:
    indent: int
    text: str
    number: int


_BASE_TYPES = {"number", "string", "bool", "array", "object", "any", "null"}


def _strip_comment(line: str) -> str:
    if "#" not in line:
        return line.rstrip("\n")
    escaped = False
    result = []
    for ch in line:
        if ch == "#" and not escaped:
            break
        if ch == "\\" and not escaped:
            escaped = True
        else:
            escaped = False
        result.append(ch)
    return "".join(result).rstrip("\n")


class ScriptSyntaxError(Exception):
    pass


class ScriptParser:
    def __init__(self, *, script_name: str, warnings: Optional[list[str]] | None = None) -> None:
        self.script_name = script_name
        self.commands: Dict[str, CompiledCommand] = {}
        self.functions: Dict[str, list[CompiledFunction]] = {}
        self.imports: list[str] = []
        self.consts: dict[str, Any] = {}
        self.macros: dict[str, list[dict]] = {}
        self.events: dict[str, list[dict]] = {}
        self.grammar_text = self._build_grammar()
        self.warnings: list[str] = warnings if warnings is not None else []

    def parse(self, source: str) -> None:
        lines = self._prepare_lines(source)
        idx = 0
        while idx < len(lines):
            idx = self._parse_top_level(lines, idx)
        self._expand_macros()

    def _prepare_lines(self, source: str) -> list[_Line]:
        def balance_delta(segment: str) -> int:
            depth = 0
            escaped = False
            quote: str | None = None
            for ch in segment:
                if escaped:
                    escaped = False
                    continue
                if ch == "\\":
                    escaped = True
                    continue
                if quote:
                    if ch == quote:
                        quote = None
                    continue
                if ch in {'"', "'"}:
                    quote = ch
                    continue
                if ch in {"(", "[", "{"}:
                    depth += 1
                if ch in {")","]","}"}:
                    depth -= 1
            return depth

        prepared: list[_Line] = []
        pending_text: str | None = None
        pending_indent = 0
        pending_start = 0
        pending_balance = 0

        for idx, raw in enumerate(source.splitlines(), start=1):
            if "\t" in raw:
                raise ScriptSyntaxError(f"Строка {idx}: табуляции не поддерживаются, используйте пробелы")
            stripped = _strip_comment(raw)
            text = stripped.strip()
            if pending_text is None and not text:
                continue
            indent = pending_indent if pending_text is not None else len(raw) - len(raw.lstrip(" "))
            if indent % 2 != 0:
                raise ScriptSyntaxError("Строка {}: отступ должен быть кратен двум пробелам".format(idx))

            if pending_text is None:
                pending_text = text
                pending_start = idx
                pending_balance = 0
                pending_indent = indent
            else:
                # продолжение выражения: добавляем с пробелом, чтобы не склеивать слова
                pending_text = (pending_text + " " + text).strip()

            pending_balance += balance_delta(text)

            if pending_balance <= 0:
                prepared.append(_Line(pending_indent // 2, pending_text, pending_start))
                pending_text = None
                pending_indent = 0
                pending_start = 0
                pending_balance = 0

        if pending_text is not None:
            if pending_balance != 0:
                raise ScriptSyntaxError("Строка {}: незакрытые скобки в выражении".format(pending_start))
            prepared.append(_Line(pending_indent // 2, pending_text, pending_start))

        return prepared

    def _parse_top_level(self, lines: list[_Line], start: int) -> int:
        if start >= len(lines):
            return start
        line = lines[start]
        if line.indent != 0:
            raise ScriptSyntaxError(f"Строка {line.number}: верхний уровень не должен иметь отступов")
        if line.text.startswith("import "):
            module = line.text[len("import "):].strip()
            if not module:
                raise ScriptSyntaxError(f"Строка {line.number}: пустой import")
            self.imports.append(module)
            return start + 1
        if line.text.startswith("const "):
            name, expr = [p.strip() for p in line.text[len("const "):].split("=", 1)]
            self.consts[name] = expr
            return start + 1
        if line.text.startswith("macro "):
            return self._parse_macro(lines, start)
        if line.text.startswith("command "):
            return self._parse_command(lines, start)
        if line.text.startswith("fn "):
            return self._parse_function(lines, start)
        if line.text.startswith("on "):
            return self._parse_event(lines, start)
        raise ScriptSyntaxError(f"Строка {line.number}: ожидается import, const, macro, command или fn")

    def _parse_command(self, lines: list[_Line], start: int) -> int:
        line = lines[start]
        name, params, description, returns = self._parse_signature(line.text[len("command "):], allow_return=True)
        name = name.lower()
        description = description.strip() or "Описание отсутствует"
        body, end_idx = self._parse_block(lines, start + 1, line.indent + 1)
        self.commands[name] = CompiledCommand(
            name=name, params=params, body=body, description=description, returns=returns
        )
        return end_idx

    def _parse_function(self, lines: list[_Line], start: int) -> int:
        line = lines[start]
        name, params, description, returns = self._parse_signature(line.text[len("fn "):], allow_return=True)
        description = description.strip()
        body, end_idx = self._parse_block(lines, start + 1, line.indent + 1)
        self.functions.setdefault(name, []).append(
            CompiledFunction(name=name, params=params, body=body, returns=returns or "any")
        )
        return end_idx

    def _parse_macro(self, lines: list[_Line], start: int) -> int:
        line = lines[start]
        name, params, _, _ = self._parse_signature(line.text[len("macro "):], allow_return=False)
        body, end_idx = self._parse_block(lines, start + 1, line.indent + 1)
        self.macros[name] = {"params": params, "body": body}
        return end_idx

    def _parse_event(self, lines: list[_Line], start: int) -> int:
        line = lines[start]
        header = line.text[len("on "):]
        if ":" not in header:
            raise ScriptSyntaxError(f"Строка {line.number}: ожидается ':' после on <event>")
        event_head, _ = header.split(":", 1)
        parts = event_head.strip().split(" ", 1)
        event_name = parts[0].strip()
        event_value = parts[1].strip() if len(parts) > 1 else None
        body, end_idx = self._parse_block(lines, start + 1, line.indent + 1)
        self.events.setdefault(event_name, []).append({"name": event_name, "value": event_value, "actions": body})
        return end_idx

    def _parse_signature(self, text: str, *, allow_return: bool = False) -> tuple[str, list[dict], str, Optional[str]]:
        match = re.match(r"(?:\"([^\"]+)\"|([a-zA-Z_][a-zA-Z0-9_]*))\s*\((.*)\)\s*:?\s*(.*)", text)
        if not match:
            fallback = re.match(r"(?:\"([^\"]+)\"|([a-zA-Z_][a-zA-Z0-9_]*))\s*:?\s*(.*)", text)
            if fallback:
                quoted, bare, trailing = fallback.groups()
                self._warn("Сигнатура без скобок: параметры приняты как пустые, типы не заданы")
                return quoted or bare, [], trailing or "", None
            raise ScriptSyntaxError("Неверная сигнатура: ожидается name(args):")
        quoted, bare, params_raw, trailing = match.groups()
        name = quoted or bare
        params = self._parse_params(params_raw)
        returns = None
        if allow_return and "->" in trailing:
            trailing, returns = [p.strip() for p in trailing.split("->", 1)]
            returns = returns or None
        return name, params, trailing, returns

    def _parse_params(self, text: str) -> list[dict]:
        text = text.strip()
        if not text:
            return []
        parts = [p.strip() for p in text.split(",") if p.strip()]
        params: list[dict] = []
        for part in parts:
            if ":" not in part:
                name, type_and_default = part, "any"
                self._warn(f"Параметр '{part}' без типа: используется any")
            else:
                name, type_and_default = [v.strip() for v in part.split(":", 1)]
            type_name, default = self._parse_type_default(type_and_default)
            params.append({"name": name, "type": type_name, "default": default})
        return params

    def _parse_type_default(self, text: str) -> tuple[str, Optional[str]]:
        if "=" in text:
            type_name, default = [p.strip() for p in text.split("=", 1)]
        else:
            type_name, default = text.strip(), None
        parts = [p.strip() for p in type_name.split("|") if p.strip()]
        if not parts:
            self._warn("Пустой тип, подставлен any")
            return "any", default
        for part in parts:
            if part not in _BASE_TYPES:
                self._warn(
                    f"Неверный тип '{type_name}' (доступны: {', '.join(sorted(_BASE_TYPES))}), подставлен any"
                )
                return "any", default
        normalized = "|".join(parts)
        return normalized, default

    def _parse_block(self, lines: list[_Line], start: int, indent: int) -> tuple[list[dict], int]:
        body: list[dict] = []
        idx = start
        while idx < len(lines):
            line = lines[idx]
            if line.indent < indent:
                break
            if line.indent > indent:
                raise ScriptSyntaxError(f"Строка {line.number}: неверный уровень отступа")
            node, idx = self._parse_statement(lines, idx)
            body.append(node)
        return body, idx

    def _parse_statement(self, lines: list[_Line], idx: int) -> tuple[dict, int]:
        line = lines[idx]
        text = line.text.strip()
        if text.startswith("if "):
            condition = text[3:].rstrip(":").strip()
            then_body, next_idx = self._parse_block(lines, idx + 1, line.indent + 1)
            else_body: list[dict] = []
            if next_idx < len(lines) and lines[next_idx].indent == line.indent and lines[next_idx].text.startswith("else"):
                else_body, next_idx = self._parse_block(lines, next_idx + 1, line.indent + 1)
            return {"op": "if", "cond": condition, "then": then_body, "else": else_body}, next_idx
        if text.startswith("while "):
            condition = text[6:].rstrip(":").strip()
            body, next_idx = self._parse_block(lines, idx + 1, line.indent + 1)
            return {"op": "while", "cond": condition, "body": body}, next_idx
        if text.startswith("for "):
            header = text[4:].rstrip(":").strip()
            if " to " in header:
                var_name, range_tail = [p.strip() for p in header.split(" in ", 1)] if " in " in header else (None, header)
                if var_name is None:
                    var_name, range_tail = [p.strip() for p in header.split(" to ", 1)]
                    start_expr = var_name
                else:
                    start_expr, range_tail = [p.strip() for p in range_tail.split(" to ", 1)]
                step_expr = None
                if " step " in range_tail:
                    end_expr, step_expr = [p.strip() for p in range_tail.split(" step ", 1)]
                else:
                    end_expr = range_tail.strip()
                body, next_idx = self._parse_block(lines, idx + 1, line.indent + 1)
                return {
                    "op": "for_range",
                    "var": var_name,
                    "start": start_expr,
                    "end": end_expr,
                    "step": step_expr or "1",
                    "body": body,
                }, next_idx
            if " in " not in header:
                raise ScriptSyntaxError(f"Строка {line.number}: используйте 'for name in expr:'")
            var_name, expr = [p.strip() for p in header.split(" in ", 1)]
            body, next_idx = self._parse_block(lines, idx + 1, line.indent + 1)
            return {"op": "for", "var": var_name, "iter": expr, "body": body}, next_idx
        if text.startswith("try"):
            try_body, next_idx = self._parse_block(lines, idx + 1, line.indent + 1)
            catch_var = "error"
            catch_body: list[dict] = []
            finally_body: list[dict] = []
            if next_idx < len(lines) and lines[next_idx].indent == line.indent and lines[next_idx].text.startswith("catch"):
                catch_line = lines[next_idx].text
                if " " in catch_line:
                    catch_var_raw = catch_line.split(" ", 1)[1].strip()
                    catch_var = catch_var_raw.rstrip(":") or catch_var
                elif catch_line.endswith(":"):
                    catch_var = catch_var.rstrip(":") or catch_var
                catch_body, next_idx = self._parse_block(lines, next_idx + 1, line.indent + 1)
            if next_idx < len(lines) and lines[next_idx].indent == line.indent and lines[next_idx].text.startswith("finally"):
                finally_body, next_idx = self._parse_block(lines, next_idx + 1, line.indent + 1)
            return {
                "op": "try",
                "body": try_body,
                "catch": catch_body,
                "catch_var": catch_var,
                "finally": finally_body,
            }, next_idx
        if text.startswith("let "):
            let_node = self._parse_let(text[4:].strip(), line)
            return let_node, idx + 1
        if text.startswith("set "):
            name, expr = [p.strip() for p in text[4:].split("=", 1)]
            return {"op": "set", "name": name, "expr": expr}, idx + 1
        if text.startswith("return"):
            expr = text[len("return") :].strip()
            return {"op": "return", "expr": expr or None}, idx + 1
        if text.startswith("throw"):
            expr = text[len("throw") :].strip()
            return {"op": "throw", "expr": expr or "runtime_error"}, idx + 1
        if text.startswith("break"):
            return {"op": "break"}, idx + 1
        if text.startswith("continue"):
            return {"op": "continue"}, idx + 1
        call_match = re.match(r"([a-zA-Z_][a-zA-Z0-9_.]*)\s*\((.*)\)$", text)
        if call_match:
            func = call_match.group(1)
            args_text = call_match.group(2)
            args = self._parse_call_args(args_text)
            return {"op": "call", "func": func, "args": args}, idx + 1
        raise ScriptSyntaxError(f"Строка {line.number}: нераспознанное выражение '{text}'")

    def _parse_call_args(self, text: str) -> list[str]:
        if not text.strip():
            return []
        args: list[str] = []
        current = []
        depth = 0
        in_string = False
        quote = ""
        for ch in text:
            if in_string:
                current.append(ch)
                if ch == quote:
                    in_string = False
                continue
            if ch in {'"', "'"}:
                in_string = True
                quote = ch
                current.append(ch)
                continue
            if ch == "(" or ch == "{" or ch == "[":
                depth += 1
            if ch == ")" or ch == "}" or ch == "]":
                depth -= 1
            if ch == "," and depth == 0:
                args.append("".join(current).strip())
                current = []
                continue
            current.append(ch)
        if current:
            args.append("".join(current).strip())
        return [a for a in args if a]

    def _parse_let(self, text: str, line: _Line) -> dict:
        name: str
        type_name: str
        expr: str | None
        if ":" in text and "=" in text.split(":", 1)[1]:
            name, type_and_expr = [p.strip() for p in text.split(":", 1)]
            type_name, expr = self._parse_type_default(type_and_expr)
        elif ":" in text:
            name, type_part = [p.strip() for p in text.split(":", 1)]
            type_name, _ = self._parse_type_default(type_part)
            expr = "null"
            self._warn(f"Строка {line.number}: let без инициализации, подставлен null")
        elif "=" in text:
            name, expr = [p.strip() for p in text.split("=", 1)]
            type_name = "any"
            self._warn(f"Строка {line.number}: let без типа, подставлен any")
        else:
            name = text.strip()
            expr = "null"
            type_name = "any"
            self._warn(f"Строка {line.number}: let без типа и значения, подставлены any и null")
        if expr is None:
            expr = "null"
            self._warn(f"Строка {line.number}: инициализация отсутствует, подставлен null")
        return {"op": "let", "name": name, "type": type_name, "expr": expr}

    def _expand_macros(self) -> None:
        if not self.macros:
            return
        for command in list(self.commands.values()):
            command.body = self._inline_macros(command.body)
        for name, overloads in list(self.functions.items()):
            for fn in overloads:
                fn.body = self._inline_macros(fn.body)

    def _inline_macros(self, body: list[dict]) -> list[dict]:
        expanded: list[dict] = []
        for node in body:
            if node.get("op") == "call" and node.get("func") in self.macros:
                macro = self.macros[node["func"]]
                param_values = {p["name"]: (node.get("args") or [])[idx] if idx < len(node.get("args", [])) else None for idx, p in enumerate(macro["params"])}
                for macro_node in copy.deepcopy(macro["body"]):
                    expanded.append(self._substitute_node(macro_node, param_values))
                continue
            expanded.append(node)
        return expanded

    def _substitute_node(self, node: dict, values: dict[str, Optional[str]]) -> dict:
        def replace(expr: str) -> str:
            result = expr
            for key, val in values.items():
                if val is None:
                    continue
                result = re.sub(rf"\b{re.escape(key)}\b", str(val), result)
            return result

        new_node = copy.deepcopy(node)
        for key, value in list(new_node.items()):
            if isinstance(value, str):
                new_node[key] = replace(value)
            elif isinstance(value, list):
                new_node[key] = [self._substitute_node(v, values) if isinstance(v, dict) else v for v in value]
            elif isinstance(value, dict):
                new_node[key] = self._substitute_node(value, values)
        return new_node

    def _warn(self, message: str) -> None:
        if self.warnings is not None:
            self.warnings.append(message)

    def _build_grammar(self) -> str:
        return (
            "script ::= (command | fn)+\n"
            "command ::= 'command' NAME '(' params? ')' ':' NEWLINE block\n"
            "fn ::= 'fn' NAME '(' params? ')' ( '->' TYPE )? ':' NEWLINE block\n"
            "params ::= param (',' param)*\n"
            "param ::= NAME ':' TYPE ('=' EXPR)?\n"
            "block ::= INDENT statement+ DEDENT\n"
            "statement ::= let | set | call | if | while | for | try | return | break | continue\n"
        )


class EScriptCompiler:
    def __init__(self, *, script_name: str) -> None:
        self.script_name = script_name
        self.errors: list[str] = []
        self.warnings: list[str] = []

    def compile(self, data: Any, *, script_id: int) -> Optional[CompiledScript]:
        source = None
        timezone = 0
        source_path = None
        if isinstance(data, str):
            source = data
        elif isinstance(data, dict):
            timezone = self._parse_timezone(str(data.get("timezone", "UTC+0")))
            source = data.get("source") or data.get("script")
            source_path = data.get("path")
        if not source:
            self.errors.append("Скрипт должен содержать поле source с кодом")
            return None
        parser = ScriptParser(script_name=self.script_name, warnings=self.warnings)
        try:
            parser.parse(source)
        except ScriptSyntaxError as exc:
            self.errors.append(str(exc))
            return None
        return CompiledScript(
            script_id=script_id,
            name=self.script_name,
            commands=parser.commands,
            functions=parser.functions,
            imports=parser.imports,
            consts=parser.consts,
            macros={k: v["body"] for k, v in parser.macros.items()},
            events=parser.events,
            timezone_offset=timezone,
            grammar=parser.grammar_text,
            path=source_path,
        )

    def _parse_timezone(self, value: str) -> int:
        text = value.strip().upper().replace("UTC", "").replace("GMT", "")
        if not text:
            return 0
        if text.startswith("+"):
            text = text[1:]
        sign = -1 if text.startswith("-") else 1
        if text.startswith("-"):
            text = text[1:]
        if ":" in text:
            hours, minutes = text.split(":", 1)
        else:
            hours, minutes = text, "0"
        try:
            return sign * (int(hours) * 60 + int(minutes))
        except ValueError:
            return 0

    @staticmethod
    def loads(raw: bytes) -> Dict[str, Any]:
        return {"source": raw.decode("utf-8")}
