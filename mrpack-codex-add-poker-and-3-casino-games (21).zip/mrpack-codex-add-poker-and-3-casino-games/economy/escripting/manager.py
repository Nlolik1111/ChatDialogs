import time
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, Optional

from telegram import Update
from telegram.constants import ParseMode

from .compiler import EScriptCompiler
from .models import CompiledCommand, CompiledScript
from .runtime import EScriptRuntime


class EScriptManager:
    def __init__(self, bot) -> None:
        self.bot = bot
        self.cache: Dict[int, Dict[int, CompiledScript]] = {}
        self.runtime = EScriptRuntime(bot=bot, storage=getattr(bot, "storage", None))
        self.button_contexts: Dict[int, Dict[str, Any]] = {}

    def scripts_root(self) -> Path:
        root = Path(__file__).resolve().parents[2] / "escripts"
        root.mkdir(parents=True, exist_ok=True)
        return root

    def script_path(self, chat_id: int, script_id: int) -> Path:
        folder = self.scripts_root() / str(chat_id)
        folder.mkdir(parents=True, exist_ok=True)
        return folder / f"{script_id}.escript"

    def log_path(self, chat_id: int, script_id: int) -> Path:
        folder = self.scripts_root() / "logs" / str(chat_id)
        folder.mkdir(parents=True, exist_ok=True)
        return folder / f"{script_id}.log"

    async def load_chat_scripts(self, chat_id: int) -> Dict[int, CompiledScript]:
        store = self.bot.ensure_storage()
        scripts = await store.list_escripts(chat_id)
        compiled: Dict[int, CompiledScript] = {}
        for row in scripts:
            script_id = int(row[0])
            filename = row[2]
            script_path = Path(filename)
            if not script_path.exists():
                continue
            raw_text = script_path.read_text(encoding="utf-8")
            compiler = EScriptCompiler(script_name=row[1])
            compiled_script = compiler.compile({"source": raw_text, "path": str(script_path)}, script_id=script_id)
            if compiled_script and not compiler.errors:
                compiled[script_id] = compiled_script
        self.cache[chat_id] = compiled
        return compiled

    async def ensure_loaded(self, chat_id: int) -> Dict[int, CompiledScript]:
        if chat_id not in self.cache:
            return await self.load_chat_scripts(chat_id)
        return self.cache[chat_id]

    async def refresh_script(self, chat_id: int, script_id: int) -> None:
        await self.load_chat_scripts(chat_id)

    async def active_commands(self, chat_id: int) -> list[tuple[str, str]]:
        store = self.bot.ensure_storage()
        scripts = await store.list_escripts(chat_id)
        active_ids = {int(row[0]) for row in scripts if row[5]}
        compiled = await self.ensure_loaded(chat_id)
        result: list[tuple[str, str]] = []
        for script_id in active_ids:
            script = compiled.get(script_id)
            if not script:
                continue
            for cmd in script.commands.values():
                desc = cmd.description or "Описание отсутствует"
                result.append((cmd.name, desc))
        return result

    async def handle_command(
        self,
        *,
        chat_id: int,
        command: str,
        update: Update,
        context,
        args: list[str],
        plan_code: str,
        override_only: bool = False,
    ) -> bool:
        store = self.bot.ensure_storage()
        scripts = await store.list_escripts(chat_id)
        active_ids = {int(row[0]) for row in scripts if row[5]}
        compiled = await self.ensure_loaded(chat_id)
        message = update.effective_message
        if not message:
            return False
        if not self.bot._plan_allowed(plan_code, "ultimate"):
            for script_id in active_ids:
                script = compiled.get(script_id)
                if script and command in script.commands:
                    await message.reply_text("Ваш уровень доступа не соответствует уровню плана!", parse_mode=ParseMode.HTML)
                    return True
            return False
        for script_id in active_ids:
            script = compiled.get(script_id)
            if not script:
                continue
            cmd = script.commands.get(command)
            if not cmd:
                continue
            if override_only and getattr(cmd, "override", False) is False:
                continue
            if not override_only and getattr(cmd, "override", False) is True:
                continue
            perms = await store.permissions(chat_id)
            role = self.bot.resolve_role(perms, update.effective_user.id if update.effective_user else 0)
            access_level = getattr(cmd, "access_level", None)
            if access_level is not None:
                if int(access_level) >= 3 and not self.bot.ensure_creator(update):
                    await message.reply_text("Доступ запрещен", parse_mode=ParseMode.HTML)
                    return True
                role_level = {"default": 0, "moderator": 1, "admin": 2, "banned": -1}.get(role, 0)
                if role_level < int(access_level) and not self.bot.ensure_creator(update):
                    await message.reply_text("Доступ запрещен", parse_mode=ParseMode.HTML)
                    return True
            required = str(getattr(cmd, "permissions", "all")).lower()
            if required == "admin" and not (self.bot.ensure_creator(update) or role == "admin"):
                await message.reply_text("Доступ запрещен", parse_mode=ParseMode.HTML)
                return True
            if required == "moderator" and not (
                self.bot.ensure_creator(update) or role in {"admin", "moderator"}
            ):
                await message.reply_text("Доступ запрещен", parse_mode=ParseMode.HTML)
                return True
            await self._execute_command(
                script_id=script_id,
                script=script,
                command=cmd,
                update=update,
                context=context,
                args=args,
            )
            return True
        return False

    async def _execute_command(
        self,
        *,
        script_id: int,
        script: CompiledScript,
        command: CompiledCommand,
        update: Update,
        context,
        args: list[str],
    ) -> None:
        message = update.effective_message
        if not message:
            return
        try:
            await self.runtime.execute_command(command, script=script, args=args, update=update, context=context, target=None)
        except Exception as exc:  # noqa: BLE001
            try:
                await message.reply_text(f"Ошибка исполнения скрипта: {exc}", parse_mode=ParseMode.HTML)
            except Exception:
                pass

    async def handle_button(self, chat_id: int, script_id: int, action_id: str, update: Update, context) -> bool:
        compiled = await self.ensure_loaded(chat_id)
        script = compiled.get(script_id)
        if not script:
            return False
        actions = script.button_actions.get(action_id)
        if not actions:
            return False
        variables = {}
        if update.callback_query and update.callback_query.message:
            variables = self.button_contexts.get(update.callback_query.message.message_id, {})
        await self.runtime.run_actions(
            script_id=script_id,
            script=script,
            actions=actions,
            update=update,
            context=context,
            target=None,
            variables=variables,
        )
        return True

    async def handle_event(self, chat_id: int, event: str, update: Update, context, value: str | None = None) -> bool:
        compiled = await self.ensure_loaded(chat_id)
        handled = False
        for script in compiled.values():
            if not script or not getattr(script, "events", None):
                continue
            for evt in script.events.get(event, []):
                target_value = evt.get("value")
                if target_value:
                    payload = value or (update.effective_message.text if update and update.effective_message else None)
                    if target_value.startswith("/") and target_value.endswith("/"):
                        pattern = target_value.strip("/")
                        if not payload or not re.search(pattern, payload):
                            continue
                    elif payload != target_value:
                        continue
                await self.runtime.run_actions(
                    script_id=script.script_id,
                    script=script,
                    actions=evt.get("actions", []),
                    update=update,
                    context=context,
                    target=None,
                )
                handled = True
        return handled

    def store_button_context(self, message_id: int, variables: Dict[str, Any]) -> None:
        self.button_contexts[message_id] = dict(variables)

    async def run_daily_events(self, chat_id: int, context) -> None:
        store = self.bot.ensure_storage()
        scripts = await store.list_escripts(chat_id)
        active_ids = {int(row[0]) for row in scripts if row[5]}
        compiled = await self.ensure_loaded(chat_id)
        now = int(time.time())
        for script_id in active_ids:
            script = compiled.get(script_id)
            if not script or not getattr(script, "events", None):
                continue
            daily_events = script.events.get("daily") or []
            for idx, event in enumerate(daily_events):
                event_key = f"daily:{idx}"
                tz_override = event.get("tz")
                tz_offset = self._parse_timezone(tz_override) if tz_override else script.timezone_offset
                last_run = await store.get_escript_run(chat_id, script_id, event_key)
                scheduled = self._scheduled_timestamp(event.get("at", "09:00"), tz_offset, now)
                if scheduled is None:
                    continue
                if not self._should_run_daily(scheduled, last_run, tz_offset, now):
                    continue
                fake_update = Update(update_id=0, message=None)
                await self.runtime.run_actions(
                    script_id=script_id,
                    script=script,
                    actions=event["actions"],
                    update=fake_update,
                    context=context,
                    target=None,
                    chat_id_override=chat_id,
                )
                await store.set_escript_run(chat_id, script_id, event_key, now)

    def _scheduled_timestamp(self, when: str, tz_offset: int, now: int) -> Optional[int]:
        try:
            hour, minute = [int(part) for part in when.split(":")]
        except Exception:
            hour, minute = 9, 0
        tz = timezone(timedelta(minutes=tz_offset))
        now_dt = datetime.fromtimestamp(now, tz=tz)
        scheduled = now_dt.replace(hour=hour, minute=minute, second=0, microsecond=0)
        return int(scheduled.timestamp())

    def _should_run_daily(self, scheduled: int, last_run: int, tz_offset: int, now: int) -> bool:
        tz = timezone(timedelta(minutes=tz_offset))
        now_dt = datetime.fromtimestamp(now, tz=tz)
        if last_run:
            last_dt = datetime.fromtimestamp(last_run, tz=tz)
            if last_dt.date() == now_dt.date():
                return False
        return now >= scheduled

    def _parse_timezone(self, value: str) -> int:
        if not value:
            return 0
        text = value.strip().upper().replace("UTC", "").replace("GMT", "")
        if not text:
            return 0
        if text.startswith("+"):
            text = text[1:]
        sign = -1 if text.startswith("-") else 1
        if text.startswith("-"):
            text = text[1:]
        if ":" in text:
            hours, minutes = text.split(":", 1)
        else:
            hours, minutes = text, "0"
        try:
            return sign * (int(hours) * 60 + int(minutes))
        except ValueError:
            return 0
