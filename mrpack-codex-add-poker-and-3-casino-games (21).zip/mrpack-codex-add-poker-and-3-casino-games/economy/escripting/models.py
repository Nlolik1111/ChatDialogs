from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class CompiledCommand:
    name: str
    params: list[dict]
    body: List[dict]
    description: str = ""
    returns: Optional[str] = None


@dataclass
class CompiledFunction:
    name: str
    params: list[dict]
    body: List[dict]
    returns: Optional[str] = None


@dataclass
class CompiledScript:
    script_id: int
    name: str
    commands: Dict[str, CompiledCommand] = field(default_factory=dict)
    functions: Dict[str, List[CompiledFunction]] = field(default_factory=dict)
    events: Dict[str, list[Dict[str, Any]]] = field(default_factory=dict)
    timezone_offset: int = 0
    grammar: str | None = None
    button_actions: Dict[str, list[Dict[str, Any]]] = field(default_factory=dict)
    imports: List[str] = field(default_factory=list)
    consts: Dict[str, Any] = field(default_factory=dict)
    macros: Dict[str, List[dict]] = field(default_factory=dict)
    path: str | None = None
