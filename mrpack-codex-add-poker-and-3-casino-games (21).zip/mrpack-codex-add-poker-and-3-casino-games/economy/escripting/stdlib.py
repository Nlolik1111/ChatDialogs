import re
from typing import Any, Dict, Optional


FUNCTION_FAMILIES = {
    "math.add": ("add", 200),
    "math.sub": ("sub", 200),
    "math.mul": ("mul", 200),
    "math.div": ("div", 200),
    "text.repeat": ("repeat", 200),
}


def parse_function_name(name: str) -> Optional[tuple[str, int]]:
    for prefix, (_op, max_val) in FUNCTION_FAMILIES.items():
        if not name.startswith(prefix + "_"):
            continue
        suffix = name.split("_", 1)[1]
        if suffix.isdigit():
            idx = int(suffix)
            if 1 <= idx <= max_val:
                return prefix, idx
    return None


def execute_function(name: str, args: list[Any]) -> Any:
    parsed = parse_function_name(name)
    if not parsed:
        raise ValueError(f"Неизвестная функция: {name}")
    prefix, idx = parsed
    value = args[0] if args else 0
    if prefix == "math.add":
        return value + idx
    if prefix == "math.sub":
        return value - idx
    if prefix == "math.mul":
        return value * idx
    if prefix == "math.div":
        return value / idx if idx else value
    if prefix == "text.repeat":
        return str(value) * idx
    return value


def list_function_docs() -> Dict[str, str]:
    docs = {}
    for prefix, (op, max_val) in FUNCTION_FAMILIES.items():
        if op == "add":
            docs[prefix] = f"{prefix}_1..{prefix}_{max_val}: прибавить константу N к первому аргументу"
        elif op == "sub":
            docs[prefix] = f"{prefix}_1..{prefix}_{max_val}: вычесть константу N из первого аргумента"
        elif op == "mul":
            docs[prefix] = f"{prefix}_1..{prefix}_{max_val}: умножить первый аргумент на N"
        elif op == "div":
            docs[prefix] = f"{prefix}_1..{prefix}_{max_val}: поделить первый аргумент на N"
        elif op == "repeat":
            docs[prefix] = f"{prefix}_1..{prefix}_{max_val}: повторить строку N раз"
    return docs
