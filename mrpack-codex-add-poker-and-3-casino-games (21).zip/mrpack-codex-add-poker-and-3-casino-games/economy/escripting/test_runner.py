from __future__ import annotations

import argparse
import asyncio
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List

from .compiler import EScriptCompiler
from .runtime import EScriptRuntime


@dataclass
class TestResult:
    name: str
    passed: bool
    expected: List[str]
    actual: List[str]


class _FakeUser:
    def __init__(self) -> None:
        self.id = 0
        self.username = "tester"
        self.first_name = "Tester"
        self.last_name = ""


class _FakeChat:
    def __init__(self, chat_id: int = 0) -> None:
        self.id = chat_id


class _FakeMessage:
    def __init__(self, chat: _FakeChat) -> None:
        self.chat = chat
        self.message_id = 0
        self.message_thread_id = None


class _FakeUpdate:
    def __init__(self, chat_id: int = 0) -> None:
        chat = _FakeChat(chat_id)
        self.effective_chat = chat
        self.effective_message = _FakeMessage(chat)
        self.effective_user = _FakeUser()


class _FakeStorage:
    def __init__(self, balances: Dict[int, int] | None = None, treasury: int = 0) -> None:
        self.balances = balances or {}
        self.treasury = treasury

    async def get_balance(self, chat_id: int, user_id: int) -> int:
        return self.balances.get(user_id, 0)

    async def adjust_balance(self, chat_id: int, user_id: int, _, delta: int, prevent_negative: bool = False):
        current = self.balances.get(user_id, 0)
        if prevent_negative and current + delta < 0:
            return None
        self.balances[user_id] = current + delta
        return self.balances[user_id]

    async def transfer_balance(self, chat_id: int, from_id: int, to_id: int, amount: int, prevent_negative: bool = False):
        if prevent_negative and self.balances.get(from_id, 0) < amount:
            return None
        await self.adjust_balance(chat_id, from_id, None, -amount, prevent_negative=True)
        await self.adjust_balance(chat_id, to_id, None, amount)
        return True

    async def adjust_treasury(self, chat_id: int, delta: int, prevent_negative: bool = False):
        if prevent_negative and self.treasury + delta < 0:
            return None
        self.treasury += delta
        return self.treasury


async def _run_command(runtime: EScriptRuntime, script, command: str, args: list[str]) -> None:
    if command not in script.commands:
        raise ValueError(f"Команда {command} не найдена")
    await runtime.execute_command(
        script.commands[command],
        script=script,
        args=args,
        update=_FakeUpdate(runtime.active_chat_id),
        context=None,
        target=None,
    )


def load_script(path: Path):
    compiler = EScriptCompiler(script_name=path.stem)
    compiled = compiler.compile({"source": path.read_text(encoding="utf-8"), "path": str(path)}, script_id=0)
    if compiler.errors or not compiled:
        raise RuntimeError("Не удалось скомпилировать скрипт: " + "; ".join(compiler.errors))
    return compiled


async def run_golden_tests(script_path: Path) -> list[TestResult]:
    script = load_script(script_path)
    runtime = EScriptRuntime(chat_id=0)
    runtime._prepare_script(script)
    tests_dir = script_path.parent / "tests"
    results: list[TestResult] = []
    for case in sorted(tests_dir.glob("*.in")):
        mocks_path = case.with_suffix(".mocks.json")
        mocks = json.loads(mocks_path.read_text(encoding="utf-8")) if mocks_path.exists() else {}
        runtime._mock_time = mocks.get("time")
        runtime._mock_http = mocks.get("http", [])
        runtime._mock_form_responses = mocks.get("forms", [])
        runtime.storage = _FakeStorage(mocks.get("balances", {}), mocks.get("treasury", 0))
        expected_path = case.with_suffix(".out")
        expected_lines = expected_path.read_text(encoding="utf-8").splitlines() if expected_path.exists() else []
        commands = [line for line in case.read_text(encoding="utf-8").splitlines() if line.strip()]
        runtime.globals.pop("__messages", None)
        for line in commands:
            parts = line.split()
            await _run_command(runtime, script, parts[0], parts[1:])
        messages = runtime.globals.get("__messages", {})
        actual_lines = [str(msg.get("text", "")) for msg in messages.values()] if isinstance(messages, dict) else []
        results.append(TestResult(name=case.stem, passed=actual_lines == expected_lines, expected=expected_lines, actual=actual_lines))
    return results


def main() -> None:
    parser = argparse.ArgumentParser(description="Run escript golden tests")
    parser.add_argument("script", type=str, help="Path to .escript file")
    args = parser.parse_args()
    script_path = Path(args.script).resolve()
    results = asyncio.run(run_golden_tests(script_path))
    for result in results:
        status = "OK" if result.passed else "FAIL"
        print(f"[{status}] {result.name}")
        if not result.passed:
            print("  expected:", result.expected)
            print("  actual:", result.actual)


if __name__ == "__main__":
    main()
