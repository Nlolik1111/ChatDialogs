import unittest

try:
    from economy.casino import CasinoManager

    TELEGRAM_OK = True
except ModuleNotFoundError as exc:
    if exc.name == "telegram":
        TELEGRAM_OK = False
        CasinoManager = None
    else:
        raise


class _DummyBot:
    settings = None


def _fmt(value, _currency=None):
    return str(value)


@unittest.skipUnless(TELEGRAM_OK, "telegram package is required for casino module")
class PokerEvaluatorTests(unittest.TestCase):
    def setUp(self) -> None:
        self.manager = CasinoManager(_DummyBot(), _fmt)

    def test_pair_kicker_comparison(self) -> None:
        board = ["A♠", "5♦", "7♣", "9♣", "2♥"]
        score_top, label_top, _combo_top, _kickers_top = self.manager._poker_hand_score(
            ["A♦", "K♦"], board
        )
        score_behind, label_behind, _combo_behind, _kickers_behind = self.manager._poker_hand_score(
            ["A♥", "Q♠"], board
        )
        self.assertGreater(score_top, score_behind)
        self.assertIn("кикер", label_top.lower())

    def test_board_play_split(self) -> None:
        board = ["A♠", "K♦", "Q♦", "J♦", "10♦"]
        score_one, label_one, _combo_one, _ = self.manager._poker_hand_score(["2♣", "3♣"], board)
        score_two, label_two, _combo_two, _ = self.manager._poker_hand_score(["4♠", "5♠"], board)
        self.assertEqual(score_one, score_two)
        self.assertTrue(label_one.startswith("борд играет") or label_two.startswith("борд играет"))


if __name__ == "__main__":
    unittest.main()
