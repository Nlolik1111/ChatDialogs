"""Class-based economy bot runtime."""
import asyncio
import html
import json
import logging
import random
import re
import time
from datetime import datetime, timedelta
from decimal import Decimal, ROUND_HALF_UP
from io import BytesIO
from pathlib import Path
from typing import Any, Dict, Iterable, Optional, Tuple
from zoneinfo import ZoneInfo

from .casino import CasinoManager
from telegram import (
    ChatPermissions,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    LabeledPrice,
    Message,
    MessageEntity,
    Update,
    User,
)
from telegram.constants import ParseMode
from telegram.error import BadRequest, TimedOut
from telegram.ext import (
    Application,
    ApplicationBuilder,
    CallbackQueryHandler,
    ChatMemberHandler,
    CommandHandler,
    ContextTypes,
    Defaults,
    MessageHandler,
    PreCheckoutQueryHandler,
    filters,
)

from economy.config import BotSettings, load_settings
from economy.escripting import EScriptCompiler, EScriptManager
from economy.formatters import format_currency as _format_currency
from economy.permissions import is_allowed
from economy.shop_manager import ShopManager
from economy.jobs import JobSystem
from economy.normal_shop import NormalShop
from economy.private_messages import PrivateMessages
from economy.transactions import Transactions
from economy.storage import (
    PLAN_BASIC,
    PLAN_MEDIUM,
    PLAN_ULTIMATE,
    MySQLEconomyStorage,
)

logger = logging.getLogger(__name__)
CURRENCY_DECIMAL_PLACES = {"XTR": 0}


def format_currency(amount: int | float, currency: Dict[str, Any]) -> str:
    if amount is None:
        amount = 0
    try:
        normalized = int(round(float(amount)))
    except (TypeError, ValueError):
        normalized = 0
    return _format_currency(normalized, currency)

class EconomyBot:
    """Encapsulates the Telegram economy bot logic with handler methods."""

    COMMAND_PREFIXES = ("!!", "‼", "‼️")
    COMMAND_PREFIX_ALIASES = {"!!": ("‼", "‼️")}
    MIN_TRANSACTION = 50
    MAX_TRANSACTION = 100_000_000
    AMOUNT_ALL = {"all", "всё", "все", "вс1"}
    SHOP_PAGE_SIZE = 5
    PLAN_RANK = {PLAN_BASIC: 0, PLAN_MEDIUM: 1, PLAN_ULTIMATE: 2}
    PLAN_LIMITS = {
        PLAN_BASIC: {"groups": 1, "transfer": 500000, "credit": 700000},
        PLAN_MEDIUM: {"groups": 3, "transfer": 1000000, "credit": 1500000},
        PLAN_ULTIMATE: {"groups": None, "transfer": None, "credit": None},
    }
    LOCAL_TZ = ZoneInfo("Europe/Moscow")

    def __init__(self, settings: Optional[BotSettings] = None) -> None:
        self.settings = settings or load_settings()
        self.storage: Optional[MySQLEconomyStorage] = None
        # expose lowercase aliases for helper classes
        self.min_transaction = self.MIN_TRANSACTION
        self.max_transaction = self.MAX_TRANSACTION
        self.shop_page_size = self.SHOP_PAGE_SIZE
        self.pending_actions: Dict[int, Dict[str, int]] = {}
        self.shop_sessions: Dict[int, Dict[str, int]] = {}
        self.purchases_sessions: Dict[int, Dict[str, int]] = {}
        self.pending_broadcasts: Dict[int, Dict[str, Any]] = {}
        self.active_polls: Dict[int, list[tuple[int, int]]] = {}
        self.pending_nukes: Dict[Tuple[int, int], Dict[str, Any]] = {}
        self.nuke_blocks: Dict[Tuple[int, int], float] = {}
        self.nuke_delete: Dict[Tuple[int, int], bool] = {}
        self.pending_promos: Dict[int, Dict[str, Any]] = {}
        self.receipt_wait_tasks: Dict[Tuple[int, str], asyncio.Task] = {}
        self.help_sessions: Dict[int, list[str]] = {}
        self.escript_log_cache: Dict[str, str] = {}
        self.chat_threads: Dict[int, int] = {}
        self.thread_usage: Dict[int, Dict[int, int]] = {}
        self.shop = ShopManager(self)
        self.normal_shop = NormalShop(self)
        self.job_sessions: Dict[int, Dict[str, Any]] = {}
        self.jobs = JobSystem(self)
        self.transactions = Transactions(self)
        self.private_messages = PrivateMessages(self)
        self.escripts = EScriptManager(self)
        self.test_mode: bool = False
        self.test_unlocked_chats: set[int] = set()
        self.news_channel_link = self.settings.news_channel_link
        self.news_channel_id: int = self.settings.news_channel_id or 0
        self.news_channel_url: str | None = None
        self.creator_chat_id: Optional[int] = None
        self._reminder_task: Optional[asyncio.Task] = None
        self._escript_task: Optional[asyncio.Task] = None
        self._daily_stats_task: Optional[asyncio.Task] = None
        self.help_pages: list[str] = [
            """✨ <b>Основное меню</b>
• /start - приветствие и быстрые ссылки
• /help - эта справка со стрелками навигации
• /settings - список групп и настройки
• /plans - выбор и статус подписки
• /promo - ввод промокода
""",
            """💬 <b>Базовые команды</b>
• !!помощь: краткая подсказка
• !!баланс [@user]: баланс
• !!профиль [@user]: профиль и рейтинг
• !!топ: топ богачей
• !!курс: курс валюты
• !!казино: рулетка, слоты, блэкджек (от Медиум), покер (до 10 игроков, от Медиум), монетка, кости
""",
            """💰 <b>Экономика</b>
• !!баланс зачислить @user amount: начислить средства (админ)
• !!баланс изъять @user amount/all: изъять средства (админ)
• !!баланс установить @user amount: установить баланс (админ)
• !!перевод @user amount: отправить перевод
• !!ежедневка: ежедневный бонус
• !!казино рулетка {красный/черный/число} {ставка}
• !!казино слоты {ставка}, !!казино блэкджек {ставка} (от Медиум)
• !!казино покер {игроки до 10} {ставка} (от Медиум), !!казино монетка орел/решка {ставка}
• !!казино кости {ставка}
• !!казна …: казна группы
• !!ограбить @user: ограбление (от Медиум)
""",
            """🛍️ <b>Магазин</b>
• !!магазин: фиксированные товары
• !!покупки [@user]: история покупок
• !!товар использовать {индекс} [@user]: активировать покупку
• Спецтовары (ядерка, щит) описаны в карточках
""",
            """🛠️ <b>Работы</b> (от Ультиматум)
• !!работа: смена/тест, учитывается кулдаун 3ч
• !!работа инфо [@user]: карточка работы и счет
• Рейтинг влияет на оклад, увольнения штрафуют
""",
            """🧾 <b>Планы и лимиты</b>
• BASIC: 1 группа, переводы 5.000/день, зачисления 7.000/день
• MEDIUM: 3 группы, переводы 10.000/день, зачисления 15.000/день
• ULTIMATE: без лимитов, все команды доступны
Оформление: /plans - выберите оплату звёздами или переводом.
""",
        ]
        self.casino = CasinoManager(self, format_currency)

    @staticmethod
    def is_bot_username(username: Optional[str]) -> bool:
        if not username:
            return False
        return str(username).lstrip("@").lower().endswith("bot")

    async def _reject_bot_target(self, *, reply, target_name: Optional[str]) -> bool:
        if self.is_bot_username(target_name):
            await reply("У ботов нет душ.")
            return True
        return False

    def _escript_log_key(self, chat_id: int, user_id: int, script_id: int) -> str:
        return f"{chat_id}-{user_id}-{script_id}-{int(time.time())}"

    async def _escript_counts(self, chat_id: int) -> tuple[int, int, int]:
        store = self.ensure_storage()
        scripts = await store.list_escripts(chat_id)
        total = len(scripts)
        active = 0
        for row in scripts:
            is_active = bool(row[5])
            errors = int(row[6] or 0)
            path_ok = Path(row[2]).exists()
            if is_active and errors == 0 and path_ok:
                active += 1
        inactive = total - active
        return total, active, inactive

    async def _escript_list_keyboard(self, chat_id: int, *, show_status: bool = True) -> Optional[InlineKeyboardMarkup]:
        store = self.ensure_storage()
        scripts = await store.list_escripts(chat_id)
        if not scripts:
            return None
        buttons = []
        for row in scripts:
            script_id = int(row[0])
            name = row[1]
            active = bool(row[5])
            errors = int(row[6] or 0)
            status_ok = active and errors == 0 and Path(row[2]).exists()
            status = "🟢" if status_ok else "🔴"
            label = f"{name} {status}" if show_status else f"{name}"
            action = "toggle" if show_status else "config"
            buttons.append(
                [InlineKeyboardButton(label, callback_data=f"escript:{action}:{chat_id}:{script_id}")]
            )
        return InlineKeyboardMarkup(buttons)

    async def _escript_settings_keyboard(self, chat_id: int, script_id: int) -> InlineKeyboardMarkup:
        return InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton("Код", callback_data=f"escript:code:{chat_id}:{script_id}"),
                    InlineKeyboardButton("Изменить", callback_data=f"escript:edit:{chat_id}:{script_id}"),
                ],
                [InlineKeyboardButton("Удалить", callback_data=f"escript:delete:{chat_id}:{script_id}")],
            ]
        )

    async def _escript_info_text(self, chat_id: int) -> str:
        total, active, inactive = await self._escript_counts(chat_id)
        return (
            "<b>Скрипты</b>\n\n"
            f"Всего скриптов: <b>{total}</b>\n"
            f"Активно: <b>{active}</b>\n"
            f"Отключено: <b>{inactive}</b>\n"
            "<u>Управление</u>: нажмите на название скрипта для переключения статуса.\n"
            "<u>Создание</u>: используйте <a href=\"https://github.com/Nlolik1111/EScripts\">официальную документацию</a> для создания скриптов."
        )

    async def _escript_settings_text(self, chat_id: int, script_id: int) -> Optional[str]:
        store = self.ensure_storage()
        script = await store.get_escript(chat_id, script_id)
        if not script:
            return None
        since = int(time.time()) - 86400
        errors_day = await store.count_escript_errors_since(chat_id, script_id, since)
        has_errors = script.get("errors", 0) > 0
        file_ok = Path(script.get("filename", "")).exists()
        status_ok = script["active"] and not has_errors and file_ok
        status = "🟢 активен" if status_ok else "🔴 неактивен"
        author = script.get("author_username") or str(script.get("author_id"))
        if author and not str(author).startswith("@"):
            author = f"@{author}"
        return (
            f"<b>Настройки скрипта \"{html.escape(script['name'])}\"</b>\n\n"
            f"Статус: <b>{status}</b>\n"
            f"Ошибки (за последний день): <b>{errors_day}</b>\n"
            f"Автор скрипта: <b>{html.escape(author)}</b>"
        )

    async def _find_escript_by_name(self, chat_id: int, name: str) -> Optional[int]:
        store = self.ensure_storage()
        scripts = await store.list_escripts(chat_id)
        name_lower = name.strip().lower()
        for script_id, script_name, *_ in scripts:
            if str(script_name).strip().lower() == name_lower:
                return int(script_id)
        return None

    @staticmethod
    def _extract_quoted_name(text: str) -> Optional[str]:
        match = re.search(r"\"([^\"]+)\"", text)
        if match:
            return match.group(1).strip()
        match = re.search(r"«([^»]+)»", text)
        if match:
            return match.group(1).strip()
        return None

    async def _compile_escript_payload(
        self,
        *,
        chat_id: int,
        script_id: int,
        script_name: str,
        raw_data: bytes,
        author: Optional[User],
    ) -> tuple[Optional[dict], list[str], list[str], str]:
        log_lines = []
        source = raw_data.decode("utf-8")
        compiler = EScriptCompiler(script_name=script_name)
        compiled = compiler.compile(source, script_id=script_id)
        log_lines.append(f"Скрипт: {script_name}")
        log_lines.append(f"Автор загрузки: {author.username if author else 'unknown'}")
        log_lines.append(f"Команд: {len(compiled.commands) if compiled else 0}")
        log_lines.append(f"Ошибок: {len(compiler.errors)} | Предупреждений: {len(compiler.warnings)}")
        if compiler.warnings:
            log_lines.append("\nПредупреждения (требуют внимания):")
            for idx, warn in enumerate(compiler.warnings, start=1):
                log_lines.append(f"!!! WARN {idx}: {warn}")
        if compiler.errors:
            log_lines.append("\nОшибки (скрипт не активирован):")
            for idx, err in enumerate(compiler.errors, start=1):
                log_lines.append(f"!!! ERROR {idx}: {err}")
        if not compiler.errors:
            log_lines.append("\n✅ Компиляция завершена без ошибок.")
        return {"source": source}, compiler.errors, compiler.warnings, "\n".join(log_lines)

    async def handle_escript_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        query = update.callback_query
        self._remember_thread(update)
        if not query:
            return
        if not await self._ensure_private_subscription(update, context):
            return
        parts = query.data.split(":")
        if len(parts) < 3:
            return
        action = parts[1]
        if action == "log":
            log_key = parts[2] if len(parts) > 2 else ""
            if not log_key or log_key not in self.escript_log_cache:
                await query.answer("Лог недоступен", show_alert=True)
                return
            try:
                chat_id = int(log_key.split("-", 1)[0])
            except ValueError:
                await query.answer("Лог недоступен", show_alert=True)
                return
            store = self.ensure_storage()
            perms = await store.permissions(chat_id)
            role = self.resolve_role(perms, query.from_user.id)
            if not (self.ensure_creator(update) or role == "admin"):
                await query.answer("Доступ запрещен", show_alert=True)
                return
            path = self.escript_log_cache[log_key]
            try:
                with open(path, "rb") as handle:
                    await context.bot.send_document(query.from_user.id, document=handle)
            except Exception:
                await query.answer("Не удалось отправить лог", show_alert=True)
            return
        if action == "logfile":
            if len(parts) < 4:
                return
            try:
                chat_id = int(parts[2])
                script_id = int(parts[3])
            except ValueError:
                await query.answer("Лог недоступен", show_alert=True)
                return
            store = self.ensure_storage()
            perms = await store.permissions(chat_id)
            role = self.resolve_role(perms, query.from_user.id)
            if not (self.ensure_creator(update) or role == "admin"):
                await query.answer("Доступ запрещен", show_alert=True)
                return
            script = await store.get_escript(chat_id, script_id)
            if not script or not script.get("last_log_path"):
                await query.answer("Лог недоступен", show_alert=True)
                return
            try:
                with open(script["last_log_path"], "rb") as handle:
                    await context.bot.send_document(query.from_user.id, document=handle)
            except Exception:
                await query.answer("Не удалось отправить лог", show_alert=True)
            return
        if len(parts) < 4:
            return
        chat_id = int(parts[2])
        script_id = int(parts[3])
        store = self.ensure_storage()
        perms = await store.permissions(chat_id)
        role = self.resolve_role(perms, query.from_user.id)
        if action in {"toggle", "config", "code", "edit", "delete", "delete_confirm"}:
            if not (self.ensure_creator(update) or role == "admin"):
                await query.answer("Доступ запрещен", show_alert=True)
                return
        if action == "toggle":
            script = await store.get_escript(chat_id, script_id)
            if not script:
                await query.answer("Скрипт не найден", show_alert=True)
                return
            if not script["active"]:
                script_path = Path(script.get("filename", ""))
                if not script_path.exists():
                    await query.answer("Файл скрипта не найден", show_alert=True)
                    return
                try:
                    raw = script_path.read_bytes()
                except Exception:
                    await query.answer("Не удалось прочитать скрипт", show_alert=True)
                    return
                data, errors, warnings, log_text = await self._compile_escript_payload(
                    chat_id=chat_id,
                    script_id=script_id,
                    script_name=script.get("name") or "Без названия",
                    raw_data=raw,
                    author=None,
                )
                log_path = self.escripts.log_path(chat_id, script_id)
                try:
                    log_path.write_text(log_text, encoding="utf-8")
                except Exception:
                    log_path = None
                if errors:
                    await store.update_escript_meta(
                        chat_id=chat_id,
                        script_id=script_id,
                        errors=len(errors),
                        warnings=len(warnings),
                        log_path=str(log_path) if log_path else None,
                        active=False,
                    )
                    await self.escripts.refresh_script(chat_id, script_id)
                    await query.answer("Скрипт содержит ошибки и не может быть активирован", show_alert=True)
                    return
                await store.update_escript_meta(
                    chat_id=chat_id,
                    script_id=script_id,
                    errors=0,
                    warnings=len(warnings),
                    log_path=str(log_path) if log_path else None,
                    active=True,
                )
            else:
                await store.update_escript_status(chat_id, script_id, False)
            await self.escripts.refresh_script(chat_id, script_id)
            keyboard = await self._escript_list_keyboard(chat_id, show_status=True)
            await query.edit_message_text(
                "<b>Список доступных скриптов:</b>",
                reply_markup=keyboard,
                parse_mode=ParseMode.HTML,
                disable_web_page_preview=True
            )

            return
        if action == "config":
            text_data = await self._escript_settings_text(chat_id, script_id)
            if not text_data:
                await query.answer("Скрипт не найден", show_alert=True)
                return
            keyboard = await self._escript_settings_keyboard(chat_id, script_id)
            await query.edit_message_text(
                text_data,
                reply_markup=keyboard,
                parse_mode=ParseMode.HTML,
                disable_web_page_preview=True
            )

            return
        if action == "code":
            script = await store.get_escript(chat_id, script_id)
            if not script:
                await query.answer("Скрипт не найден", show_alert=True)
                return
            try:
                with open(script["filename"], "rb") as handle:
                    await context.bot.send_document(query.from_user.id, document=handle)
            except Exception:
                await query.answer("Не удалось отправить файл", show_alert=True)
            return
        if action == "edit":
            script = await store.get_escript(chat_id, script_id)
            if not script:
                await query.answer("Скрипт не найден", show_alert=True)
                return
            prompt = await query.message.reply_text("Загрузи новый .escript ответом на это сообщение.")
            await store.set_pending_escript(
                prompt_id=prompt.message_id,
                chat_id=chat_id,
                user_id=query.from_user.id,
                script_id=script_id,
                name=script.get("name"),
            )
            return
        if action == "delete":
            await query.edit_message_text(
                "<b>Подтвердить удаление скрипта?</b>",
                reply_markup=InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton("Да", callback_data=f"escript:delete_confirm:{chat_id}:{script_id}"),
                            InlineKeyboardButton("Нет", callback_data=f"escript:config:{chat_id}:{script_id}"),
                        ]
                    ]
                ),
                parse_mode=ParseMode.HTML,
            )
            return
        if action == "delete_confirm":
            script = await store.get_escript(chat_id, script_id)
            if script and Path(script["filename"]).exists():
                try:
                    Path(script["filename"]).unlink()
                except Exception:
                    pass
            await store.delete_escript(chat_id, script_id)
            await self.escripts.refresh_script(chat_id, script_id)
            keyboard = await self._escript_list_keyboard(chat_id, show_status=True)
            await query.edit_message_text("<b>Список доступных скриптов:</b>", reply_markup=keyboard, parse_mode=ParseMode.HTML)
            return

    async def handle_escript_button_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        query = update.callback_query
        self._remember_thread(update)
        if not query:
            return
        if not await self._ensure_private_subscription(update, context):
            return
        parts = query.data.split(":")
        if len(parts) < 3:
            return
        script_id = int(parts[1])
        action_id = ":".join(parts[2:])
        chat_id = query.message.chat_id if query.message else None
        if chat_id is None:
            return
        await self.escripts.handle_button(chat_id, script_id, action_id, update, context)

    # region helpers
    @classmethod
    def _expanded_prefixes(cls, prefixes: Iterable[str] | None = None) -> tuple[str, ...]:
        base = tuple(prefixes) if prefixes else cls.COMMAND_PREFIXES
        seen: list[str] = []
        for prefix in base:
            if not prefix:
                continue
            if prefix not in seen:
                seen.append(prefix)
            for alias in cls.COMMAND_PREFIX_ALIASES.get(prefix, ()):  # add lookalikes but do not show them in UI
                if alias not in seen:
                    seen.append(alias)
        # Longer prefixes first so that "!!" wins over "!"
        return tuple(sorted(seen, key=len, reverse=True))

    @classmethod
    def normalize_command(cls, text: str, prefixes: Iterable[str] | None = None) -> tuple[Optional[str], str]:
        clean = text.lstrip()
        active = cls._expanded_prefixes(prefixes)
        for prefix in active:
            if clean.startswith(prefix):
                return prefix, clean[len(prefix):].strip()
        return None, clean

    def _date_key(self, timestamp: int | None = None) -> str:
        ts = timestamp or int(time.time())
        dt = datetime.fromtimestamp(ts, tz=self.LOCAL_TZ)
        return dt.strftime("%Y-%m-%d")

    def _previous_date_key(self, timestamp: int | None = None) -> str:
        ts = timestamp or int(time.time())
        dt = datetime.fromtimestamp(ts, tz=self.LOCAL_TZ) - timedelta(days=1)
        return dt.strftime("%Y-%m-%d")

    def ensure_storage(self) -> MySQLEconomyStorage:
        if self.storage is None:
            raise RuntimeError("Хранилище не инициализировано")
        return self.storage

    def _plan_allowed(self, user_plan: str, required: str) -> bool:
        return self.PLAN_RANK.get(user_plan, 0) >= self.PLAN_RANK.get(required, 0)

    def _plan_limits(self, plan: str) -> dict:
        return self.PLAN_LIMITS.get(plan, self.PLAN_LIMITS[PLAN_BASIC])

    async def _maybe_send_plan_reminder(
        self, user, context: ContextTypes.DEFAULT_TYPE, raw_plan: dict
    ) -> None:
        if not user or not context:
            return
        plan_code = raw_plan.get("plan", PLAN_BASIC)
        expires_at = int(raw_plan.get("expires_at", 0) or 0)
        remind_at = int(raw_plan.get("remind_at", 0) or 0)
        if plan_code == PLAN_BASIC or not expires_at:
            return
        now = int(time.time())
        store = self.ensure_storage()
        message = None
        next_remind = remind_at
        if now >= expires_at:
            if remind_at != -1:
                message = "⚠️ Срок действия подписки истёк."
                next_remind = -1
        elif now >= expires_at - 24 * 3600 and remind_at <= expires_at - 24 * 3600:
            message = "⏳ Подписка заканчивается завтра."
            next_remind = expires_at
        elif now >= expires_at - 2 * 24 * 3600 and remind_at <= expires_at - 2 * 24 * 3600:
            message = "⏳ Подписка заканчивается через 2 дня."
            next_remind = expires_at - 24 * 3600
        elif now >= expires_at - 3 * 24 * 3600 and remind_at <= expires_at - 3 * 24 * 3600:
            message = "⏳ Подписка заканчивается через 3 дня."
            next_remind = expires_at - 2 * 24 * 3600
        if message:
            await self._safe_send_message(
                context,
                chat_id=user.id,
                text=f"{message}\nНажмите «Продлить», чтобы продлить подписку.",
                reply_markup=self._renew_keyboard(),
                parse_mode=ParseMode.HTML,
            )
            await store.update_plan_reminder(user.id, next_remind)

    async def _creator_chat_id(self, context: ContextTypes.DEFAULT_TYPE) -> Optional[int]:
        if self.creator_chat_id:
            return self.creator_chat_id
        if self.settings.creator_id:
            self.creator_chat_id = self.settings.creator_id
            return self.creator_chat_id
        username = self.settings.creator_username
        if not username:
            return None
        try:
            chat = await context.bot.get_chat(f"@{username}")
            self.creator_chat_id = chat.id
        except Exception:
            self.creator_chat_id = None
        return self.creator_chat_id

    async def _plan_for_user(self, user) -> dict:
        if user and (user.username or "").lower() == self.settings.creator_username:
            return {"plan": PLAN_ULTIMATE, "expires_at": 0, "remind_at": 0}
        return await self.ensure_storage().ensure_plan(user.id if user else 0)

    async def _plan_for_user_with_reminder(self, user, context: ContextTypes.DEFAULT_TYPE) -> dict:
        if user and (user.username or "").lower() == self.settings.creator_username:
            return {"plan": PLAN_ULTIMATE, "expires_at": 0, "remind_at": 0}
        store = self.ensure_storage()
        raw = await store.get_user_plan_raw(user.id if user else 0)
        await self._maybe_send_plan_reminder(user, context, raw)
        return await store.ensure_plan(user.id if user else 0)

    async def _plan_for_chat(self, chat_id: int, context: ContextTypes.DEFAULT_TYPE) -> dict:
        store = self.ensure_storage()
        owner_id = await store.chat_owner(chat_id)
        if not owner_id:
            try:
                admins = await context.bot.get_chat_administrators(chat_id)
            except Exception:
                admins = []
            best_plan = {"plan": PLAN_BASIC}
            best_owner = None
            for admin in admins:
                user = admin.user
                if user and (user.username or "").lower() == self.settings.creator_username:
                    best_owner = user.id
                    best_plan = {"plan": PLAN_ULTIMATE, "expires_at": 0, "remind_at": 0}
                    break
                plan_info = await store.ensure_plan(user.id if user else 0)
                if self.PLAN_RANK.get(plan_info.get("plan", PLAN_BASIC), 0) > self.PLAN_RANK.get(best_plan.get("plan", PLAN_BASIC), 0):
                    best_plan = plan_info
                    best_owner = user.id if user else None
            if best_owner:
                await store.set_chat_owner(chat_id, best_owner)
                return best_plan
            return {"plan": PLAN_BASIC}
        owner_stub = User(id=owner_id, first_name="Owner", is_bot=False)
        return await self._plan_for_user_with_reminder(owner_stub, context)

    async def _bump_rating(self, chat_id: int, user_id: int, delta: float) -> None:

        try:
            await self.ensure_storage().update_job_rating(chat_id, user_id, delta=delta)
        except Exception:
            logger.debug("Не удалось обновить рейтинг для %s", user_id)

    def _remember_thread(self, update: Update) -> None:

        message = update.effective_message
        chat_id = getattr(message, "chat_id", None)
        if chat_id is None:
            return
        thread_id = getattr(message, "message_thread_id", None)
        if thread_id is None:
            self.chat_threads.pop(chat_id, None)
            return

        if chat_id not in self.chat_threads:
            self.chat_threads[chat_id] = thread_id

    def _record_thread_preference(self, chat_id: int, thread_id: Optional[int]) -> None:

        if thread_id is None:
            return
        stats = self.thread_usage.setdefault(chat_id, {})
        stats[thread_id] = stats.get(thread_id, 0) + 1
        preferred = max(stats.items(), key=lambda kv: (kv[1], -kv[0]))[0]
        self.chat_threads[chat_id] = preferred

    async def _safe_send_message(self, context: ContextTypes.DEFAULT_TYPE, **kwargs) -> None:

        target_chat = kwargs.get("chat_id")
        reply_to = kwargs.get("reply_to_message_id")
        if reply_to is None and kwargs.get("message_thread_id") is None:
            thread_id = self.chat_threads.get(target_chat)
            if thread_id is not None:
                kwargs.setdefault("message_thread_id", thread_id)
        try:
            await context.bot.send_message(**kwargs)
        except TimedOut:
            logger.warning("Отправка сообщения прервана по таймауту (%s)", kwargs.get("chat_id"))
        except Exception:
            logger.exception("Не удалось отправить сообщение (%s)", kwargs.get("chat_id"))

    async def _safe_edit_message(
        self,
        context: ContextTypes.DEFAULT_TYPE,
        chat_id: int,
        message_id: int,
        text: str,
        *,
        markup: Optional[InlineKeyboardMarkup] = None,
    ) -> None:
        try:
            await context.bot.edit_message_text(
                chat_id=chat_id,
                message_id=message_id,
                text=text,
                reply_markup=markup,
                parse_mode=ParseMode.HTML,
                disable_web_page_preview=True,
            )
        except BadRequest as exc:
            if "message is not modified" in str(exc).lower():
                return
            logger.warning("Не удалось отредактировать сообщение %s: %s", message_id, exc)
        except TimedOut:
            logger.warning("Редактирование сообщения прервано по таймауту (%s)", chat_id)
        except Exception:
            logger.exception("Не удалось отредактировать сообщение (%s)", chat_id)

    def _is_group_unlocked(self, chat_id: int) -> bool:
        return not self.test_mode or chat_id in self.test_unlocked_chats

    async def _edit_query_message(
        self,
        query,
        text: str,
        reply_markup: Optional[InlineKeyboardMarkup] = None,
    ) -> None:
        try:
            if query.message and query.message.text is not None:
                await query.edit_message_text(
                    text,
                    reply_markup=reply_markup,
                    parse_mode=ParseMode.HTML,
                )
                return
            if query.message and query.message.caption is not None:
                await query.edit_message_caption(
                    caption=text,
                    reply_markup=reply_markup,
                    parse_mode=ParseMode.HTML,
                )
                return
            await self._safe_send_message(
                query,
                chat_id=query.from_user.id,
                text=text,
                reply_markup=reply_markup,
                parse_mode=ParseMode.HTML,
                disable_web_page_preview=True,
            )
        except BadRequest as exc:
            if "message is not modified" in str(exc).lower():
                return
            logger.warning("Не удалось обновить сообщение: %s", exc)

    async def _pick_random_nuke_target(self, chat_id: int, initiator_id: int) -> Optional[Tuple[int, str]]:
        store = self.ensure_storage()
        banned = await store.banned_users(chat_id)
        exclude: set[int] = set(banned)
        exclude.add(initiator_id)
        bot_id = getattr(self, "bot_id", None)
        if bot_id:
            exclude.add(bot_id)
        candidate: Optional[Tuple[int, str]] = None
        for _ in range(15):
            candidate = await store.random_chat_user(chat_id, exclude=exclude)
            if not candidate:
                break
            uid, uname = candidate
            uname_lower = str(uname).lstrip("@").lower()
            if uname_lower == (self.settings.creator_username or "").lower():
                if random.random() < 0.7:
                    exclude.add(uid)
                    continue
            if self.is_bot_username(uname):
                exclude.add(uid)
                continue
            return candidate
        return candidate

    async def _pick_random_chat_users(
        self,
        chat_id: int,
        count: int,
        *,
        exclude: Iterable[int] | None = None,
    ) -> list[Tuple[int, str]]:
        store = self.ensure_storage()
        excluded = set(exclude or [])
        selected: list[Tuple[int, str]] = []
        for _ in range(max(1, count) * 8):
            candidate = await store.random_chat_user(chat_id, exclude=excluded)
            if not candidate:
                break
            if self.is_bot_username(candidate[1]):
                excluded.add(candidate[0])
                continue
            selected.append(candidate)
            excluded.add(candidate[0])
            if len(selected) >= count:
                break
        return selected

    async def _trigger_nuke(
        self,
        chat_id: int,
        context: ContextTypes.DEFAULT_TYPE,
        initiator,
        target: Optional[Tuple[int, str]],
        currency: Dict[str, Any],
    ) -> None:
        if not target:
            return
        target_id, target_name = target
        key = (chat_id, target_id)
        self.pending_nukes[key] = {"cancelled": False}
        mention_target = self.mention_id(target_id, target_name)
        intro_steps = [
            "Ядерка активирована",
            "Расчёт направления...",
            f"Цель: {mention_target}",
            "Подготовка к отправке",
            "Ядерка отправлена, время ожидания: 1 минута",
        ]

        async def run_intro():
            for step in intro_steps:
                await self._safe_send_message(context, chat_id=chat_id, text=step, parse_mode=ParseMode.HTML)
                await asyncio.sleep(random.uniform(1, 2))

        async def run_nuke():
            try:
                await asyncio.sleep(60)
                if await self.ensure_storage().consume_nuke_shield(chat_id, target_id):
                    await self._safe_send_message(
                        context,
                        chat_id=chat_id,
                        text=f"{mention_target} использовал щит и избежал урона!",
                        parse_mode=ParseMode.HTML,
                    )
                    await self.ensure_storage().log_event(
                        chat_id,
                        f"{self.log_handle(username=target_name, user_id=target_id)} спасся щитом от ядерки",
                    )
                    return
                for countdown in range(10, 0, -1):
                    await self._safe_send_message(
                        context,
                        chat_id=chat_id,
                        text=(
                            f"{mention_target}, в вас запустили ядерку! "
                            f"У вас 10 секунд, чтобы спрятаться ({countdown})"
                        ),
                        parse_mode=ParseMode.HTML,
                    )
                    await asyncio.sleep(0.01)
                await self._safe_send_message(
                    context,
                    chat_id=chat_id,
                    text=f"{mention_target}, спрячься!",
                    reply_markup=InlineKeyboardMarkup(
                        [[InlineKeyboardButton("Спрятаться", callback_data=f"nuke:hide:{chat_id}:{target_id}")]]
                    ),
                    parse_mode=ParseMode.HTML,
                )
                await asyncio.sleep(10)
                if self.pending_nukes.get(key, {}).get("cancelled"):
                    self.pending_nukes.pop(key, None)
                    return
                if await self.ensure_storage().consume_nuke_shield(chat_id, target_id):
                    self.pending_nukes.pop(key, None)
                    await self._safe_send_message(
                        context,
                        chat_id=chat_id,
                        text=f"{mention_target} использовал щит и избежал урона!",
                        parse_mode=ParseMode.HTML,
                    )
                    await self.ensure_storage().log_event(
                        chat_id,
                        f"{self.log_handle(username=target_name, user_id=target_id)} спасся щитом от ядерки",
                    )
                    return
                penalty = -150000
                await self.ensure_storage().adjust_balance(chat_id, target_id, target_name, penalty)
                block_until = time.time() + 3600
                self.nuke_blocks[key] = block_until
                try:
                    await context.bot.restrict_chat_member(
                        chat_id,
                        target_id,
                        permissions=ChatPermissions(
                            can_send_messages=False,
                            can_send_media_messages=False,
                            can_add_web_page_previews=False,
                            can_send_polls=False,
                            can_send_other_messages=False,
                        ),
                        until_date=int(block_until),
                    )
                except Exception:
                    logger.warning("Не удалось выдать мут после ядерки %s", target_id)
                    self.nuke_delete[key] = True
                await self._safe_send_message(
                    context,
                    chat_id=chat_id,
                    text=f"Ядерка взорвалась! Вы потеряли {format_currency(abs(penalty), currency)}!",
                    parse_mode=ParseMode.HTML,
                )
                await self.ensure_storage().log_event(
                    chat_id,
                    (
                        f"{self.log_handle(username=target_name, user_id=target_id)} пострадал от ядерки и заблокирован до "
                        f"{time.strftime('%H:%M:%S', time.localtime(block_until))}"
                    ),
                )
            finally:
                self.pending_nukes.pop(key, None)
        asyncio.create_task(run_intro())
        asyncio.create_task(run_nuke())

    async def handle_nuke_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        query = update.callback_query
        self._remember_thread(update)
        if not query:
            return
        if update.effective_chat and update.effective_chat.type != "private":
            if not self._is_group_unlocked(update.effective_chat.id):
                return
        if await self._should_skip_update(update):
            return
        await self._mark_update_processed(update)
        if not await self._ensure_private_subscription(update, context):
            return
        await query.answer()
        parts = query.data.split(":")
        if len(parts) < 4:
            return
        _action = parts[1]
        chat_id = int(parts[2])
        target_id = int(parts[3])
        if query.from_user.id != target_id and not self.ensure_creator(update):
            await query.answer("Доступ запрещен", show_alert=True)
            return
        key = (chat_id, target_id)
        entry = self.pending_nukes.get(key)
        if entry:
            entry["cancelled"] = True
            await query.edit_message_text("Вы успели спрятаться")
            await self.ensure_storage().log_event(
                chat_id,
                f"{self.log_handle(user=query.from_user)} уклонился от ядерки",
            )
        else:
            await query.edit_message_text("Поздно, взрыв уже произошёл.")

    def pick_username_argument(self, args: list[str]) -> Optional[str]:
        if not args:
            return None
        tail = args[-1].lower()
        numeric_tail = self.parse_amount(args[-1])
        is_all_tail = tail in self.AMOUNT_ALL
        candidates = args[:-1] if (numeric_tail is not None or is_all_tail) else args
        for token in candidates:
            if token.strip():
                return token
        return None

    @staticmethod
    def start_keyboard(bot_username: str) -> InlineKeyboardMarkup:
        return InlineKeyboardMarkup(
            [[InlineKeyboardButton("Добавить группу", url=f"https://t.me/{bot_username}?startgroup=true")]]
        )

    @staticmethod
    def settings_keyboard(
        chat_id: int,
        *,
        blocked: bool = False,
        free_mode: bool = False,
        show_admin_controls: bool = False,
        allow_block: bool = False,
        show_rights: bool = False,
    ) -> InlineKeyboardMarkup:
        toggle = "Разблокировать" if blocked else "Заблокировать"
        rows = [
            [InlineKeyboardButton("Название валюты", callback_data=f"settings:name:{chat_id}")],
            [InlineKeyboardButton("Иконка валюты", callback_data=f"settings:icon:{chat_id}")],
            [InlineKeyboardButton("Курс валюты", callback_data=f"settings:rate:{chat_id}")],
            [InlineKeyboardButton("Дневной бонус", callback_data=f"settings:daily:{chat_id}")],
            [InlineKeyboardButton("Магазин", callback_data=f"settings:shop:{chat_id}")],
            [InlineKeyboardButton("Налог магазина", callback_data=f"settings:tax:{chat_id}")],
            [InlineKeyboardButton("Падежи", callback_data=f"settings:cases:{chat_id}")],
            [InlineKeyboardButton("Автосклонение", callback_data=f"settings:auto:{chat_id}")],
            [InlineKeyboardButton("Префикс", callback_data=f"settings:prefix:{chat_id}")],
        ]
        if show_rights:
            rows.append([InlineKeyboardButton("Права доступа", callback_data=f"settings:rights:{chat_id}")])
        if show_admin_controls and allow_block:
            rows.append([InlineKeyboardButton(toggle, callback_data=f"settings:block:{chat_id}")])
        if show_admin_controls:
            free_label = "Свободный режим ✅" if free_mode else "Свободный режим"
            rows.append([InlineKeyboardButton(free_label, callback_data=f"settings:freemode:{chat_id}")])
            rows.append([InlineKeyboardButton("Удалить", callback_data=f"settings:delete:{chat_id}")])
        return InlineKeyboardMarkup(rows)

    def parse_amount(self, value: str) -> Optional[int]:
        normalized = value.strip().replace(" ", "")
        if not normalized:
            return None
        if normalized.count(",") + normalized.count(".") > 1:
            return None
        if "," in normalized:
            whole, frac = normalized.split(",", 1)
        elif "." in normalized:
            whole, frac = normalized.split(".", 1)
        else:
            whole, frac = normalized, ""
        if not whole and not frac:
            return None
        if whole and not whole.isdigit():
            return None
        if frac and not frac.isdigit():
            return None
        whole_value = int(whole or "0")
        frac_value = int((frac + "00")[:2]) if frac else 0
        if frac:
            return whole_value + (1 if frac_value >= 50 else 0)
        return whole_value

    def validate_amount(self, amount: Optional[int]) -> Optional[int]:
        if amount is None:
            return None
        if amount < self.MIN_TRANSACTION or amount > self.MAX_TRANSACTION:
            return None
        return amount

    def parse_amount_token(self, token: str) -> tuple[Optional[int], bool]:
        token = token.lower()
        if token in self.AMOUNT_ALL:
            return None, True
        return self.validate_amount(self.parse_amount(token)), False

    def parse_percent(self, value: str) -> Optional[int]:
        try:
            normalized = value.replace(",", ".").strip()
            if not normalized:
                return None
            basis_points = (Decimal(normalized).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP) * 100)
            return int(basis_points)
        except Exception:
            return None

    @staticmethod
    def _username_candidate(label: str | None) -> str | None:
        if not label:
            return None
        stripped = label.lstrip("@")
        if not stripped or any(ch.isspace() for ch in stripped):
            return None
        return stripped

    def _hyperlink_user(
        self, user_id: int, label: str | None = None, username: str | None = None, *, notify: bool = True
    ) -> str:
        display = html.escape(label or username or f"id{user_id}")
        if notify:
            return f'<a href="tg://user?id={int(user_id)}">{display}</a>'
        username = self._username_candidate(username or label)
        if username:
            safe_username = html.escape(username)
            return f"<a href=\"https://t.me/{safe_username}\">{display}</a>"
        return display

    def mention(self, user) -> str:
        if not user:
            return "неизвестен"
        label = user.full_name or user.username or str(user.id)
        try:
            uid = int(user.id)
        except Exception:
            return html.escape(label)
        return self._hyperlink_user(uid, label, getattr(user, "username", None))

    @staticmethod
    def _format_plain_amount(amount_cents: int) -> str:
        sign = "-" if amount_cents < 0 else ""
        cents = abs(int(amount_cents))
        units, remainder = divmod(cents, 100)
        if remainder == 0:
            return f"{sign}{units}"
        return f"{sign}{units}.{remainder:02d}".rstrip("0").rstrip(".")

    def mention_id(self, user_id: int, name: str | None = None, *, notify: bool = True) -> str:
        label = (name or f"id{user_id}").lstrip("@")
        return self._hyperlink_user(user_id, label, notify=notify)

    def hyperlink_username(self, username: str | None, user_id: int | None = None) -> str:
        if user_id is not None:
            return self.mention_id(user_id, username or str(user_id))
        if username:
            safe = html.escape(username.lstrip("@"))
            return f"<a href=\"https://t.me/{safe}\">{safe}</a>"
        return "<i>неизвестен</i>"

    @staticmethod
    def log_handle(user: Any = None, *, username: str | None = None, user_id: int | None = None) -> str:
        if username:
            return username.lstrip("@") if username.strip() else (f"id{user_id}" if user_id else "неизвестен")
        if user and getattr(user, "username", None):
            return user.username
        if user and getattr(user, "full_name", None):
            return user.full_name
        if user_id:
            return f"id{user_id}"
        return "неизвестен"

    @staticmethod
    def resolve_role(perms: dict, user_id: int) -> str:
        if user_id in set(perms.get("banned", [])):
            return "banned"
        if user_id in perms.get("economy_admins", []):
            return "admin"
        if user_id in perms.get("allow_credit", []) or user_id in perms.get("allow_debit", []):
            return "moderator"
        return "default"

    @staticmethod
    def render_purchases(items: tuple, currency: Dict) -> str:
        if not items:
            return "<b>История покупок пуста.</b>"
        lines = ["<b>История покупок:</b>"]
        for title, price, seller_username, _seller_id, created_at in items:
            seller_username = (seller_username or "").lstrip("@")
            safe_seller = html.escape(seller_username)
            seller = (
                f"{safe_seller}" if seller_username else "неизвестен"
            )
            timestamp = time.strftime("%d.%m.%Y", time.localtime(created_at))
            safe_title = html.escape(title)
            lines.append(
                f"• <blockquote>{safe_title}</blockquote>\n"
                f"<i>{timestamp}</i> - <b>{format_currency(price, currency)}</b> - {seller}"
            )
        return "\n\n".join(lines)

    def ensure_creator(self, update: Update) -> bool:
        user = update.effective_user
        username = (user.username or "").lower() if user else ""
        return username == self.settings.creator_username

    async def _should_skip_update(self, update: Update) -> bool:
        if not update.update_id:
            return False
        store = self.ensure_storage()
        return await store.is_update_processed(update.update_id)

    async def _mark_update_processed(self, update: Update) -> None:
        if not update.update_id:
            return
        store = self.ensure_storage()
        await store.mark_update_processed(update.update_id)

    async def error_handler(self, update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
        logger.exception("Необработанная ошибка в обработчике: %s", context.error)
        store = self.storage
        if not store:
            return
        try:
            await store.record_metric("errors_total", 1)
            kind = "unknown"
            if isinstance(update, Update):
                if update.callback_query:
                    kind = "callback"
                elif update.message:
                    kind = "message"
                elif update.my_chat_member:
                    kind = "chat_member"
                elif update.pre_checkout_query:
                    kind = "precheckout"
            await store.record_metric(f"errors_{kind}", 1)
        except Exception:
            logger.debug("Не удалось записать метрику ошибки")

    async def _filter_active_chats(
        self, chat_ids: Iterable[int], context: ContextTypes.DEFAULT_TYPE, *, keep_all: bool = False
    ) -> tuple[int, ...]:

        if keep_all:
            return tuple(dict.fromkeys(chat_ids))

        active: list[int] = []
        for cid in chat_ids:
            try:
                member = await context.bot.get_chat_member(cid, self.bot_id)
                if member.status not in {"member", "administrator"}:
                    raise RuntimeError("not a member")
                active.append(cid)
            except Exception:
                logger.debug("Чат %s недоступен или бот не состоит", cid)
        return tuple(active)

    async def _ensure_subscription(
        self,
        user,
        context: ContextTypes.DEFAULT_TYPE,
        *,
        prompt_message: Optional[Message] = None,
    ) -> bool:
        if not (self.news_channel_link or self.news_channel_id) or not user:
            return True
        if await self._is_subscribed(user, context):
            return True
        url = await self._news_channel_link(context)
        keyboard = InlineKeyboardMarkup([[InlineKeyboardButton("✅ Подписаться", url=url)]])
        text = (
            "❌ <b>Вы не подписались на канал новостей!</b>\n"
            "📢 Подпишитесь, чтобы пользоваться ботом и получать обновления."
        )
        if prompt_message:
            await prompt_message.reply_text(text, reply_markup=keyboard, parse_mode=ParseMode.HTML)
        else:
            await context.bot.send_message(user.id, text, reply_markup=keyboard, parse_mode=ParseMode.HTML)
        return False

    async def _ensure_private_subscription(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
        chat = update.effective_chat
        if not chat or chat.type != "private":
            return True
        user = update.effective_user
        if await self._is_subscribed(user, context):
            return True
        await self._ensure_subscription(user, context, prompt_message=update.effective_message)
        query = update.callback_query
        if query:
            try:
                await query.answer("❌ Требуется подписка на новости.", show_alert=True)
            except Exception:
                pass
        return False

    async def _is_subscribed(self, user, context: ContextTypes.DEFAULT_TYPE) -> bool:
        if not (self.news_channel_link or self.news_channel_id) or not user:
            return True
        # try resolving channel id if not cached
        if not self.news_channel_id:
            await self._resolve_news_channel(context)
        if not self.news_channel_id:
            return False
        try:
            member = await context.bot.get_chat_member(self.news_channel_id, user.id)
            if member.status in {"member", "administrator", "creator"}:
                return True
        except Exception:
            pass
        return False

    # endregion helpers

    async def post_init(self, application: Application):
        self.storage = await MySQLEconomyStorage.create(
            host=self.settings.db_host,
            port=self.settings.db_port,
            user=self.settings.db_user,
            password=self.settings.db_password,
            db=self.settings.db_name,
        )
        me = await application.bot.get_me()
        self.bot_id = me.id
        application.bot_data["bot_username"] = me.username
        if self.news_channel_link:
            await self._resolve_news_channel(application)
        if not self._reminder_task:
            self._reminder_task = asyncio.create_task(self._reminder_loop(application))
        if not self._escript_task:
            self._escript_task = asyncio.create_task(self._escript_daily_loop(application))
        if not self._daily_stats_task:
            self._daily_stats_task = asyncio.create_task(self._daily_stats_loop(application))
        asyncio.create_task(self._scan_escripts_on_start(application))

    async def _news_channel_link(self, context: ContextTypes.DEFAULT_TYPE) -> str:

        if self.news_channel_url:
            return self.news_channel_url
        await self._resolve_news_channel(context)
        # fallback to provided link or chat id if resolution failed
        if not self.news_channel_url:
            if self.news_channel_link:
                self.news_channel_url = self.news_channel_link
            elif self.news_channel_id and str(self.news_channel_id).startswith("-100"):
                self.news_channel_url = f"https://t.me/c/{str(self.news_channel_id)[4:]}"
        return self.news_channel_url or ""

    async def _resolve_news_channel(self, ctx) -> None:
        bot = getattr(ctx, "bot", None)
        if bot is None and hasattr(ctx, "application"):
            bot = getattr(ctx.application, "bot", None)
        if not bot:
            return
        # Сначала пробуем ID из настроек
        if self.news_channel_id:
            try:
                chat = await bot.get_chat(self.news_channel_id)
                self.news_channel_id = chat.id
                if chat.username:
                    self.news_channel_url = f"https://t.me/{chat.username}"
                elif chat.invite_link:
                    self.news_channel_url = chat.invite_link
                elif str(chat.id).startswith("-100"):
                    self.news_channel_url = f"https://t.me/c/{str(chat.id)[4:]}"
                return
            except Exception:
                logger.debug("Не удалось получить чат новостей по ID")
        if not self.news_channel_link:
            return
        try:
            chat = await bot.get_chat(self.news_channel_link)
        except Exception:
            return
        self.news_channel_id = chat.id
        if chat.username:
            self.news_channel_url = f"https://t.me/{chat.username}"
        elif chat.invite_link:
            self.news_channel_url = chat.invite_link
        elif str(chat.id).startswith("-100"):
            self.news_channel_url = f"https://t.me/c/{str(chat.id)[4:]}"

    async def _reminder_loop(self, application: Application) -> None:
        await asyncio.sleep(5)
        while True:
            try:
                plans = await self.ensure_storage().list_user_plans()
                for rec in plans:
                    user_stub = type("UserStub", (), {"id": rec.get("user_id"), "username": None})()
                    await self._maybe_send_plan_reminder(user_stub, application, rec)
            except Exception as exc:
                logger.debug("Плановые напоминания не отправлены: %s", exc)
            await asyncio.sleep(3600)

    async def _escript_daily_loop(self, application: Application) -> None:
        await asyncio.sleep(10)
        while True:
            try:
                chats = await self.ensure_storage().list_chats()
                for chat_id in chats:
                    try:
                        owner_id = await self.ensure_storage().chat_owner(chat_id)
                        if not owner_id:
                            continue
                        user_stub = type("UserStub", (), {"id": owner_id, "username": None})()
                        plan_info = await self._plan_for_user(user_stub)
                        if not self._plan_allowed(plan_info.get("plan"), PLAN_ULTIMATE):
                            continue
                        await self.escripts.run_daily_events(chat_id, application)
                    except Exception as exc:
                        logger.debug("EScripting daily failed for %s: %s", chat_id, exc)
            except Exception as exc:
                logger.debug("EScripting daily loop error: %s", exc)
            await asyncio.sleep(60)

    async def _daily_stats_loop(self, application: Application) -> None:
        await asyncio.sleep(5)
        while True:
            now = datetime.now(tz=self.LOCAL_TZ)
            today_target = now.replace(hour=23, minute=0, second=0, microsecond=0)
            if now >= today_target:
                today_target = today_target + timedelta(days=1)
            delay = (today_target - now).total_seconds()
            await asyncio.sleep(delay)
            try:
                await self._send_daily_stats(application)
            except Exception as exc:
                logger.warning("Не удалось отправить ежедневную статистику: %s", exc)

    async def _send_daily_stats(self, application: Application) -> None:
        if not self.news_channel_id:
            return
        store = self.ensure_storage()
        now_ts = int(time.time())
        today_key = self._date_key(now_ts)
        yesterday_key = self._previous_date_key(now_ts)
        today_commands = await store.daily_command_totals(today_key)
        yesterday_commands = await store.daily_command_totals(yesterday_key)
        total_groups = await store.count_chats()
        prev_total_groups = await store.get_daily_metric("groups_total", date_key=yesterday_key)
        group_delta = total_groups - (prev_total_groups if prev_total_groups is not None else total_groups)
        premium_total = await store.count_premium_users()
        activity_change_base = max(yesterday_commands.get("total", 0), 1)
        activity_delta = today_commands.get("total", 0) - yesterday_commands.get("total", 0)
        activity_pct = Decimal(activity_delta * 100) / Decimal(activity_change_base)
        activity_label = f"{'+' if activity_delta >= 0 else ''}{activity_pct.quantize(Decimal('1.'), rounding=ROUND_HALF_UP)}%"
        await store.set_daily_metric("groups_total", total_groups, date_key=today_key)
        parts = [
            "☀️<b>Ежедневная статистика</b>:",
            f"\nКоманд за день: <u>{today_commands.get('total', 0)}</u>",
            f"\nГрупп за день: <u>{'+' if group_delta >= 0 else ''}{group_delta}</u>",
            f"\nВсего групп: <u>{total_groups}</u>",
            f"\nПремиум-пользователей: <u>{premium_total}</u>",
            f"\nАктивных пользователей: <u>{today_commands.get('users', 0)}</u>",
            f"\n\nРезультат активности: <u>{activity_label}</u>",
        ]
        text = "\n".join(parts)
        try:
            await application.bot.send_message(self.news_channel_id, text, parse_mode=ParseMode.HTML)
        except Exception as exc:
            logger.warning("Не удалось отправить статистику в канал %s: %s", self.news_channel_id, exc)

    async def _scan_escripts_on_start(self, application: Application) -> None:
        await asyncio.sleep(2)
        store = self.ensure_storage()
        chats = await store.list_chats()
        for chat_id in chats:
            scripts = await store.list_escripts(chat_id)
            for row in scripts:
                script_id = int(row[0])
                script_name = row[1]
                filename = row[2]
                script_path = Path(filename)
                if not script_path.exists():
                    continue
                try:
                    raw = script_path.read_bytes()
                except Exception:
                    continue
                data, errors, warnings, log_text = await self._compile_escript_payload(
                    chat_id=chat_id,
                    script_id=script_id,
                    script_name=script_name,
                    raw_data=raw,
                    author=None,
                )
                log_path = self.escripts.log_path(chat_id, script_id)
                try:
                    log_path.write_text(log_text, encoding="utf-8")
                except Exception:
                    log_path = None
                if errors:
                    await store.update_escript_meta(
                        chat_id=chat_id,
                        script_id=script_id,
                        errors=len(errors),
                        warnings=len(warnings),
                        log_path=str(log_path) if log_path else None,
                        active=False,
                    )
                    await self.escripts.refresh_script(chat_id, script_id)
                    try:
                        await application.bot.send_message(
                            chat_id,
                            (
                                f"⚠️ Скрипт \"{script_name}\" отключён: найдено ошибок {len(errors)}. "
                                f"Предупреждения: {len(warnings)}."
                            ),
                        )
                    except Exception:
                        pass
                else:
                    await store.update_escript_meta(
                        chat_id=chat_id,
                        script_id=script_id,
                        errors=0,
                        warnings=len(warnings),
                        log_path=str(log_path) if log_path else None,
                        active=True,
                    )
                    await self.escripts.refresh_script(chat_id, script_id)
    async def start(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if update.effective_chat.type != "private":
            return
        if await self._should_skip_update(update):
            return
        await self._mark_update_processed(update)
        if update.effective_user and not await self._check_cooldown(update.effective_user.id, message=update.message):
            return

        payload = ""
        if update.message and update.message.text:
            parts = update.message.text.split(maxsplit=1)
            if len(parts) > 1:
                payload = parts[1].strip()
        if payload.startswith("poker-") and update.effective_user:
            joined = await self.casino.join_poker_from_private(
                context, code=payload.replace("poker-", "", 1), user=update.effective_user
            )
            if joined:
                return

        bot_username = context.bot_data.get("bot_username") or (await context.bot.get_me()).username
        text = self._start_overview(context)
        try:
            subscribed = await self._is_subscribed(update.effective_user, context)
            if subscribed:
                await update.message.reply_text(text, reply_markup=self.start_keyboard(bot_username))
            else:
                await update.message.reply_text(text)
                await self._ensure_subscription(update.effective_user, context, prompt_message=update.message)
        except TimedOut:
            logger.warning("Timeout while sending start message")
        except Exception as exc:
            logger.error("Не удалось отправить приветствие: %s", exc)

    async def testmode_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if update.effective_chat.type != "private":
            return
        if await self._should_skip_update(update):
            return
        await self._mark_update_processed(update)
        if update.effective_user and not await self._check_cooldown(update.effective_user.id, message=update.message):
            return
        if not self.ensure_creator(update):
            await update.message.reply_text("Доступ запрещен")
            return
        self.test_mode = not self.test_mode
        if self.test_mode:
            await update.message.reply_text(
                "Тестовый режим включён. Бот работает только в разблокированных группах. "
                "Для разблокировки напишите в группе: unlock 1917"
            )
            return
        self.test_unlocked_chats.clear()
        await update.message.reply_text("Тестовый режим выключен. Все группы снова доступны.")


    def _start_overview(self, context: ContextTypes.DEFAULT_TYPE) -> str:
        prefix = self.COMMAND_PREFIXES[0]
        return (
            "Привет! Я экономический бот.\n"
            "Я помогу вести виртуальную экономику, кастомные скрипты и многое другое.\n\n"
            "⬇️ Начни с команд:\n"
            "• /help - подробная справка по разделам\n"
            "• /plans - посмотреть подписки и статус\n"
            "• /settings - группы, куда ты добавил бота\n"
            "• /promo - Ввод промокода\n\n"
            f"Поддержка: @softeconomy_support"
        )

    @staticmethod
    def _scaled_daily_bonus(currency: Dict[str, Any], multiplier: str, minimum: int) -> int:
        base = Decimal(str(currency.get("daily_reward", 10000)))
        scaled = (base * Decimal(multiplier)).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
        return max(minimum, int(scaled))

    def _should_skip_cooldown(self, text: str) -> bool:
        if not text:
            return False
        lowered = text.lower()
        return any(
            token in lowered
            for token in (
                "используй",
                "укажи",
                "нужно",
                "формат",
                "не удалось",
                "не найден",
            )
        )

    def describe_commands(
        self, prefix: str, currency_name: str, currency_icon: str, *, free_mode: bool = False
    ) -> str:
        visible_prefix = prefix or self.COMMAND_PREFIXES[0]
        balance_lines = "".join(
            (
                f"{prefix}баланс зачислить @user amount: начислить {currency_icon} {currency_name} (админы)\n" if free_mode else "",
                f"{prefix}баланс изъять @user amount/all: изъять {currency_icon} {currency_name} (админы)\n",
                f"{prefix}баланс установить @user amount: задать баланс {currency_icon} {currency_name} (админы)\n" if free_mode else "",
            )
        )
        return (
            f"<b>Команды с префиксом {visible_prefix}</b>\n"
            f"{prefix}помощь: показать справку\n"
            f"{prefix}баланс [@user]: показать баланс\n"
            f"{balance_lines}"
            f"{prefix}топ: топ пользователей по балансу\n"
            f"{prefix}курс: показать текущий курс\n"
            f"{prefix}перевод @user amount: перевести свои средства другому участнику\n"
            f"{prefix}ежедневка: получить ежедневный бонус\n"
            f"{prefix}профиль [@user]: карточка игрока\n"
            f"{prefix}права: показать свои права\n"
            f"{prefix}выдатьправа @user [admin|credit|debit]: выдать доступ\n"
            f"{prefix}отобратьправа @user [admin|credit|debit]: удалить доступ\n"
            f"{prefix}магазин: показать витрину наград и прокачек\n"
            f"{prefix}покупки [@user]: показать историю покупок\n"
            f"{prefix}товар использовать индекс [@user]: активировать купленное\n"
            f"{prefix}казино рулетка {{красный/черный/число}} {{ставка}}, слоты {{ставка}}, блэкджек {{ставка}} (от Медиум)\n"
            f"{prefix}казино покер {{игроки до 10}} {{ставка}}, монетка орел/решка {{ставка}}, кости {{ставка}} (покер — от Медиум)\n"
            f"{prefix}казна [депозит|вывод] сумма: управление казной\n"
            f"{prefix}инфо: сводка по группе\n"
            f"{prefix}работа [инфо @user]: работа и статистика\n"
            f"{prefix}ограбить @user: попытка украсть 40% баланса (1% шанс забрать всё) (от Медиум)\n"
        )

    def _plan_label(self, plan_info: dict) -> str:
        plan_code = plan_info.get("plan", PLAN_BASIC)
        name = {PLAN_BASIC: "Обычный", PLAN_MEDIUM: "Медиум", PLAN_ULTIMATE: "Ультиматум"}.get(plan_code, "Обычный")
        expires = plan_info.get("expires_at", 0)
        if expires:
            ts = time.strftime("%Y-%m-%d", time.localtime(expires))
            return f"{name} (до {ts})"
        return f"{name}"

    def _plans_text(self, plan_info: dict) -> str:
        status = self._plan_label(plan_info)
        limits = self._plan_limits_text(plan_info.get("plan", PLAN_BASIC))
        return (
            "<b>Планы бота</b>\n"
            f"Текущий план: {status}\n{limits}\n\n"
            "Обычный: 1 группа, без !!работа/!!ограбить. Казна доступна.\n"
            f"Медиум: до 3 групп, без !!работа. Стоимость: {self.settings.plan_medium_stars} ⭐ или {self.settings.plan_medium_rub}₽ в месяц.\n"
            f"Ультиматум: без ограничений. Стоимость: {self.settings.plan_ultimate_stars} ⭐ или {self.settings.plan_ultimate_rub}₽ в месяц."
        )

    def _plan_limits_text(self, plan_code: str) -> str:
        limits = self._plan_limits(plan_code)
        if plan_code == PLAN_ULTIMATE:
            return "Ограничения отсутствуют."
        return (
            f"Лимиты: переводы до {self._format_plain_amount(int(limits['transfer']))} в сутки, "
            f"зачисления до {self._format_plain_amount(int(limits['credit']))} в сутки, групп: {limits['groups']}"
        )

    def _help_pages_group(
        self,
        shop_type: str,
        *,
        prefix: str = "!!",
        script_commands: Optional[list[tuple[str, str]]] = None,
        free_mode: bool = False,
    ) -> list[str]:
        pages: list[str] = []
        pages.append(
            "<b>Команды группы</b>\n"
            f"• {prefix}баланс [@user]: баланс пользователя\n"
            f"• {prefix}профиль [@user]: профиль и рейтинг пользователя\n"
            f"• {prefix}топ, {prefix}курс: топ и курс валюты\n"
            f"• {prefix}казино: рулетка/слоты/блэкджек/покер/монетка/кости\n"
            f"• {prefix}инфо: сводка по группе\n"
            f"• {prefix}скрипты: меню и сводка скриптов (от Ультиматум)\n"
        )
        pages.append(
            "<b>Экономика</b>\n"
            + (f"• {prefix}баланс зачислить @user amount (админы)\\n" if free_mode else "")
            + f"• {prefix}баланс изъять @user amount/all (админы)\n"
            + (f"• {prefix}баланс установить @user amount (админы)\\n" if free_mode else "")
            + f"• {prefix}перевод @user amount: перевод средств\n"
            + f"• {prefix}ежедневка: ежедневный бонус\n"
            + f"• {prefix}казна …\n"
            + f"• {prefix}работа …: смена или тест (от Ультиматум)\n"
            + f"• {prefix}ограбить @user (от Медиум)\n"
            + f"• {prefix}казино рулетка {{красный/черный/число}} {{ставка}}, слоты {{ставка}}\n"
            + f"• {prefix}казино блэкджек {{ставка}} (от Медиум), покер {{игроки до 10}} {{ставка}} (от Медиум), монетка орел/решка {{ставка}}\n"
            + f"• {prefix}казино кости {{ставка}}\n"
        )
        if shop_type == "normal":
            pages.append(
                "<b>Магазин</b>\n"
                f"• {prefix}магазин: витрина товаров\n"
                f"• {prefix}покупки [@user]: история покупок\n"
                f"• {prefix}товар добавить \"Название\" цена [кол-во]: добавить товар\n"
                f"• {prefix}товар удалить {{индекс}}: удалить товар\n"
                f"• {prefix}товар настроить {{индекс}}: изменить товар\n"
            )
        else:
            pages.append(
                "<b>Магазин</b>\n"
                f"• {prefix}магазин: витрина товаров\n"
                f"• {prefix}покупки [@user]: история покупок\n"
                f"• {prefix}товар использовать {{индекс}} [@user]: активировать покупку\n"
            )
        if script_commands:
            lines = ["<b>Скриптовые команды</b>"]
            for cmd, desc in script_commands:
                safe_desc = desc or "Описание отсутствует"
                lines.append(f"• {prefix}{cmd}: {html.escape(safe_desc)}")
            pages.append("\n".join(lines))
        return pages

    async def _check_cooldown(self, user_id: int, *, message=None) -> bool:
        if self.test_mode:
            return True
        key = f"cmd:{user_id}"
        store = self.ensure_storage()
        on_cooldown = await store.check_cooldown(key, 5)
        if on_cooldown:
            if message is not None:
                asyncio.create_task(message.reply_text("⏳ Подождите 5 секунд перед следующей командой."))
            return False
        return True

    async def _check_cooldown_with_text(self, user_id: int, text: str) -> bool:
        if self._should_skip_cooldown(text):
            return True
        return await self._check_cooldown(user_id)

    def _help_pages_for_plan(
        self,
        plan_info: dict,
        shop_type: str = "fixed",
        *,
        is_creator: bool = False,
        has_groups: bool = False,
    ) -> list[str]:
        status = self._plan_label(plan_info)
        limits_text = self._plan_limits_text(plan_info.get("plan", PLAN_BASIC))
        pages: list[str] = []
        pages.append(
            "<b>Команды в личных сообщениях</b>\n"
            f"Статус подписки: {status}\n{limits_text}\n\n"
            "• /start - краткая справка и быстрые кнопки запуска.\n"
            "• /help - подробная справка с навигацией по страницам.\n"
            "• /settings - открыть настройки групп, где ты владелец.\n"
            "• /plans - информация о подписке и выбор способа оплаты.\n"
            "• /promo - ввод промокода на план.\n"
            + (
                "• /backup save|load N - создать/восстановить бэкап базы.\n"
                "• /msg_all - получить приглашение и разослать ответ во все группы (текст, .md/.html, медиа).\n"
                "• /msg - выбрать группу, получить приглашение и отправить в неё ответ с форматированием.\n"
                "• /give_plan @user plan duration - выдать план вручную.\n"
                if is_creator
                else ""
            )
        )
        if has_groups or is_creator:
            pages.append(
                "<b>Кнопки настроек группы (в /settings)</b>\n"
                "• Название валюты - изменить отображаемое имя валюты.\n"
                "• Иконка валюты - сменить символ/эмодзи валюты.\n"
                "• Курс валюты - установить стоимость 1 единицы.\n"
                "• Дневной бонус - размер награды за !!ежедневка.\n"
                "• Магазин - переключение типа магазина (обычный/фиксированный).\n"
                "• Налог магазина - процент комиссии с покупок.\n"
                "• Падежи - формы склонения валюты (1/несколько/много).\n"
                "• Автосклонение - включить/выключить автоформы валюты.\n"
                "• Префикс - список префиксов команд (по одному на строку).\n"
                + (
                    "• Права доступа - список user_id для ролей admin/credit/debit.\n"
                    "• Заблокировать - выключить экономику в группе.\n"
                    "• Удалить - удалить группу из базы и выйти из чата.\n"
                    if is_creator
                    else "• Удалить - удалить группу из базы и выйти из чата.\n"
                )
            )
        else:
            pages.append(
                "<b>Кнопки настроек группы</b>\n"
                "Настройки доступны владельцам групп. Сначала добавь бота в группу и стань владельцем."
            )
        pages.append(
            "<b>Команды в группе</b>\n"
            "• !!помощь: краткая справка по командам чата.\n"
            "• !!баланс [@user]: посмотреть баланс пользователя.\n"
            "• !!профиль [@user]: профиль и рейтинг пользователя.\n"
            "• !!топ: топ богатейших участников.\n"
            "• !!курс: текущий курс валюты.\n"
            "• !!инфо: сводка по настройкам и участникам.\n"
            "• !!права: список ролей доступа в группе.\n"
            "• !!бан @user: запретить экономику пользователю (модератор).\n"
            "• !!разбанить @user: снять запрет (модератор).\n"
            "• !!лог: последние события экономики (админ).\n"
            "• !!казино: рулетка, слоты, блэкджек, покер (до 10 игроков), монетка и кости.\n"
            "• !!скрипты: меню скриптов (от Ультиматум).\n"
        )
        pages.append(
            "<b>Экономика и магазин</b>\n"
            "• !!баланс зачислить @user amount: начислить средства (админ).\n"
            "• !!баланс изъять @user amount/all: списать средства (админ).\n"
            "• !!баланс установить @user amount: задать баланс (админ).\n"
            "• !!перевод @user amount: перевод между участниками.\n"
            "• !!ежедневка: получить дневной бонус.\n"
            "• !!казна …: операции с казной.\n"
            "• !!казино рулетка {красный/черный/число} {ставка}, слоты {ставка}.\n"
            "• !!казино блэкджек {ставка}, покер {игроки до 10} {ставка}.\n"
            "• !!казино монетка орел/решка {ставка}, кости {ставка}.\n"
            "• !!магазин: открыть витрину товаров.\n"
            "• !!покупки [@user]: история покупок.\n"
            + (
                "• !!товар добавить \"Название\" цена [кол-во]: создать товар.\n"
                "• !!товар удалить {индекс}: удалить товар.\n"
                "• !!товар настроить {индекс}: изменить товар.\n"
                if shop_type == "normal"
                else "• !!товар использовать {индекс} [@user]: активировать покупку.\n"
            )
            + "• !!работа: начать смену/тест (от Ультиматум).\n"
            "• !!работа инфо [@user]: карточка работы и счёт.\n"
            "• !!ограбить @user: попытка ограбления (от Медиум).\n"
            "• !!выдатьправа @user: выдать доступ к команде (админ).\n"
        )
        return pages

    def _help_keyboard(self, page: int, total: int) -> InlineKeyboardMarkup:
        buttons: list[list[InlineKeyboardButton]] = []
        row: list[InlineKeyboardButton] = []
        if page > 0:
            row.append(InlineKeyboardButton("←", callback_data=f"help:page:{page-1}"))
        if page < total - 1:
            row.append(InlineKeyboardButton("→", callback_data=f"help:page:{page+1}"))
        if row:
            buttons.append(row)
        return InlineKeyboardMarkup(buttons) if buttons else None

    async def help_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if update.effective_chat.type != "private":
            return
        if await self._should_skip_update(update):
            return
        await self._mark_update_processed(update)
        if update.effective_user and not await self._check_cooldown(update.effective_user.id, message=update.message):
            return
        plan = await self._plan_for_user_with_reminder(update.effective_user, context)
        is_creator = self.ensure_creator(update)
        store = self.ensure_storage()
        has_groups = bool(await store.chats_by_owner(update.effective_user.id)) if update.effective_user else False
        pages = self._help_pages_for_plan(plan, shop_type="fixed", is_creator=is_creator, has_groups=has_groups)
        page = 0
        kb = self._help_keyboard(page, len(pages))
        sent = await update.message.reply_text(pages[page], reply_markup=kb)
        self.help_sessions[sent.message_id] = pages

    async def help_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        query = update.callback_query
        self._remember_thread(update)
        if not query:
            return
        if await self._should_skip_update(update):
            return
        await self._mark_update_processed(update)
        await query.answer()
        parts = query.data.split(":")
        if len(parts) != 3:
            return
        try:
            page = int(parts[2])
        except ValueError:
            return
        plan = await self._plan_for_user_with_reminder(query.from_user, context)
        is_creator = self.ensure_creator(update)
        store = self.ensure_storage()
        has_groups = bool(await store.chats_by_owner(query.from_user.id))
        pages = self.help_sessions.get(query.message.message_id) or self._help_pages_for_plan(
            plan,
            is_creator=is_creator,
            has_groups=has_groups,
        )
        self.help_sessions[query.message.message_id] = pages
        page = max(0, min(page, len(pages) - 1))
        kb = self._help_keyboard(page, len(pages))
        try:
            await query.edit_message_text(pages[page], reply_markup=kb)
        except BadRequest as exc:
            if "Message is not modified" not in str(exc):
                logger.warning("Не удалось обновить страницу помощи: %s", exc)

    async def on_bot_added(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        chat_member_update = update.my_chat_member
        if not chat_member_update:
            return
        if await self._should_skip_update(update):
            return
        await self._mark_update_processed(update)
        new_status = chat_member_update.new_chat_member.status
        old_status = chat_member_update.old_chat_member.status
        if new_status not in {"member", "administrator"}:
            return
        if old_status in {"member", "administrator"}:
            return
        chat = update.effective_chat
        if chat.type == "private":
            return
        # Каналы не поддерживаются (кроме новостного); уходим через 10 секунд после уведомления
        if chat.type == "channel":
            if self.news_channel_link and not self.news_channel_id:
                await self._resolve_news_channel(context)
            if self.news_channel_id and chat.id == self.news_channel_id:
                return
            inviter = update.effective_user
            notice_text = (
                f"Бот не поддерживает каналы. Экономика для канала {chat.title} будет отключена через 10 секунд."
            )
            sent_to = False
            if inviter:
                try:
                    await context.bot.send_message(inviter.id, notice_text)
                    sent_to = True
                except Exception:
                    logger.warning("Не удалось уведомить пригласившего об отключении канала %s", chat.id)
            if not sent_to:
                try:
                    admins = await context.bot.get_chat_administrators(chat.id)
                except Exception:
                    admins = []
                for admin in admins:
                    try:
                        await context.bot.send_message(admin.user.id, notice_text)
                        sent_to = True
                        break
                    except Exception:
                        continue
            try:
                await context.bot.send_message(chat.id, notice_text)
            except Exception:
                logger.debug("Не удалось отправить уведомление в канал %s", chat.id)

            async def _delayed_leave():
                await asyncio.sleep(10)
                try:
                    await context.bot.leave_chat(chat.id)
                except Exception:
                    logger.warning("Не удалось покинуть канал %s", chat.id)

            asyncio.create_task(_delayed_leave())
            return
        store = self.ensure_storage()
        inviter = update.effective_user
        owner_id = inviter.id if inviter else None
        if owner_id:
            if self.ensure_creator(update):
                owner_plan = {"plan": PLAN_ULTIMATE}
            else:
                owner_plan = await store.ensure_plan(owner_id)
            limits = self._plan_limits(owner_plan.get("plan", PLAN_BASIC))
            group_limit = limits.get("groups")
            current = await store.count_chats_by_owner(owner_id)
            if group_limit and current >= group_limit:
                try:
                    await context.bot.send_message(
                        owner_id,
                        "Достигнут максимальный лимит на добавление в группы.",
                        parse_mode=ParseMode.HTML,
                    )
                except Exception:
                    logger.warning("Не удалось уведомить о лимите групп %s", owner_id)
                try:
                    await context.bot.leave_chat(chat.id)
                except Exception:
                    logger.warning("Не удалось выйти из чата %s при превышении лимита", chat.id)
                return
                await store.set_chat_owner(chat.id, owner_id)
        try:
            await store.record_daily_metric("groups_added", 1, date_key=self._date_key())
        except Exception:
            logger.debug("Не удалось записать статистику по новой группе %s", chat.id)
        currency = await store.chat_currency(chat.id)
        prefixes = await store.chat_prefixes(chat.id)
        greet = (
            f"Привет, {chat.title}! Я готов управлять экономикой.\n\n"
            + self.describe_commands(
                prefixes[0], currency.get("name", "валюта"), currency.get("icon", "💰"), free_mode=bool(currency.get("free_mode"))
            )
            + "\nУправлять экономикой могут администраторы чата"
        )
        await context.bot.send_message(chat.id, greet, parse_mode=ParseMode.HTML)

        # Заносим известных участников (админов, пригласившего и бота) в базу для быстрых операций
        try:
            admins = await context.bot.get_chat_administrators(chat.id)
        except Exception:
            admins = []
        known_users = [(adm.user.id, adm.user.username or adm.user.full_name or str(adm.user.id)) for adm in admins]
        inviter = update.effective_user
        if inviter:
            known_users.append((inviter.id, inviter.username or inviter.full_name or str(inviter.id)))
        known_users.append((context.bot.id, context.bot.name))
        await store.register_users(chat.id, known_users)
        if inviter:
            await store.set_chat_owner(chat.id, inviter.id)
            perms = await store.permissions(chat.id)
            economy_admins = set(perms.get("economy_admins", []))
            economy_admins.add(inviter.id)
            await store.update_permissions(
                chat.id,
                economy_admins=list(economy_admins),
                allow_credit=perms.get("allow_credit", []),
                allow_debit=perms.get("allow_debit", []),
            )

        if inviter and inviter.id != context.bot.id:
            await context.bot.send_message(
                inviter.id,
                f"Бот добавлен в канал <b>{chat.title}</b>.",
                reply_markup=self.settings_keyboard(
                    chat.id,
                    blocked=bool(currency.get("blocked")),
                    free_mode=bool(currency.get("free_mode")),
                    show_admin_controls=True,
                    show_rights=bool(self.settings.creator_id and inviter.id == self.settings.creator_id),
                ),
                parse_mode=ParseMode.HTML,
            )

    async def send_settings_panel(
        self,
        user_id: int,
        chat_id: int,
        context: ContextTypes.DEFAULT_TYPE,
        message_id: Optional[int] = None,
        *,
        show_admin_controls: Optional[bool] = None,
        allow_block: bool = False,
    ) -> None:
        store = self.ensure_storage()
        currency = await store.chat_currency(chat_id)
        perms = await store.permissions(chat_id)
        free_mode = bool(currency.get("free_mode"))
        if show_admin_controls is None:
            owner_id = await store.chat_owner(chat_id)
            show_admin_controls = owner_id == user_id
        prefixes = await store.chat_prefixes(chat_id)
        shop_type = await store.chat_shop_type(chat_id)
        admins = ", ".join([f"<code>{uid}</code>" for uid in perms.get("economy_admins", [])]) or "нет"
        credit = ", ".join([f"<code>{uid}</code>" for uid in perms.get("allow_credit", [])]) or "нет"
        debit = ", ".join([f"<code>{uid}</code>" for uid in perms.get("allow_debit", [])]) or "нет"
        chat_title = chat_id
        try:
            chat = await context.bot.get_chat(chat_id)
            chat_title = chat.title or chat_id
        except Exception:
            pass
        summary = (
            f"<b>Настройки для</b> {chat_title}\n"
            f"• Валюта: {currency.get('icon')} <code>{currency.get('name')}</code>\n"
            f"• Курс: <code>{currency.get('rate')}</code>\n"
            f"• Дневной бонус: <code>{format_currency(currency.get('daily_reward', 0), currency)}</code>\n"
            f"• Магазин: <code>{'обычный' if shop_type == 'normal' else 'фиксированный'}</code>\n"
            f"• Налог: <code>{currency.get('tax_rate', 0) / 100:.2f}%</code>\n"
            f"• Автосклонение: <code>{'включено' if currency.get('auto_declension', True) else 'выключено'}</code>\n"
            f"• Префиксы: <code>{' | '.join(prefixes)}</code>\n"
            f"• Блокировка: <code>{'включена' if currency.get('blocked') else 'выключена'}</code>\n"
            f"• Свободный режим: <code>{'включен' if free_mode else 'выключен'}</code>\n"
            f"<b>Права</b>\n"
            f"• Админы экономики: {admins}\n"
            f"• Начисление: {credit}\n"
            f"• Изъятие: {debit}"
        )
        keyboard = self.settings_keyboard(
            chat_id,
            blocked=bool(currency.get("blocked")),
            free_mode=free_mode,
            show_admin_controls=show_admin_controls,
            allow_block=allow_block,
            show_rights=bool(self.settings.creator_id and user_id == self.settings.creator_id),
        )
        if message_id:
            await context.bot.edit_message_text(
                chat_id=user_id,
                message_id=message_id,
                text=summary,
                reply_markup=keyboard,
                parse_mode=ParseMode.HTML,
            )
        else:
            await context.bot.send_message(
                user_id,
                summary,
                reply_markup=keyboard,
                parse_mode=ParseMode.HTML,
            )

    # Additional handlers and helpers continue below

    async def handle_settings_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        query = update.callback_query
        self._remember_thread(update)
        if not query:
            return
        if await self._should_skip_update(update):
            return
        await self._mark_update_processed(update)
        if not await self._ensure_private_subscription(update, context):
            return
        await query.answer()
        data = query.data.split(":")
        if len(data) < 3:
            return
        action = data[1]
        chat_id = int(data[2])
        user_id = query.from_user.id
        is_creator = self.ensure_creator(update)
        if action == "searchprompt":
            if not is_creator:
                return
            prompt = await query.edit_message_text("Введи chat_id для поиска настроек.")
            self.pending_actions[user_id] = {"chat_id": 0, "action": "searchid", "prompt_id": prompt.message_id}
            return

        store = self.ensure_storage()
        chat_owner = await store.chat_owner(chat_id)
        is_owner = chat_owner == user_id
        if chat_owner is None:
            await store.set_chat_owner(chat_id, user_id)
            chat_owner = user_id
            is_owner = True
        owner_plan = {"plan": PLAN_BASIC}
        if chat_owner:
            if is_creator:
                owner_plan = {"plan": PLAN_ULTIMATE}
            else:
                owner_plan = await store.ensure_plan(chat_owner)
        if not (is_creator or is_owner):
            await query.edit_message_text("Доступ запрещен.")
            return

        if action == "open":
            await self.send_settings_panel(
                user_id,
                chat_id,
                context,
                message_id=query.message.message_id,
                show_admin_controls=is_creator or is_owner,
                allow_block=is_creator,
            )
            return

        if action == "block":
            if not is_creator:
                await query.edit_message_text("Доступ запрещен.")
                return
            blocked_now = await store.is_blocked(chat_id)
            await store.set_blocked(chat_id, not blocked_now)
            await store.log_event(chat_id, f"Бот {'разблокирован' if blocked_now else 'заблокирован'} через настройки")
            await self.send_settings_panel(
                user_id,
                chat_id,
                context,
                message_id=query.message.message_id,
                show_admin_controls=is_creator or is_owner,
                allow_block=True,
            )
            return
        if action == "freemode":
            is_enabled = await store.is_free_mode(chat_id)
            status = "включён" if is_enabled else "выключен"
            text = (
                "<u>Свободный режим:</u> при включении этого режима администраторы экономики "
                "<b>смогут зачислять и устанавливать деньги на балансы других пользователей</b>.\n\n"
                "<u>⚠️Внимание:</u> при включении этого режима основная суть экономики может быть утеряна!\n"
                f"Текущий статус: <b>{status}</b>."
            )
            buttons = InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(
                            "Выключить" if is_enabled else "Включить",
                            callback_data=f"settings:freemodetoggle:{chat_id}",
                        )
                    ],
                    [InlineKeyboardButton("Назад", callback_data=f"settings:open:{chat_id}")],
                ]
            )
            await query.edit_message_text(text, reply_markup=buttons, parse_mode=ParseMode.HTML)
            return
        if action == "freemodetoggle":
            new_state = not await store.is_free_mode(chat_id)
            await store.set_free_mode(chat_id, new_state)
            await store.log_event(
                chat_id,
                f"Свободный режим {'включён' if new_state else 'выключен'} через настройки",
            )
            await self.send_settings_panel(
                user_id,
                chat_id,
                context,
                message_id=query.message.message_id,
                show_admin_controls=is_creator or is_owner,
                allow_block=is_creator,
            )
            return
        if action == "shop":
            text = (
                "Выберете тип магазина:\n"
                "<u>Фиксированный</u>: вид товаров и услуг, <b>не</b> подлежащие редактированию.\n"
                "<u>Обычный</u>: вид товаров и услуг, подлежащие редактированию пользователями."
            )
            buttons = InlineKeyboardMarkup(
                [
                    [InlineKeyboardButton("Фиксированный", callback_data=f"settings:shopset:{chat_id}:fixed")],
                    [InlineKeyboardButton("Обычный", callback_data=f"settings:shopset:{chat_id}:normal")],
                    [InlineKeyboardButton("Назад", callback_data=f"settings:open:{chat_id}")],
                ]
            )
            await query.edit_message_text(text, reply_markup=buttons, parse_mode=ParseMode.HTML)
            return
        if action == "shopset" and len(data) >= 4:
            mode = data[3]
            await store.set_shop_type(chat_id, mode)
            await store.log_event(chat_id, f"Тип магазина изменён на {mode}")
            await self.send_settings_panel(
                user_id,
                chat_id,
                context,
                message_id=query.message.message_id,
                show_admin_controls=is_creator or is_owner,
                allow_block=is_creator,
            )
            return
        if action == "delete":
            if not (is_creator or is_owner):
                await query.edit_message_text("Доступ запрещен.")
                return
            buttons = [
                [InlineKeyboardButton("Да", callback_data=f"settings:deleteyes:{chat_id}")],
                [InlineKeyboardButton("Нет", callback_data=f"settings:open:{chat_id}")],
            ]
            await query.edit_message_text(
                "Удалить группу из базы и покинуть её?",
                reply_markup=InlineKeyboardMarkup(buttons),
            )
            return
        if action == "deleteyes":
            if not (is_creator or is_owner):
                await query.edit_message_text("Доступ запрещен.")
                return
            await store.delete_chat(chat_id)
            try:
                await context.bot.leave_chat(chat_id)
            except Exception:
                pass
            await query.edit_message_text("Группа удалена, бот вышел из чата.")
            return
        if action == "rights" and not is_creator:
            await query.edit_message_text("Доступ запрещен.")
            return
        self.pending_actions[user_id] = {
            "chat_id": chat_id,
            "action": action,
            "prompt_id": query.message.message_id,
        }
        prompts = {
            "name": "Отправь новое название валюты (например: тублик).",
            "icon": "Отправь один символ или эмодзи для иконки валюты.",
            "rate": "Отправь числовой курс валюты относительно базового значения.",
            "daily": "Отправь размер ежедневного бонуса (число).",
            "tax": "Отправь налог магазина в процентах (число от 0 до 100).",
            "cases": "Пришли три формы через запятую: именительный, родительный, родительный множественного (пример: тублик, тублика, тубликов).",
            "auto": "Переключаю автосклонение прямо сейчас.",
            "prefix": "Отправь список префиксов столбиком (например: !!\n!\nec.).",
            "rights": "Пришли список user_id через запятую в формате: admin=1 2, credit=3 4, debit=5 6.",
        }

        if action == "auto":
            currency = await store.chat_currency(chat_id)
            toggled = not currency.get("auto_declension", True)
            await store.set_auto_declension(chat_id, toggled)
            await query.edit_message_text(
                f"Автосклонение {'включено' if toggled else 'выключено'}.",
                reply_markup=self.settings_keyboard(
                    chat_id,
                    blocked=bool(currency.get("blocked")),
                    free_mode=bool(currency.get("free_mode")),
                    show_admin_controls=is_creator or is_owner,
                    show_rights=is_creator,
                ),
            )
            await store.log_event(chat_id, f"Автосклонение {'включено' if toggled else 'выключено'}")
            return
        await query.edit_message_text(
            prompts.get(action, ""),
            reply_markup=self.settings_keyboard(
                chat_id,
                blocked=await store.is_blocked(chat_id),
                free_mode=await store.is_free_mode(chat_id),
                show_admin_controls=is_creator or is_owner,
                show_rights=is_creator,
            ),
        )

    async def handle_shop_router(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        query = update.callback_query
        self._remember_thread(update)
        if not query or not query.data:
            return
        if await self._should_skip_update(update):
            return
        await self._mark_update_processed(update)
        if not await self._ensure_private_subscription(update, context):
            return
        parts = query.data.split(":")
        if len(parts) < 3:
            return
        try:
            chat_id = int(parts[2])
        except ValueError:
            return
        shop_type = await self.ensure_storage().chat_shop_type(chat_id)
        if shop_type == "normal":
            await self.normal_shop.handle_shop_callback(update, context)
        else:
            await self.shop.handle_shop_callback(update, context)

    async def handle_upgrade_shop_router(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        query = update.callback_query
        if not query or not query.data:
            return
        if await self._should_skip_update(update):
            return
        await self._mark_update_processed(update)
        if not await self._ensure_private_subscription(update, context):
            return
        parts = query.data.split(":")
        if len(parts) < 3:
            return
        try:
            chat_id = int(parts[2])
        except ValueError:
            return
        shop_type = await self.ensure_storage().chat_shop_type(chat_id)
        if shop_type != "normal":
            await query.answer("Прокачка доступна только при обычном магазине.", show_alert=True)
            return
        await self.shop.handle_upgrade_callback(update, context)

    async def handle_shop_settings_router(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        query = update.callback_query
        self._remember_thread(update)
        if not query or not query.data:
            return
        if await self._should_skip_update(update):
            return
        await self._mark_update_processed(update)
        if not await self._ensure_private_subscription(update, context):
            return
        parts = query.data.split(":")
        if len(parts) < 3:
            return
        try:
            chat_id = int(parts[2])
        except ValueError:
            return
        shop_type = await self.ensure_storage().chat_shop_type(chat_id)
        if shop_type == "normal":
            await self.normal_shop.handle_shop_settings_callback(update, context)
        else:
            await query.answer("Недоступно для фиксированного магазина", show_alert=True)

    async def handle_purchases_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        self._remember_thread(update)
        if await self._should_skip_update(update):
            return
        await self._mark_update_processed(update)
        if not await self._ensure_private_subscription(update, context):
            return
        await self.shop.handle_purchases_callback(update, context)

    async def handle_shop_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        query = update.callback_query
        self._remember_thread(update)
        if not query:
            return
        if update.effective_chat and update.effective_chat.type != "private":
            if not self._is_group_unlocked(update.effective_chat.id):
                return
        if await self._should_skip_update(update):
            return
        await self._mark_update_processed(update)
        if not await self._ensure_private_subscription(update, context):
            return
        await query.answer()
        parts = query.data.split(":")
        if len(parts) < 3:
            return
        action = parts[1]
        chat_id = int(parts[2])
        page = int(parts[3]) if len(parts) > 3 else 0
        index = int(parts[4]) if len(parts) > 4 else None
        session_key = None
        if query.message:
            session_key = f"{query.message.chat_id}:{query.message.message_id}"
        store = self.ensure_storage()
        # Блокировка чата - любой не‑создатель получает ошибку и выход
        if await store.is_blocked(chat_id) and not self.ensure_creator(update):
            await query.answer("Ваша группа неожиданно разорвала соединение с ботом. Код ошибки: POSHEL_NAHUY", show_alert=True)
            return
        if await store.is_banned(chat_id, query.from_user.id):
            await query.answer("Команда не распознана. Попробуй !!poshel naxui", show_alert=True)
            return
        currency = await store.chat_currency(chat_id)
        items = await store.list_shop_items(chat_id)
        total_pages = max(1, (len(items) + self.SHOP_PAGE_SIZE - 1) // self.SHOP_PAGE_SIZE)
        page = max(0, min(page, total_pages - 1))
        keyboard = self.build_shop_keyboard(chat_id, items, currency.get("icon", "💰"), page=page)
        if action == "open":
            if session_key:
                self.shop_sessions.pop(session_key, None)
            text = self.render_shop_menu_text() if items else "Магазин пуст. Добавьте товары командой !!товар добавить ..."
            await query.edit_message_text(text, reply_markup=keyboard, parse_mode=ParseMode.HTML)
            return
        if action == "view" and index:
            if not items or index < 1 or index > len(items):
                await query.edit_message_text("Товар не найден.")
                return
            _, title, price, _, author_username, quantity = items[index - 1]
            await query.edit_message_text(
                self.render_item_text(title, price, currency, author_username, quantity),
                reply_markup=InlineKeyboardMarkup(
                    [
                        [InlineKeyboardButton("Приобрести", callback_data=f"shop:confirm:{chat_id}:{page}:{index}")],
                        [InlineKeyboardButton("Назад", callback_data=f"shop:open:{chat_id}:{page}")],
                    ]
                ),
                parse_mode=ParseMode.HTML,
            )
            return
        if action == "confirm" and index:
            if session_key:
                if self.shop_sessions.get(session_key) == query.data:
                    await query.answer("Покупка уже обработана", show_alert=True)
                    return
                self.shop_sessions[session_key] = query.data
            buyer = query.from_user
            buyer_name = buyer.username or buyer.full_name
            tax_rate = max(0, min(10000, int(currency.get("tax_rate", 500))))
            idem_key = f"shop:{chat_id}:{query.message.message_id}:{buyer.id}:{index}"
            try:
                result = await store.purchase_shop_item(
                    chat_id=chat_id,
                    index=index,
                    buyer_id=buyer.id,
                    buyer_username=buyer_name,
                    tax_rate=tax_rate,
                    idempotency_key=idem_key,
                    metadata={"message_id": query.message.message_id},
                )
            except ValueError:
                await query.edit_message_text(
                    "Недостаточно средств для покупки.",
                    reply_markup=InlineKeyboardMarkup(
                        [[InlineKeyboardButton("Назад", callback_data=f"shop:open:{chat_id}:{page}")]]
                    ),
                )
                return
            if result is None:
                await query.edit_message_text("Покупка уже обработана.")
                return
            title = result["title"]
            price_value = result["price"]
            seller_gain = result["seller_gain"]
            await store.log_event(
                chat_id,
                f"Пользователь {self.log_handle(buyer)} купил '{title}' за {format_currency(price_value, currency)} (налог {tax_rate / 100:.2f}%): продавцу зачтено {format_currency(seller_gain, currency)}",
            )
            await query.edit_message_text(
                f"<b>Транзакция завершена!</b> Ты купил <b>{title}</b> за {format_currency(price_value, currency)}."
                f" Баланс: {format_currency(result['new_balance'], currency)}",
                reply_markup=InlineKeyboardMarkup(
                    [[InlineKeyboardButton("Назад", callback_data=f"shop:open:{chat_id}:{page}")]]
                ),
                parse_mode=ParseMode.HTML,
            )
            return

    async def _handle_private_message_impl(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if update.effective_chat.type != "private":
            return
        user_id = update.effective_user.id
        store = self.ensure_storage()
        if user_id in self.pending_broadcasts:
            payload = self.pending_broadcasts[user_id]
            prompt_id = payload.get("prompt_id")
            if not update.message.reply_to_message or update.message.reply_to_message.message_id != prompt_id:
                await update.message.reply_text("Ответьте на сообщение-приглашение, чтобы отправить рассылку.")
                return
            text_value = (update.message.text or update.message.caption or "").strip()
            doc_text: str | None = None
            doc_parse_mode: ParseMode | None = None
            if update.message.document:
                doc = update.message.document
                lowered_name = (doc.file_name or "").lower()
                if lowered_name.endswith((".md", ".txt", ".html")):
                    file = await context.bot.get_file(doc.file_id)
                    data = await file.download_as_bytearray()
                    doc_text = data.decode("utf-8", errors="ignore")
                    if lowered_name.endswith(".md"):
                        doc_parse_mode = ParseMode.MARKDOWN
                    elif lowered_name.endswith(".html"):
                        doc_parse_mode = ParseMode.HTML
            if doc_text:
                text_value = doc_text.strip()
            media: dict[str, str] | None = None
            if update.message.photo:
                media = {"type": "photo", "file_id": update.message.photo[-1].file_id}
            elif update.message.document and (update.message.document.mime_type or "").startswith("image/"):
                media = {"type": "document", "file_id": update.message.document.file_id}
            if not text_value and not media:
                await update.message.reply_text("Нужно текстовое сообщение, .md/.html файл или изображение для отправки.")
                return
            scope = payload.get("scope")
            is_poll = False
            question: str | None = None
            options: list[str] = []
            raw_text = text_value
            parse_mode: ParseMode | None = doc_parse_mode or ParseMode.HTML
            lowered = text_value.lower()
            if lowered.startswith("html:"):
                text_value = text_value[5:].lstrip()
                parse_mode = ParseMode.HTML
            elif lowered.startswith("md:"):
                text_value = text_value[3:].lstrip()
                parse_mode = ParseMode.MARKDOWN
            elif not doc_parse_mode and "<" in text_value and ">" in text_value:
                parse_mode = ParseMode.HTML
            if text_value.lower().startswith("poll(") and text_value.endswith(")"):
                import re

                inner = text_value[len("poll(") : -1]
                quoted = re.findall(r"[\"\“\”]([^\"\“\”]+)[\"\“\”]", inner)
                if len(quoted) >= 2:
                    question, *options = quoted
                    is_poll = True
            poll_messages: list[tuple[int, int]] = []

            async def send_payload(chat_id: int) -> None:
                try:
                    if is_poll and question and options:
                        msg = await context.bot.send_poll(chat_id, question, options)
                        poll_messages.append((chat_id, msg.message_id))
                    else:
                        try:
                            if media and media.get("type") == "photo":
                                await context.bot.send_photo(
                                    chat_id,
                                    media["file_id"],
                                    caption=text_value or None,
                                    parse_mode=parse_mode if text_value else None,
                                )
                            elif media and media.get("type") == "document":
                                await context.bot.send_document(
                                    chat_id,
                                    media["file_id"],
                                    caption=text_value or None,
                                    parse_mode=parse_mode if text_value else None,
                                )
                            else:
                                await context.bot.send_message(chat_id, text_value, parse_mode=parse_mode)
                        except BadRequest:
                            fallback_mode = None if parse_mode == ParseMode.MARKDOWN else ParseMode.MARKDOWN
                            try:
                                if media and media.get("type") == "photo":
                                    await context.bot.send_photo(
                                        chat_id,
                                        media["file_id"],
                                        caption=text_value or None,
                                        parse_mode=fallback_mode if text_value else None,
                                    )
                                elif media and media.get("type") == "document":
                                    await context.bot.send_document(
                                        chat_id,
                                        media["file_id"],
                                        caption=text_value or None,
                                        parse_mode=fallback_mode if text_value else None,
                                    )
                                else:
                                    await context.bot.send_message(chat_id, text_value, parse_mode=fallback_mode)
                            except BadRequest:
                                if media and media.get("type") == "photo":
                                    await context.bot.send_photo(chat_id, media["file_id"], caption=raw_text or None)
                                elif media and media.get("type") == "document":
                                    await context.bot.send_document(chat_id, media["file_id"], caption=raw_text or None)
                                else:
                                    await context.bot.send_message(chat_id, raw_text)
                except Exception:
                    logger.warning("Не удалось отправить сообщение в чат %s", chat_id)

            if scope == "all":
                if self.ensure_creator(update):
                    chat_ids = await store.list_chats()
                else:
                    chat_ids = await store.chats_by_owner(user_id)
                for cid in chat_ids:
                    if self.news_channel_id and cid == self.news_channel_id:
                        continue
                    await send_payload(cid)
            elif scope == "chat":
                chat_id = payload.get("chat_id")
                if chat_id:
                    await send_payload(chat_id)
            if is_poll and poll_messages:
                self.active_polls[user_id] = poll_messages
                await update.message.reply_text(
                    "Опрос создан и отправлен в группы.",
                    reply_markup=InlineKeyboardMarkup(
                        [[InlineKeyboardButton("Закрыть опрос", callback_data=f"poll:close:{user_id}")]]
                    ),
                )
            else:
                await update.message.reply_text("Сообщение отправлено.")
            self.pending_broadcasts.pop(user_id, None)
            return
        pending = await store.get_pending_transfer(user_id)
        if pending:
            prompt_id = pending.get("prompt_id")
            if prompt_id and (
                not update.message.reply_to_message
                or update.message.reply_to_message.message_id != prompt_id
            ):
                await update.message.reply_text("Ответьте на сообщение с кнопкой «Я оплатил ✅», чтобы прикрепить квитанцию.")
                return
            if pending.get("file_id"):
                await update.message.reply_text("Квитанция уже получена. Ожидайте проверки.")
                return
            plan_code = pending.get("plan")
            amount = pending.get("amount")
            file_id, _ = self.transactions.extract_receipt(update.message)
            if not file_id:
                await update.message.reply_text("Нужно изображение квитанции (фото/скрин). Пришлите его ответом на приглашение.")
                return
            await store.set_pending_transfer(
                user_id,
                plan_code,
                amount,
                pending.get("method", "transfer"),
                file_id=file_id,
                prompt_id=prompt_id,
                ttl_seconds=3600,
            )
            self.transactions.cancel_receipt_timeout(user_id, plan_code)
            forwarded = await self.transactions.forward_receipt(update.message, plan_code, amount, user_id, context)
            if forwarded:
                await update.message.reply_text("📸 Фото отправлено на проверку!")
            else:
                await update.message.reply_text("⚠️ Не удалось отправить на проверку. Попробуйте ещё раз позже.")
            return
        if user_id in self.pending_promos:
            payload = self.pending_promos[user_id]
            prompt_id = payload.get("prompt_id")
            if not update.message.reply_to_message or update.message.reply_to_message.message_id != prompt_id:
                await update.message.reply_text("Пожалуйста, ответьте на приглашение, чтобы применить промокод.")
                return
            code = (update.message.text or "").strip()
            if not code:
                await update.message.reply_text("Нужен текстовый промокод.")
                return
            from pathlib import Path

            promo_path = Path("economy/promo_codes.json")
            try:
                data = json.loads(promo_path.read_text(encoding="utf-8")) if promo_path.exists() else {}
            except Exception:
                data = {}
            lookup_entry = data.get(code) or data.get(code.upper()) or data.get(code.lower())
            if not lookup_entry:
                await update.message.reply_text("Промокод не найден.")
                self.pending_promos.pop(user_id, None)
                return
            plan_map = {
                "ultimate": PLAN_ULTIMATE,
                "ultimatum": PLAN_ULTIMATE,
                "ultime": PLAN_ULTIMATE,
                "medium": PLAN_MEDIUM,
                "med": PLAN_MEDIUM,
                "basic": PLAN_BASIC,
            }
            plan_code = PLAN_BASIC
            months = 1
            weeks = 0
            days = 0
            code_key = str(code).strip()
            if isinstance(lookup_entry, dict):
                plan_code = plan_map.get(str(lookup_entry.get("plan", "basic")).lower(), PLAN_BASIC)
                months = int(lookup_entry.get("months", 0) or 0)
                weeks = int(lookup_entry.get("weeks", 0) or 0)
                days = int(lookup_entry.get("days", 0) or 0)
                code_key = str(lookup_entry.get("code") or code_key)
            else:
                lookup_str = str(lookup_entry or "")
                parts = lookup_str.replace("_", "-").split("-") if lookup_str else []
                plan_code = plan_map.get(parts[0].lower(), PLAN_BASIC) if parts else PLAN_BASIC
                for token in parts:
                    if token.isdigit():
                        months = int(token)
                        break
            if months == weeks == days == 0 and plan_code != PLAN_BASIC:
                months = 1
            store = self.ensure_storage()
            if await store.promo_redeemed(user_id, code_key):
                await update.message.reply_text("Этот промокод уже был использован." )
                self.pending_promos.pop(user_id, None)
                return
            current_plan = (await store.ensure_plan(user_id)).get("plan", PLAN_BASIC)
            if self.PLAN_RANK.get(current_plan, 0) > self.PLAN_RANK.get(plan_code, 0):
                await update.message.reply_text("У Вас уже активен более высокий план.")
                self.pending_promos.pop(user_id, None)
                return
            info = await store.set_user_plan(user_id, plan_code, months, weeks=weeks, days=days)
            await store.mark_promo_redeemed(user_id, code_key)
            status = self._plan_label(info)
            await update.message.reply_text(f"Промокод применён. Новый план: {status}")
            self.pending_promos.pop(user_id, None)
            return
        if user_id not in self.pending_actions:
            return
        payload = self.pending_actions.pop(user_id)
        chat_id = payload.get("chat_id")
        action = payload.get("action")
        prompt_id = payload.get("prompt_id")
        text = (update.message.text or "").strip()
        if action == "poker_raise":
            if not self.casino:
                return
            session_id = payload.get("session_id")
            session = self.casino.poker_tables.get(session_id)
            if not session or session.get("status") != "active":
                await update.message.reply_text("Игра уже завершена.")
                return
            pending = session.get("pending_raises", {}).get(user_id, {})
            if prompt_id and (
                not update.message.reply_to_message
                or update.message.reply_to_message.message_id != prompt_id
            ):
                await update.message.reply_text("Ответь на сообщение бота, чтобы повысить ставку.")
                self.pending_actions[user_id] = payload
                return
            amount_value, is_all = self.parse_amount_token(update.message.text or "")
            min_raise = payload.get("min_raise") or session.get("bet", self.casino.MIN_BET)
            if is_all:
                balance_left = await self.ensure_storage().get_balance(session["chat_id"], user_id)
                amount = max(min_raise, balance_left + session.get("round_bets", {}).get(user_id, 0))
            else:
                amount = amount_value
            if amount is None or amount < min_raise:
                await update.message.reply_text(
                    f"Минимальное повышение: {self.casino.format_currency(min_raise, session['currency'])}"
                )
                self.pending_actions[user_id] = payload
                return
            session.setdefault("decisions", {})[user_id] = ("raise", amount)
            waiter = pending.get("event") or session.get("waiters", {}).get(user_id)
            if waiter:
                waiter.set()
            session.get("pending_raises", {}).pop(user_id, None)
            confirmation = f"Ставка увеличена на {self.casino.format_currency(amount, session['currency'])}"
            prompt_to_edit = payload.get("prompt_id")
            if prompt_to_edit:
                await self._safe_edit_message(
                    context,
                    user_id,
                    prompt_to_edit,
                    confirmation,
                    markup=None,
                )
            else:
                await update.message.reply_text(confirmation)
            return
        if prompt_id and (
            not update.message.reply_to_message
            or update.message.reply_to_message.message_id != prompt_id
        ):
            await update.message.reply_text("Ответь на сообщение-приглашение, чтобы применить настройку.")
            return
        store = self.ensure_storage()
        if action == "name":
            await store.set_currency_name(chat_id, text)
            await update.message.reply_text(f"Название валюты обновлено на: {text}")
            await store.log_event(chat_id, f"Название валюты изменено на {text}")
        elif action == "icon":
            await store.set_currency_icon(chat_id, text[:2])
            await update.message.reply_text(f"Иконка обновлена: {text[:2]}")
            await store.log_event(chat_id, f"Иконка валюты изменена на {text[:2]}")
        elif action == "rate":
            if not text.isdigit():
                await update.message.reply_text("Нужно целое число. Попробуй снова.")
            else:
                value = int(text)
                await store.set_currency_rate(chat_id, value)
                await update.message.reply_text(f"Курс установлен: {value}")
                await store.log_event(chat_id, f"Курс валюты установлен на {value}")
        elif action == "daily":
            value = self.parse_amount(text)
            if value is None:
                await update.message.reply_text("Нужно число. Попробуй снова.")
            else:
                await store.set_daily_reward(chat_id, value)
                await update.message.reply_text(
                    f"Дневной бонус установлен: {format_currency(value, await store.chat_currency(chat_id))}"
                )
                await store.log_event(chat_id, f"Ежедневный бонус установлен на {value}")
        elif action == "prefix":
            prefixes = [line.strip() for line in text.splitlines() if line.strip()]
            await store.set_prefixes(chat_id, prefixes)
            await update.message.reply_text("Префиксы обновлены.")
        elif action == "tax":
            value = self.parse_percent(text)
            if value is None:
                await update.message.reply_text("Нужно число. Попробуй снова.")
            else:
                clamped = max(0, min(10000, value))
                await store.set_tax_rate(chat_id, clamped)
                await update.message.reply_text(f"Налог установлен: {clamped / 100:.2f}%")
                await store.log_event(chat_id, f"Налог магазина обновлён до {clamped}")
        elif action == "cases":
            parts = [p.strip() for p in text.split(",") if p.strip()]
            if len(parts) != 3:
                await update.message.reply_text("Нужно три формы через запятую: один, несколько, много.")
            else:
                await store.set_cases(chat_id, parts[0], parts[1], parts[2])
                await update.message.reply_text(f"Падежи сохранены: {', '.join(parts)}")
                await store.log_event(chat_id, f"Падежи валюты изменены: {', '.join(parts)}")
        elif action == "rights":
            perms = await store.permissions(chat_id)
            admin_ids = perms.get("economy_admins", [])
            credit_ids = perms.get("allow_credit", [])
            debit_ids = perms.get("allow_debit", [])
            owner_id = await store.chat_owner(chat_id)
            blocks = [part.strip() for part in text.split(",") if part.strip()]
            for block in blocks:
                if "=" not in block:
                    continue
                key, value = block.split("=", 1)
                ids = [int(part) for part in value.replace(",", " ").split() if part.isdigit()]
                if key.startswith("admin"):
                    admin_ids = ids
                elif key.startswith("credit"):
                    credit_ids = ids
                elif key.startswith("debit"):
                    debit_ids = ids
            if owner_id and owner_id not in admin_ids:
                admin_ids.append(owner_id)
            await store.update_permissions(chat_id, economy_admins=admin_ids, allow_credit=credit_ids, allow_debit=debit_ids)
            await update.message.reply_text("Права обновлены.")
            await store.log_event(chat_id, "Изменены права доступа участников.")
        elif action == "searchid":
            try:
                chat_lookup = int(text)
            except ValueError:
                await update.message.reply_text("Нужно число chat_id")
                return
            available = tuple(dict.fromkeys(await store.list_chats()))
            if chat_lookup not in available:
                await update.message.reply_text("Бот не состоит в этой группе.")
                return
            await self.send_settings_panel(
                user_id,
                chat_lookup,
                context,
                show_admin_controls=self.ensure_creator(update),
                allow_block=self.ensure_creator(update),
            )
            return
        await self.send_settings_panel(
            user_id,
            chat_id,
            context,
            show_admin_controls=self.ensure_creator(update),
            allow_block=self.ensure_creator(update),
        )

    async def handle_private_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if await self._should_skip_update(update):
            return
        await self._mark_update_processed(update)
        message = update.effective_message
        if message and update.effective_chat.type == "private":
            text = (message.text or "").strip()
            if text.startswith("/"):
                if not text.lower().startswith("/start"):
                    if not await self._is_subscribed(update.effective_user, context):
                        await self._ensure_subscription(update.effective_user, context, prompt_message=message)
                        return
            else:
                prefix, _ = self.normalize_command(text)
                if prefix and not await self._is_subscribed(update.effective_user, context):
                    await self._ensure_subscription(update.effective_user, context, prompt_message=message)
                    return
        await self.private_messages.handle(update, context)

    async def settings_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if update.effective_chat.type != "private":
            return
        if await self._should_skip_update(update):
            return
        await self._mark_update_processed(update)
        if update.effective_user and not await self._check_cooldown(update.effective_user.id, message=update.message):
            return
        if not await self._ensure_subscription(update.effective_user, context, prompt_message=update.message):
            return
        store = self.ensure_storage()
        is_creator = self.ensure_creator(update)
        if is_creator:
            chat_ids = await self._filter_active_chats(await store.list_chats(), context, keep_all=True)
        else:
            chat_ids = await self._filter_active_chats(
                await store.chats_by_owner(update.effective_user.id), context, keep_all=True
            )
        if not chat_ids:
            await update.message.reply_text("Нет доступных групп.")
            return
        rows = []
        if is_creator:
            rows.append([InlineKeyboardButton("Поиск", callback_data="settings:searchprompt:0")])
        for cid in chat_ids:
            if self.news_channel_id and cid == self.news_channel_id:
                continue
            title = None
            is_admin = False
            try:
                chat = await context.bot.get_chat(cid)
                if chat.type == "channel":
                    continue
                title = chat.title or chat.full_name
            except Exception:
                logger.debug("Не удалось получить данные чата %s", cid)
            try:
                member = await context.bot.get_chat_member(cid, self.bot_id)
                is_admin = member.status == "administrator"
            except Exception:
                logger.debug("Не удалось проверить права бота в чате %s", cid)

            if not is_admin:
                label = f"Н/Д ({cid})"
            else:
                label = title or f"Н/Д ({cid})"
            cb = f"settings:open:{cid}"
            rows.append([InlineKeyboardButton(label, callback_data=cb)])
        markup = InlineKeyboardMarkup(rows)
        await update.message.reply_text("Выбери группу для настроек:", reply_markup=markup)

    async def backup_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if update.effective_chat.type != "private":
            return
        if await self._should_skip_update(update):
            return
        await self._mark_update_processed(update)
        if update.effective_user and not await self._check_cooldown(update.effective_user.id, message=update.message):
            return
        if not await self._ensure_subscription(update.effective_user, context, prompt_message=update.message):
            return
        if not self.ensure_creator(update):
            await update.message.reply_text("Доступ запрещен")
            return
        sub = context.args[0].lower() if context.args else None
        store = self.ensure_storage()
        backups_dir = Path("backups")
        backups_dir.mkdir(parents=True, exist_ok=True)
        if sub == "save":
            data = await store.dump_all()
            existing = [
                int(p.stem.replace("backup", ""))
                for p in backups_dir.glob("backup*.json")
                if p.stem.replace("backup", "").isdigit()
            ]
            next_index = max(existing) + 1 if existing else 1
            path = backups_dir / f"backup{next_index}.json"
            path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
            await update.message.reply_document(
                document=path.open("rb"), filename=path.name, caption=f"Бэкап #{next_index} сохранён"
            )
            return
        if sub == "load":
            if len(context.args) < 2:
                await update.message.reply_text("Укажи индекс бэкапа: /backup load 1")
                return
            try:
                index = int(context.args[1])
            except ValueError:
                await update.message.reply_text("Индекс бэкапа должен быть числом.")
                return
            path = backups_dir / f"backup{index}.json"
            if not path.exists():
                await update.message.reply_text("Бэкап с таким индексом не найден.")
                return
            data = json.loads(path.read_text(encoding="utf-8"))
            await store.load_dump(data)
            await update.message.reply_text(f"Бэкап #{index} восстановлен")
            return
        await update.message.reply_text("Использование: /backup save или /backup load {index}")

    def _renew_keyboard(self) -> InlineKeyboardMarkup:
        return InlineKeyboardMarkup(
            [[InlineKeyboardButton("Продлить", callback_data="plans:method")]]
        )

    def _plans_entry_keyboard(self) -> InlineKeyboardMarkup:
        return InlineKeyboardMarkup(
            [[InlineKeyboardButton("Выбрать план", callback_data="plans:method")]]
        )

    def _plans_method_keyboard(self) -> InlineKeyboardMarkup:
        return InlineKeyboardMarkup(
            [
                [InlineKeyboardButton("Telegram Stars", callback_data="plans:method:stars")],
                [InlineKeyboardButton("Перевод (₽)", callback_data="plans:method:transfer")],
                [InlineKeyboardButton("Назад", callback_data="plans:root")],
            ]
        )

    def _plans_select_keyboard(self, method: str) -> InlineKeyboardMarkup:
        buttons: list[list[InlineKeyboardButton]] = []
        if method == "stars":
            medium = self.settings.plan_medium_stars
            ultimate = self.settings.plan_ultimate_stars
            buttons.append(
                [InlineKeyboardButton(f"Медиум - {medium}⭐", callback_data="plans:buy:stars:medium")]
            )
            buttons.append(
                [InlineKeyboardButton(f"Ультиматум - {ultimate}⭐", callback_data="plans:buy:stars:ultimate")]
            )
        else:
            medium = self.settings.plan_medium_rub
            ultimate = self.settings.plan_ultimate_rub
            buttons.append(
                [InlineKeyboardButton(f"Медиум - {medium}₽", callback_data="plans:buy:transfer:medium")]
            )
            buttons.append(
                [InlineKeyboardButton(f"Ультиматум - {ultimate}₽", callback_data="plans:buy:transfer:ultimate")]
            )
        buttons.append([InlineKeyboardButton("Назад", callback_data="plans:method")])
        return InlineKeyboardMarkup(buttons)

    async def plans_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if update.effective_chat.type != "private":
            return
        if await self._should_skip_update(update):
            return
        await self._mark_update_processed(update)
        if update.effective_user and not await self._check_cooldown(update.effective_user.id, message=update.message):
            return
        if not await self._ensure_subscription(update.effective_user, context, prompt_message=update.message):
            return
        store = self.ensure_storage()
        plan_info = await self._plan_for_user_with_reminder(update.effective_user, context)
        text = self._plans_text(plan_info)
        await update.message.reply_text(text, reply_markup=self._plans_entry_keyboard())

    async def info_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if update.effective_chat.type != "private":
            return
        if await self._should_skip_update(update):
            return
        await self._mark_update_processed(update)
        if update.effective_user and not await self._check_cooldown(update.effective_user.id, message=update.message):
            return
        if not self.ensure_creator(update):
            await update.message.reply_text("Доступ запрещен")
            return
        store = self.ensure_storage()
        now = int(time.time())
        week_start = now - 7 * 24 * 3600
        total_users = await store.count_known_users()
        weekly_users = await store.count_active_users_since(week_start)
        total_groups = await store.count_chats()
        premium_users = await store.count_premium_users()
        command_totals = await store.command_totals_since(0)
        text = (
            "<b>Статистика бота</b>\n"
            f"Активных за 7 дней: {weekly_users}\n"
            f"Пользователей всего: {total_users}\n"
            f"Всего групп: {total_groups}\n"
            f"Премиум-пользователей: {premium_users}\n"
            f"Команд выполнено: {command_totals.get('total', 0)}"
        )
        await update.message.reply_text(text, parse_mode=ParseMode.HTML)

    async def promo_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:

        if update.effective_chat.type != "private":
            return
        if await self._should_skip_update(update):
            return
        await self._mark_update_processed(update)
        if update.effective_user and not await self._check_cooldown(update.effective_user.id, message=update.message):
            return
        if not await self._ensure_subscription(update.effective_user, context, prompt_message=update.message):
            return
        prompt = await update.message.reply_text("Введи промокод ответом на это сообщение.")
        self.pending_promos[update.effective_user.id] = {"prompt_id": prompt.message_id}

    async def give_plan_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if update.effective_chat.type != "private":
            return
        if await self._should_skip_update(update):
            return
        await self._mark_update_processed(update)
        if update.effective_user and not await self._check_cooldown(update.effective_user.id, message=update.message):
            return
        if not await self._ensure_subscription(update.effective_user, context, prompt_message=update.message):
            return
        if not self.ensure_creator(update):
            await update.message.reply_text("Доступ запрещен")
            return
        if len(context.args) < 2:
            await update.message.reply_text("Использование: /give_plan @user plan duration(0|1d|1w|1m|1y)")
            return
        user_token = context.args[0]
        plan_token = context.args[1].lower()
        duration_token = context.args[2].lower() if len(context.args) > 2 else "0"
        target = await self._resolve_user_global(user_token, context)
        if not target:
            await update.message.reply_text("Пользователь не найден или не писал боту.")
            return
        target_id, target_name = target
        store = self.ensure_storage()
        if not await store.user_seen_anywhere(target_id):
            await update.message.reply_text("Пользователь ещё не взаимодействовал с ботом.")
            return
        plan_map = {
            "default": PLAN_BASIC,
            "basic": PLAN_BASIC,
            "medium": PLAN_MEDIUM,
            "med": PLAN_MEDIUM,
            "ultim": PLAN_ULTIMATE,
            "ultimate": PLAN_ULTIMATE,
            "ult": PLAN_ULTIMATE,
            "ultimatum": PLAN_ULTIMATE,
        }
        plan_code = plan_map.get(plan_token, PLAN_BASIC)
        months = 0
        weeks = 0
        days = 0
        if duration_token != "0":
            try:
                value = int(duration_token[:-1]) if duration_token[-1].isalpha() else int(duration_token)
                unit = duration_token[-1] if duration_token[-1].isalpha() else "m"
                if unit == "d":
                    days = value
                elif unit == "w":
                    weeks = value
                elif unit == "y":
                    months = value * 12
                else:
                    months = value
            except Exception:
                await update.message.reply_text("Неверный формат длительности. Пример: 1d, 1w, 1y, 0")
                return
        info = await store.set_user_plan(target_id, plan_code, months, weeks=weeks, days=days)
        await update.message.reply_text(
            f"План для {self.mention_id(target_id, target_name)} установлен: {self._plan_label(info)}"
        )

    async def handle_plans_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        query = update.callback_query
        self._remember_thread(update)
        if not query:
            return
        if await self._should_skip_update(update):
            return
        await self._mark_update_processed(update)
        if not await self._ensure_private_subscription(update, context):
            return
        await query.answer()
        parts = query.data.split(":")
        if len(parts) < 2:
            return
        action = parts[1]
        user_id = query.from_user.id
        store = self.ensure_storage()
        plan_info = await self._plan_for_user_with_reminder(query.from_user, context)
        current_plan = plan_info.get("plan", PLAN_BASIC)

        def plan_text() -> str:
            return self._plans_text(plan_info)

        if action == "root":
            await self._edit_query_message(query, plan_text(), reply_markup=self._plans_entry_keyboard())
            return

        if action == "method":
            # plans:method or plans:method:stars/transfer
            if len(parts) == 2:
                await self._edit_query_message(query, "Выберите способ оплаты", reply_markup=self._plans_method_keyboard())
                return
            method = parts[2]
            await self._edit_query_message(
                query,
                "Выберите план для оплаты",
                reply_markup=self._plans_select_keyboard(method),
            )
            return

        if action == "buy" and len(parts) >= 4:
            method = parts[2]
            plan_code = parts[3]
            expires_at = int(plan_info.get("expires_at", 0) or 0)
            now_ts = int(time.time())
            renewal_window = expires_at and (expires_at <= now_ts or expires_at - now_ts <= 3 * 24 * 3600)
            if self.PLAN_RANK.get(current_plan, 0) > self.PLAN_RANK.get(plan_code, 0) and not renewal_window:
                await self._edit_query_message(query, "У Вас уже активен более высокий план.")
                return
            if current_plan == plan_code and not renewal_window:
                await self._edit_query_message(query, "Выбранный вами план уже активирован.")
                return
            if method == "stars":
                if not self.settings.stars_provider_token:
                    await self._edit_query_message(query, "Оплата звёздами недоступна. Укажите STARS_PROVIDER_TOKEN в .env")
                    return
                price = (
                    self.settings.plan_medium_stars if plan_code == PLAN_MEDIUM else self.settings.plan_ultimate_stars
                )
                decimals = CURRENCY_DECIMAL_PLACES.get("XTR", 0)
                q = Decimal(10) ** decimals
                price_units = int((Decimal(str(price)) * q).to_integral_value())
                payload = f"plan:{plan_code}:1"
                title = "Покупка плана"
                description = "Ежемесячная подписка на бота"
                await context.bot.send_invoice(
                    user_id,
                    title=title,
                    description=description,
                    payload=payload,
                    provider_token=self.settings.stars_provider_token,
                    currency="XTR",
                    prices=[LabeledPrice("plan", price_units)],
                )
                await self._edit_query_message(query, "Счёт отправлен. Оплатите звёздами в появившемся окне.")
                return
            if method == "transfer":
                amount = (
                    self.settings.plan_medium_rub if plan_code == PLAN_MEDIUM else self.settings.plan_ultimate_rub
                )
                await store.set_pending_transfer(user_id, plan_code, amount, "transfer", ttl_seconds=1800)
                text = (
                    "🧾 <b>Запрос создан.</b>\n"
                    f"Переведите на этот счёт {amount}₽:\n"
                    f"Номер карты: <code>{html.escape(self.settings.card_number)}</code>\n"
                    f"Получатель: <code>{html.escape(self.settings.card_payee)}</code>\n\n"
                    "После оплаты прикрепите квитанцию ответом на это сообщение и нажмите «Я оплатил ✅»."
                )
                kb = InlineKeyboardMarkup(
                    [
                        [InlineKeyboardButton("Я оплатил ✅", callback_data=f"plans:payconfirm:{plan_code}")],
                        [InlineKeyboardButton("Назад", callback_data="plans:method:transfer")],
                    ]
                )
                await self._edit_query_message(query, text, reply_markup=kb)
                return

        if action == "payconfirm" and len(parts) >= 3:
            plan_code = parts[2]
            pending = await store.get_pending_transfer(user_id)
            if not pending or pending.get("plan") != plan_code:
                await query.answer("Нет активного платежа.", show_alert=True)
                return
            if pending.get("file_id"):
                await query.answer("Квитанция уже получена. Ожидайте проверки.", show_alert=True)
                return
            amount = pending.get("amount")
            note = await context.bot.send_message(
                chat_id=user_id,
                text=(
                    "📎 Прикрепите квитанцию об оплате ответом на это сообщение.\n"
                    "Если не отправите фото в течение 10 минут, запрос будет отменен."
                ),
            )
            await store.set_pending_transfer(
                user_id,
                plan_code,
                amount,
                pending.get("method", "transfer"),
                file_id=pending.get("file_id"),
                prompt_id=note.message_id,
                ttl_seconds=1200,
            )
            await self.transactions.schedule_receipt_timeout(context, user_id, plan_code, amount)
            await self._edit_query_message(query, "Ожидаем квитанцию. Пришлите фото ответом на сообщение ниже.")
            return

        if action in {"approve", "decline"} and len(parts) >= 4:
            if not self.ensure_creator(update):
                await query.answer("Доступ запрещен", show_alert=True)
                return
            target_id = int(parts[2])
            plan_code = parts[3]
            pending = await store.get_pending_transfer(target_id)
            if not pending or pending.get("plan") != plan_code:
                await query.answer("Нет активного платежа.", show_alert=True)
                return
            await store.clear_pending_transfer(target_id)
            self.transactions.cancel_receipt_timeout(target_id, plan_code)
            if action == "approve":
                info = await store.set_user_plan(target_id, plan_code, 1)
                try:
                    await context.bot.send_message(target_id, "✅ Платёж подтверждён! Подписка активирована.")
                except Exception:
                    logger.debug("Не удалось уведомить %s об одобрении платежа", target_id)
                await self._edit_query_message(query, "Платеж подтвержден", reply_markup=None)
            else:
                try:
                    await context.bot.send_message(target_id, "❌ Платёж отклонён. Попробуйте снова.")
                except Exception:
                    logger.debug("Не удалось уведомить %s об отклонении платежа", target_id)
                await self._edit_query_message(query, "Платеж отклонен", reply_markup=None)
            return

    async def precheckout_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        query = update.pre_checkout_query
        if not query:
            return
        if await self._should_skip_update(update):
            return
        await self._mark_update_processed(update)
        await query.answer(ok=True)

    async def successful_payment_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if await self._should_skip_update(update):
            return
        await self._mark_update_processed(update)
        await self.transactions.successful_payment_handler(update, context)

    async def poll_close_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        query = update.callback_query
        self._remember_thread(update)
        if not query:
            return
        if await self._should_skip_update(update):
            return
        await self._mark_update_processed(update)
        if not await self._ensure_private_subscription(update, context):
            return
        parts = query.data.split(":")
        if len(parts) != 3:
            return
        try:
            owner_id = int(parts[2])
        except ValueError:
            return
        if query.from_user.id != owner_id and not self.ensure_creator(update):
            await query.answer("Эта кнопка не для Вас", show_alert=True)
            return
        polls = self.active_polls.pop(owner_id, [])
        if not polls:
            await query.answer("Опрос уже закрыт", show_alert=True)
            return
        for chat_id, mid in polls:
            try:
                await context.bot.stop_poll(chat_id, mid)
            except Exception:
                logger.debug("Не удалось закрыть опрос %s:%s", chat_id, mid)
        try:
            await query.edit_message_text("Опрос закрыт.")
        except Exception:
            pass

    async def msg_all_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if update.effective_chat.type != "private":
            return
        if await self._should_skip_update(update):
            return
        await self._mark_update_processed(update)
        if update.effective_user and not await self._check_cooldown(update.effective_user.id, message=update.message):
            return
        if not await self._ensure_subscription(update.effective_user, context, prompt_message=update.message):
            return
        if not self.ensure_creator(update):
            await update.message.reply_text("Доступ запрещен")
            return
        prompt = await update.message.reply_text(
            "Ответь на приглашение текстом, прикрепи .md/.html или медиа — всё будет отправлено в группы с форматированием."
        )
        self.pending_broadcasts[update.effective_user.id] = {"scope": "all", "prompt_id": prompt.message_id}

    async def msg_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if update.effective_chat.type != "private":
            return
        if await self._should_skip_update(update):
            return
        await self._mark_update_processed(update)
        if update.effective_user and not await self._check_cooldown(update.effective_user.id, message=update.message):
            return
        if not await self._ensure_subscription(update.effective_user, context, prompt_message=update.message):
            return
        if not self.ensure_creator(update):
            await update.message.reply_text("Доступ запрещен")
            return
        store = self.ensure_storage()
        chat_ids = await store.list_chats()
        if not chat_ids:
            await update.message.reply_text("Нет групп для отправки сообщения.")
            return
        rows = []
        for cid in chat_ids:
            title = str(cid)
            try:
                chat = await context.bot.get_chat(cid)
                title = chat.title or chat.full_name or title
            except Exception:
                pass
            rows.append([InlineKeyboardButton(title, callback_data=f"broadcast:choose:{cid}")])
        await update.message.reply_text("Выбери группу для отправки:", reply_markup=InlineKeyboardMarkup(rows))

    async def handle_broadcast_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        query = update.callback_query
        self._remember_thread(update)
        if not query:
            return
        if await self._should_skip_update(update):
            return
        await self._mark_update_processed(update)
        if not await self._ensure_private_subscription(update, context):
            return
        await query.answer()
        if not self.ensure_creator(update):
            await query.edit_message_text("Доступ запрещен")
            return
        parts = query.data.split(":")
        if len(parts) < 3:
            return
        chat_id = int(parts[2])
        prompt = await query.message.reply_text(
            "Ответь на приглашение текстом, прикрепи .md/.html или медиа — всё будет отправлено с форматированием."
        )
        self.pending_broadcasts[query.from_user.id] = {"scope": "chat", "chat_id": chat_id, "prompt_id": prompt.message_id}

    def build_shop_keyboard(self, chat_id: int, items: tuple, currency_icon: str, page: int = 0) -> Optional[InlineKeyboardMarkup]:
        if not items:
            return None
        start = page * self.SHOP_PAGE_SIZE
        end = start + self.SHOP_PAGE_SIZE
        current = items[start:end]
        buttons = []
        for idx, (_, title, price, *_rest, quantity) in enumerate(current, start=start + 1):
            stock_label = "∞" if quantity == 0 else f"x{quantity}"
            buttons.append(
                [
                    InlineKeyboardButton(
                        f"[{idx}] {title}: {format_currency(price, {'icon': currency_icon})} ({stock_label})",
                        callback_data=f"shop:view:{chat_id}:{page}:{idx}",
                    )
                ]
            )
        nav_row = []
        total_pages = max(1, (len(items) + self.SHOP_PAGE_SIZE - 1) // self.SHOP_PAGE_SIZE)
        if page > 0:
            nav_row.append(InlineKeyboardButton("←", callback_data=f"shop:open:{chat_id}:{page-1}"))
        if page < total_pages - 1:
            nav_row.append(InlineKeyboardButton("→", callback_data=f"shop:open:{chat_id}:{page+1}"))
        if nav_row:
            buttons.append(nav_row)
        return InlineKeyboardMarkup(buttons)

    @staticmethod
    def render_shop_menu_text() -> str:
        return "Магазин. Выбери товар:"

    @staticmethod
    def render_item_text(title: str, price: float, currency, author_username: str | None, quantity: int) -> str:
        author_username = (author_username or "").lstrip("@")
        safe_author = html.escape(author_username)
        author = f"@{safe_author}" if author_username else "неизвестен"
        stock = "∞" if quantity == 0 else str(quantity)
        return (
            f"<b>{title}</b>\n"
            f"Цена: {format_currency(price, currency)}\n"
            f"Автор: {author}\n"
            f"В наличии: {stock}"
        )

    async def handle_job_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        query = update.callback_query
        self._remember_thread(update)
        if not query:
            return
        if update.effective_chat and update.effective_chat.type != "private":
            if not self._is_group_unlocked(update.effective_chat.id):
                return
        if await self._should_skip_update(update):
            return
        await self._mark_update_processed(update)
        await query.answer()
        parts = query.data.split(":")
        if len(parts) < 4:
            return
        action = parts[1]
        chat_id = int(parts[2])
        target_id = int(parts[3])
        store = self.ensure_storage()
        if query.from_user.id != target_id and not self.ensure_creator(update):
            await query.answer("Доступ запрещен", show_alert=True)
            return
        if await store.is_blocked(chat_id) and not self.ensure_creator(update):
            await query.answer(
                "Ваша группа неожиданно разорвала соединение с ботом. Код ошибки: POSHEL_NAHUY",
                show_alert=True,
            )
            return
        if await store.is_banned(chat_id, query.from_user.id):
            await query.answer("Команда не распознана. Попробуй !!poshel naxui", show_alert=True)
            return
        job_state = await store.get_job(chat_id, target_id)
        if job_state.get("job_blocked_until", 0) > time.time() and not self.ensure_creator(update):
            remaining = int(job_state["job_blocked_until"] - time.time())
            hrs = remaining // 3600
            mins = (remaining % 3600) // 60
            await query.answer(f"Рабочие команды заблокированы на {hrs}ч {mins}м", show_alert=True)
            return
        session = self.job_sessions.get(query.message.message_id, {}) if query.message else {}
        owner_id = session.get("user_id", target_id)
        if query.from_user.id != owner_id and not self.ensure_creator(update):
            await query.answer("Доступ запрещен", show_alert=True)
            return
        currency = await store.chat_currency(chat_id)

        if action == "teststart":
            await self.jobs.start_test(chat_id, target_id, query.message, use_edit=True)
            return
        if action == "testans" and len(parts) >= 6:
            idx = int(parts[4])
            option_index = int(parts[5]) if parts[5].lstrip("-+").isdigit() else -1
            await self.jobs.handle_test_answer_callback(query, chat_id, target_id, idx, option_index)
            return

        async def refresh():
            text = await self.jobs.work_info(chat_id, target_id, currency=currency)
            buttons = [
                [InlineKeyboardButton("Уволиться", callback_data=f"job:quitask:{chat_id}:{target_id}")],
                [InlineKeyboardButton("Счёт", callback_data=f"job:wallet:{chat_id}:{target_id}")],
            ]
            if currency.get("shop_type") == "normal":
                buttons.append([InlineKeyboardButton("Прокачка", callback_data=f"job:upgrade:{chat_id}:{target_id}")])
            kb = InlineKeyboardMarkup(buttons)
            await query.edit_message_text(text, reply_markup=kb)

        if action == "open":
            await refresh()
            return
        if action == "quitask":
            buttons = [
                [InlineKeyboardButton("Да", callback_data=f"job:quit:{chat_id}:{target_id}")],
                [InlineKeyboardButton("Нет", callback_data=f"job:open:{chat_id}:{target_id}")],
            ]
            await query.edit_message_text("Вы уверены, что хотите уволиться?", reply_markup=InlineKeyboardMarkup(buttons))
            return
        if action == "quit":
            outcome = await store.clear_job(chat_id, target_id, rating_drop=0.4)
            if outcome.get("penalty"):
                await query.edit_message_text(
                    "Слишком частые увольнения: рейтинг снижен на 1.0 и работа заблокирована на час.",
                    parse_mode=ParseMode.HTML,
                )
            else:
                await query.edit_message_text("Вы уволились. Рейтинг понижен.")
            return
        if action == "wallet":
            job = await store.get_job(chat_id, target_id)
            text = f"Ваш рабочий счёт: {format_currency(job.get('work_balance', 0), currency)}"
            buttons = [
                [InlineKeyboardButton("Вывести", callback_data=f"job:withdraw:{chat_id}:{target_id}")],
                [InlineKeyboardButton("Назад", callback_data=f"job:open:{chat_id}:{target_id}")],
            ]
            await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(buttons))
            return
        if action == "withdraw":
            job = await store.get_job(chat_id, target_id)
            amount = job.get("work_balance", 0)
            if amount <= 0:
                await query.answer("Счёт пуст", show_alert=True)
                return
            withdrawn = await store.withdraw_work_balance(chat_id, target_id, amount)
            await store.adjust_balance(chat_id, target_id, None, withdrawn, prevent_negative=False)
            await query.edit_message_text(
                f"Вывели {format_currency(withdrawn, currency)}.",
                reply_markup=InlineKeyboardMarkup(
                    [[InlineKeyboardButton("Назад", callback_data=f"job:open:{chat_id}:{target_id}")]]
                ),
            )
            return
        if action == "upgrade":
            plan_code = (await self._plan_for_chat(chat_id, context)).get("plan", PLAN_BASIC)
            items = self.shop.upgrade_items(plan_code)
            keyboard = self.shop.build_shop_keyboard(
                chat_id,
                items,
                currency.get("icon", "💰"),
                page=0,
                callback_prefix="upshop",
            )
            text = self.shop.render_upgrade_menu_text() if items else "Магазин прокачки пуст."
            await query.edit_message_text(
                text,
                reply_markup=keyboard,
                parse_mode=ParseMode.HTML,
            )
            return

    async def handle_casino_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        await self.casino.handle_callback(update, context)

    async def _resolve_username_to_user(
        self, chat_id: int, username: str, context: ContextTypes.DEFAULT_TYPE, store: MySQLEconomyStorage
    ) -> Optional[Tuple[int, str]]:
        username = username.strip().lstrip("@").strip(",.;:!?")
        if not username:
            return None
        if username.isdigit():
            return int(username), username
        try:
            chat = await context.bot.get_chat(f"@{username}")
            if chat and chat.id:
                return chat.id, chat.username or chat.full_name
        except Exception:
            pass
        rows = await store._execute(
            "SELECT user_id, COALESCE(username, user_id) FROM balances WHERE chat_id=%s AND LOWER(username)=LOWER(%s) LIMIT 1",
            (chat_id, username),
        )
        if rows:
            uid, uname = rows[0]
            return int(uid), str(uname)
        return None

    async def _resolve_user_global(self, token: str, context: ContextTypes.DEFAULT_TYPE) -> Optional[Tuple[int, str]]:
        token = token.strip()
        if not token:
            return None
        token = token.lstrip("@")
        store = self.ensure_storage()

        if token.isdigit():
            uid = int(token)
            ident = await store.user_identity(uid)
            if ident:
                return ident
            try:
                chat = await context.bot.get_chat(uid)
                return chat.id, chat.username or chat.full_name or str(chat.id)
            except Exception:
                pass

        ident = await store.find_user_by_username(token)
        if ident:
            return ident

        try:
            chat = await context.bot.get_chat(f"@{token}")
            return chat.id, chat.username or chat.full_name or str(chat.id)
        except Exception:
            return None

    async def resolve_target_from_message(
        self,
        message: Message,
        store: MySQLEconomyStorage,
        context: ContextTypes.DEFAULT_TYPE,
        explicit_username: Optional[str] = None,
        *,
        use_reply: bool = True,
    ) -> Optional[Tuple[int, str]]:
        if explicit_username:
            resolved = await self._resolve_username_to_user(message.chat_id, explicit_username, context, store)
            if resolved:
                return resolved
        if use_reply and message.reply_to_message and message.reply_to_message.from_user:
            u = message.reply_to_message.from_user
            return u.id, u.username or u.full_name
        entities = message.parse_entities(types=[MessageEntity.TEXT_MENTION, MessageEntity.MENTION])
        for entity, value in entities.items():
            if entity.type == MessageEntity.TEXT_MENTION and entity.user:
                return entity.user.id, entity.user.username or entity.user.full_name
            if entity.type == MessageEntity.MENTION:
                username = value.lstrip("@")
                resolved = await self._resolve_username_to_user(message.chat_id, username, context, store)
                if resolved:
                    return resolved
        parts = (message.text or "").split()
        if len(parts) >= 2:
            username_arg = parts[1].lstrip("@")
            resolved = await self._resolve_username_to_user(message.chat_id, username_arg, context, store)
            if resolved:
                return resolved
        return None

    async def has_admin_rights(self, user_id: int, _chat_admin_ids: Tuple[int, ...], chat_id: int) -> bool:
        perms = await self.ensure_storage().permissions(chat_id)
        return is_allowed(user_id, perms)

    async def handle_group_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        message = update.effective_message
        text = message.text or message.caption or ""
        self._remember_thread(update)
        if await self._should_skip_update(update):
            return
        await self._mark_update_processed(update)
        if message.from_user and message.from_user.is_bot:
            return
        if await self.jobs.handle_test_reply(update, context):
            return
        chat_id = message.chat_id
        store = self.ensure_storage()
        if self.test_mode and not self._is_group_unlocked(chat_id):
            if text.strip().lower() == "unlock 1917":
                user = update.effective_user
                is_creator = (user.username or "").lower() == self.settings.creator_username if user else False
                try:
                    admins = tuple(admin.user.id for admin in await context.bot.get_chat_administrators(chat_id))
                except Exception:
                    admins = tuple()
                if is_creator or (user and user.id in admins):
                    self.test_unlocked_chats.add(chat_id)
                    await message.reply_text("Тестовый режим: группа разблокирована.")
                else:
                    await message.reply_text("Доступ запрещен.")
            return
        # Auto-register speaking user to keep balances in sync
        if message.from_user and not message.from_user.is_bot:
            try:
                await store.register_user(
                    chat_id,
                    message.from_user.id,
                    message.from_user.username or message.from_user.full_name,
                )
            except Exception:
                logger.warning("Не удалось автоматически зарегистрировать пользователя %s", message.from_user.id)

        text_stripped = text.strip().lower()

        if text_stripped == "unban 1917":
            user = update.effective_user
            try:
                admins = tuple(admin.user.id for admin in await context.bot.get_chat_administrators(chat_id))
            except Exception:
                admins = tuple()
            is_creator = (user.username or "").lower() == self.settings.creator_username if user else False
            if user and (is_creator or user.id in admins):
                await store.clear_all_bans(chat_id)
                await store.clear_chat_cooldowns(chat_id)
                self.nuke_blocks = {k: v for k, v in self.nuke_blocks.items() if k[0] != chat_id}
                self.nuke_delete = {k: v for k, v in self.nuke_delete.items() if k[0] != chat_id}
                await store.log_event(
                    chat_id, f"{self.log_handle(user=user)} снял все ограничения через unban 1917"
                )
                await message.reply_text("Все ограничения для этой группы сняты.")
            else:
                await message.reply_text("Доступ запрещен.")
            return
        # Hidden admin-only unmute for post-nuke sanctions
        if text_stripped == "sudo unmute me":
            user = update.effective_user
            try:
                chat_admins = tuple(admin.user.id for admin in await context.bot.get_chat_administrators(chat_id))
            except Exception:
                chat_admins = tuple()
            perms = await store.permissions(chat_id)
            is_creator = (user.username or "").lower() == self.settings.creator_username if user else False
            is_econ_admin = user.id in perms.get("economy_admins", [])
            if is_creator or is_econ_admin or user.id in chat_admins:
                block_key = (chat_id, user.id)
                self.nuke_blocks.pop(block_key, None)
                self.nuke_delete.pop(block_key, None)
                try:
                    await context.bot.restrict_chat_member(
                        chat_id,
                        user.id,
                        permissions=ChatPermissions(
                            can_send_messages=True,
                            can_send_media_messages=True,
                            can_send_polls=True,
                            can_send_other_messages=True,
                            can_add_web_page_previews=True,
                        ),
                    )
                except Exception:
                    logger.debug("Не удалось снять мут с %s", user.id)
                await message.reply_text("Санкции сняты.")
                await store.log_event(chat_id, f"{self.log_handle(user=user)} снял санкции командой sudo unmute me")
            else:
                await message.reply_text("Доступ запрещен")
            return

        block_key = (chat_id, update.effective_user.id if update.effective_user else 0)
        block_until = self.nuke_blocks.get(block_key, 0)
        if block_until and block_until > time.time() and not self.ensure_creator(update):
            if self.nuke_delete.get(block_key):
                try:
                    await message.delete()
                except Exception:
                    pass
                return
            await message.reply_text(
                f"Вы под санкциями после ядерки до {time.strftime('%H:%M:%S', time.localtime(block_until))}.",
                parse_mode=ParseMode.HTML,
            )
            return
        if block_key in self.nuke_blocks and block_until <= time.time():
            self.nuke_blocks.pop(block_key, None)
            self.nuke_delete.pop(block_key, None)
        if message.reply_to_message and message.document:
            pending_escript = await store.get_pending_escript(message.reply_to_message.message_id)
            if pending_escript:
                user = update.effective_user
                if not user:
                    return
                perms = await store.permissions(chat_id)
                role = self.resolve_role(perms, user.id)
                if not (self.ensure_creator(update) or role == "admin"):
                    await message.reply_text("Доступ запрещен")
                    return
                if not message.document.file_name or not message.document.file_name.endswith(".escript"):
                    await message.reply_text("Нужен файл с расширением .escript")
                    return
                pending_name = pending_escript.get("name") or "Без названия"
                script_id = pending_escript.get("script_id") or 0
                progress_message = await message.reply_text(
                    "🟩⬜⬜⬜⬜⬜⬜⬜⬜⬜ 10%\nКомпиляция файла..."
                )
                file = await context.bot.get_file(message.document.file_id)
                raw = await file.download_as_bytearray()
                await asyncio.sleep(0.4)
                await progress_message.edit_text("🟩🟩🟩⬜⬜⬜⬜⬜⬜⬜ 30%\nКомпиляция файла...")
                data, errors, warnings, log_text = await self._compile_escript_payload(
                    chat_id=chat_id,
                    script_id=script_id or 1,
                    script_name=pending_name,
                    raw_data=raw,
                    author=user,
                )
                await asyncio.sleep(0.4)
                await progress_message.edit_text("🟩🟩🟩🟩🟩🟩⬜⬜⬜⬜ 60%\nКомпиляция файла...")
                await asyncio.sleep(0.4)
                await progress_message.edit_text("🟩🟩🟩🟩🟩🟩🟩🟩🟩🟩 100%\nКомпиляция файла...")
                log_key = self._escript_log_key(chat_id, user.id, script_id or 0)
                log_path = self.escripts.log_path(chat_id, script_id or int(time.time()))
                log_path.write_text(log_text, encoding="utf-8")
                self.escript_log_cache[log_key] = str(log_path)
                if errors:
                    await store.clear_pending_escript(message.reply_to_message.message_id)

                    log_button = (
                        InlineKeyboardButton("Получить лог", callback_data=f"escript:log:{log_key}")
                        if not script_id
                        else InlineKeyboardButton("Получить лог",
                                                  callback_data=f"escript:logfile:{chat_id}:{script_id}")
                    )

                    await message.reply_text(
                        "❌ <b>Скрипт не загружен.</b>\n"
                        f"Ошибки: <b>{len(errors)}</b>\n"
                        f"Предупреждения: <b>{len(warnings)}</b>",
                        reply_markup=InlineKeyboardMarkup([[log_button]]),
                        parse_mode=ParseMode.HTML,
                    )
                    return

                source_text = data.get("source", "") if isinstance(data, dict) else ""
                if script_id:
                    script_path = self.escripts.script_path(chat_id, script_id)
                    script_path.write_text(source_text, encoding="utf-8")
                    await store.update_escript_meta(
                        chat_id=chat_id,
                        script_id=script_id,
                        filename=str(script_path),
                        errors=0,
                        warnings=len(warnings),
                        log_path=str(log_path),
                        active=True,
                    )
                    await self.escripts.refresh_script(chat_id, script_id)
                else:
                    temp_path = self.escripts.script_path(chat_id, int(time.time()))
                    temp_path.write_text(source_text, encoding="utf-8")
                    new_id = await store.add_escript(
                        chat_id=chat_id,
                        name=pending_name,
                        filename=str(temp_path),
                        author_id=user.id,
                        author_username=user.username,
                        active=True,
                        errors=0,
                        warnings=len(warnings),
                        log_path=str(log_path),
                    )
                    final_path = self.escripts.script_path(chat_id, new_id)
                    try:
                        temp_path.rename(final_path)
                    except Exception:
                        final_path = temp_path
                    await store.update_escript_meta(
                        chat_id=chat_id,
                        script_id=new_id,
                        filename=str(final_path),
                        errors=0,
                        warnings=len(warnings),
                        log_path=str(log_path),
                        active=True,
                    )
                    script_id = new_id
                    await self.escripts.refresh_script(chat_id, new_id)
                await store.clear_pending_escript(message.reply_to_message.message_id)
                await message.reply_text(
                    "✅ <b>Скрипт успешно загружен и активирован.</b>\n"
                    "Ошибки: <b>0</b>\n"
                    f"Предупреждения: <b>{len(warnings)}</b>",
                    reply_markup=InlineKeyboardMarkup(
                        [[InlineKeyboardButton("Получить лог", callback_data=f"escript:logfile:{chat_id}:{script_id or 0}")]]
                    ),
                    parse_mode=ParseMode.HTML,
                )
                return
        if message.reply_to_message:
            pending = await store.get_pending_item_edit(message.reply_to_message.message_id)
            if pending and pending.get("chat_id") == chat_id:
                user = update.effective_user
                if not user:
                    return
                owner_id = pending.get("owner")
                if owner_id and user.id != owner_id and not self.ensure_creator(update):
                    await message.reply_text("Доступ запрещен")
                    return
                field = pending.get("field")
                index = pending.get("index")
                text_value = (message.text or message.caption or "").strip()
                if not text_value:
                    await message.reply_text("Нужно текстовое значение.")
                    return
                item = await store.get_shop_item_by_index(chat_id, index)
                if not item:
                    await message.reply_text("Товар не найден или был удалён.")
                    await store.clear_pending_item_edit(message.reply_to_message.message_id)
                    return
                if field == "title":
                    await store.update_shop_item(chat_id, index, title=text_value)
                    await message.reply_text(f"Название обновлено: {text_value}")
                    await store.log_event(chat_id, f"Название товара [{index}] изменено на '{text_value}'")
                elif field == "price":
                    value = self.validate_amount(self.parse_amount(text_value))
                    if value is None:
                        await message.reply_text(
                            f"Цена должна быть от {self.MIN_TRANSACTION} до {self.MAX_TRANSACTION}."
                        )
                        return
                    await store.update_shop_item(chat_id, index, price=value)
                    await message.reply_text(f"Цена обновлена: {format_currency(value, await store.chat_currency(chat_id))}")
                    await store.log_event(chat_id, f"Цена товара [{index}] изменена на {value}")
                elif field == "quantity":
                    if not text_value.isdigit():
                        await message.reply_text("Нужно число. Попробуй снова.")
                        return
                    quantity = int(text_value)
                    await store.update_shop_item(chat_id, index, quantity=quantity)
                    await message.reply_text(
                        f"Количество обновлено: {quantity if quantity else '∞'}"
                    )
                    await store.log_event(chat_id, f"Количество товара [{index}] изменено на {quantity}")
                else:
                    await message.reply_text("Неизвестное поле.")
                    await store.clear_pending_item_edit(message.reply_to_message.message_id)
                    return
                await store.clear_pending_item_edit(message.reply_to_message.message_id)
                return
        prefixes = await store.chat_prefixes(chat_id)
        prefix, payload = self.normalize_command(text, prefixes or self.COMMAND_PREFIXES)
        if not prefix:
            return
        user = update.effective_user
        if user and not await self._check_cooldown(user.id, message=message):
            return
        is_creator = (user.username or "").lower() == self.settings.creator_username if user else False
        parts = payload.split()
        if not parts:
            await message.reply_text(f"Команда не распознана. Напиши {prefix}помощь.", parse_mode=ParseMode.HTML)
            return
        command = parts[0].lower()
        self._record_thread_preference(chat_id, getattr(message, "message_thread_id", None))
        await store.record_command_usage(
            chat_id,
            update.effective_user.id if update.effective_user else None,
            timestamp=int(time.time()),
            date_key=self._date_key(),
        )
        args = parts[1:]
        if await store.is_blocked(chat_id) and not is_creator:
            await message.reply_text(
                "Ваша группа неожиданно разорвала соединение с ботом. Код ошибки: POSHEL_NAHUY",
                parse_mode=ParseMode.HTML,
            )
            return
        try:
            admins = tuple(admin.user.id for admin in await context.bot.get_chat_administrators(chat_id))
        except TimedOut:
            logger.warning("Не удалось получить список админов чата %s из-за таймаута", chat_id)
            admins = tuple()
        except Exception as exc:
            logger.error("Ошибка при получении админов %s: %s", chat_id, exc)
            admins = tuple()
        perms = await store.permissions(chat_id)
        currency = await store.chat_currency(chat_id)
        shop_type = await store.chat_shop_type(chat_id)
        role = self.resolve_role(perms, user.id)
        free_mode = bool(currency.get("free_mode"))
        plan_code = (await self._plan_for_chat(chat_id, context)).get("plan", PLAN_BASIC)

        if role == "banned":
            await message.reply_text(
                "Команда не распознана. Попробуй !!poshel naxui",
                parse_mode=ParseMode.HTML,
            )
            return

        async def reply(text: str, **kwargs) -> None:
            await message.reply_text(text, parse_mode=ParseMode.HTML, **kwargs)
            if user and self._should_skip_cooldown(text):
                await store.clear_cooldown(f"cmd:{user.id}")

        def require_plan(required: str) -> bool:
            if self._plan_allowed(plan_code, required):
                return True
            asyncio.create_task(reply("Ваш уровень доступа не соответствует уровню плана!"))
            return False

        if await self.escripts.handle_command(
            chat_id=chat_id,
            command=command,
            update=update,
            context=context,
            args=args,
            plan_code=plan_code,
            override_only=True,
        ):
            return

        if command == "скрипты":
            if not require_plan(PLAN_ULTIMATE):
                return
            sub = args[0].lower() if args else ""
            if sub == "добавить":
                if not (is_creator or role == "admin"):
                    await reply("Доступ запрещен")
                    return
                script_name = self._extract_quoted_name(text)
                if not script_name:
                    await reply(f"Используй {prefix}скрипты добавить \"Название\"")
                    return
                prompt = await message.reply_text("Загрузи файл .escript ответом на это сообщение.")
                await store.set_pending_escript(
                    prompt_id=prompt.message_id,
                    chat_id=chat_id,
                    user_id=user.id,
                    name=script_name,
                )
                return
            if sub == "настроить":
                if not (is_creator or role == "admin"):
                    await reply("Доступ запрещен")
                    return
                if len(args) > 1:
                    script_id = await self._find_escript_by_name(chat_id, " ".join(args[1:]))
                    if not script_id:
                        await reply("Скрипт не найден.")
                        return
                    text_data = await self._escript_settings_text(chat_id, script_id)
                    if not text_data:
                        await reply("Скрипт не найден.")
                        return
                    keyboard = await self._escript_settings_keyboard(chat_id, script_id)
                    await reply(text_data, reply_markup=keyboard)
                    return
                keyboard = await self._escript_list_keyboard(chat_id, show_status=False)
                await reply("<b>Выбери скрипт для настройки:</b>", reply_markup=keyboard)
                return
            if sub == "инфо":
                info_text = await self._escript_info_text(chat_id)
                keyboard = await self._escript_list_keyboard(chat_id, show_status=True)
                await reply(info_text + "\n\n<b>Список доступных скриптов:</b>", reply_markup=keyboard)
                return
            info_text = await self._escript_info_text(chat_id)
            keyboard = await self._escript_list_keyboard(chat_id, show_status=True)
            await reply(info_text + "\n\n<b>Список доступных скриптов:</b>", reply_markup=keyboard)
            return

        if command == "помощь":
            script_commands = await self.escripts.active_commands(chat_id)
            pages = self._help_pages_group(
                shop_type, prefix=prefix, script_commands=script_commands, free_mode=free_mode
            )
            page = 0
            kb = self._help_keyboard(page, len(pages))
            sent = await message.reply_text(pages[page], reply_markup=kb)
            self.help_sessions[sent.message_id] = pages
            return
        if command == "баланс":
            action = args[0].lower() if args else ""
            if action in {"зачислить", "изъять", "установить"}:
                if not free_mode and action in {"зачислить", "установить"} and not is_creator:
                    await reply("Команда не найдена.")
                    return
                sub_args = args[1:]
                explicit_username = self.pick_username_argument(sub_args)
                target = await self.resolve_target_from_message(
                    message, store, context, explicit_username, use_reply=not explicit_username
                )
                remaining = list(sub_args)
                if explicit_username:
                    removed = False
                    cleaned: list[str] = []
                    for token in remaining:
                        if not removed and token == explicit_username:
                            removed = True
                            continue
                        cleaned.append(token)
                    remaining = cleaned
                amount_token = remaining[-1] if remaining else None
                if not target or amount_token is None:
                    await reply(f"Используй {prefix}баланс {action} @user amount.")
                    return
                amount_value, is_all = self.parse_amount_token(amount_token)
                if action == "зачислить" and is_all:
                    await reply(
                        f"Укажи точную сумму от {self.MIN_TRANSACTION} до {self.MAX_TRANSACTION} - вариант all недоступен для зачисления."
                    )
                    return
                if amount_value is None and not is_all:
                    await reply(f"Укажи сумму от {self.MIN_TRANSACTION} до {self.MAX_TRANSACTION} или all.")
                    return
                uid, uname = target
                if await self._reject_bot_target(reply=reply, target_name=uname):
                    return
                if not (is_creator or role == "admin"):
                    await reply("Недостаточно прав для этой операции.")
                    return
                if action == "установить":
                    amount_value = max(0, min(self.MAX_TRANSACTION, amount_value or 0))
                    new_balance = await store.set_balance(chat_id, uid, uname, amount_value)
                    await store.log_event(
                        chat_id,
                        f"Баланс {uname} установлен на {format_currency(amount_value, currency)} ({self.log_handle(user)}).",
                    )
                    await reply(
                        f"Баланс {self.mention_id(uid, uname, notify=False)} обновлён: {format_currency(new_balance, currency)}"
                    )
                    return
                if is_all:
                    amount_value = await store.get_balance(chat_id, uid)
                    amount_value = min(amount_value or 0, self.MAX_TRANSACTION)
                delta = amount_value if action == "зачислить" else -amount_value
                if action == "зачислить":
                    limits = await store.get_limits(chat_id, user.id)
                    credit_cap = self._plan_limits(plan_code).get("credit")
                    if credit_cap and limits.get("credit", 0) + amount_value > credit_cap:
                        await reply("Достигнут максимальный лимит на зачисления")
                        return
                new_balance = await store.adjust_balance(chat_id, uid, uname, delta)
                if new_balance is None:
                    await reply("Недостаточно средств.")
                    return
                await store.log_event(
                    chat_id,
                    (
                        f"Пользователю {uname} {'зачислено' if delta > 0 else 'сняты'}"
                        f" {format_currency(abs(amount_value), currency)} (Команда {prefix}баланс {action} от {self.log_handle(user)})"
                    ),
                )
                if action == "зачислить":
                    await store.upsert_limits(chat_id, user.id, credit=amount_value)
                await reply(
                    f"Операция выполнена. Баланс {self.mention_id(uid, uname, notify=False)}: {format_currency(new_balance, currency)}"
                )
                return
            explicit_username = self.pick_username_argument(args)
            target = await self.resolve_target_from_message(
                message, store, context, explicit_username, use_reply=not explicit_username
            )
            if explicit_username and not target:
                await reply("Не нашёл пользователя для просмотра баланса.")
                return
            if not target:
                uid, uname = user.id, user.username or user.full_name
            else:
                uid, uname = target
                if await self._reject_bot_target(reply=reply, target_name=uname):
                    return
            if uid != user.id and not (is_creator or role in {"admin", "moderator"}):
                await reply("Доступ запрещен")
                return
            balance = await store.get_balance(chat_id, uid)
            label = "Ваш баланс" if uid == user.id else f"Баланс {self.mention_id(uid, uname, notify=False)}"
            await reply(f"{label}: {format_currency(balance, currency)}")
            return
        if command == "топ":
            top = await store.get_top(chat_id)
            filtered = [(uid, name, amount) for uid, name, amount in top if not self.is_bot_username(name)]
            lines = [
                f"{idx+1}. {self.mention_id(uid, name, notify=False)}: {format_currency(amount, currency)}"
                for idx, (uid, name, amount) in enumerate(filtered)
            ]
            await reply("Топ богатейших:\n" + "\n".join(lines) if lines else "Пока нет данных.")
            return
        if command == "курс":
            await reply(f"Текущий курс: {currency.get('rate')} за единицу.")
            return
        if command == "инфо":
            admins_ids = perms.get("economy_admins", [])
            moderators_ids = set(perms.get("allow_credit", [])) | set(perms.get("allow_debit", []))

            async def build_links(ids: Iterable[int]) -> str:
                links = []
                for uid in ids:
                    try:
                        member = await context.bot.get_chat_member(chat_id, uid)
                        name = self.mention(member.user)
                    except Exception:
                        name = self.mention_id(uid)
                    links.append(name)
                return ", ".join(links) if links else "-"

            admins_links = await build_links(admins_ids)
            moderators_links = await build_links(moderators_ids)
            if admins_links == "-":
                admins_links = "Отсутствует"
            if moderators_links == "-":
                moderators_links = "Отсутствует"
            auto_decl = "включено" if currency.get("auto_declension", True) else "выключено"
            rate_val = currency.get("rate")
            tax_val = currency.get("tax_rate")
            info_text = (
                "<b>Информация:</b>\n"
                f"• Валюта: {currency.get('icon')} {currency.get('name')}\n"
                f"• Курс: {rate_val}\n"
                f"• Дневной бонус: {format_currency(currency.get('daily_reward', 0), currency)}\n"
                f"• Налог: {tax_val / 100:.2f}%\n"
                f"• Автосклонение: {auto_decl}\n\n"
                "<b>Права</b>\n"
                f"• Админы экономики: {admins_links}\n"
                f"• Модераторы экономики: {moderators_links}"
            )
            await reply(info_text)
            return
        if command == "профиль":
            explicit_username = self.pick_username_argument(args)
            target = await self.resolve_target_from_message(
                message, store, context, explicit_username, use_reply=not explicit_username
            )
            if explicit_username and not target:
                await reply("Не удалось найти пользователя для показа профиля.")
                return
            target_id = user.id if not target else target[0]
            target_username = target[1] if target else user.full_name or user.username
            if target and await self._reject_bot_target(reply=reply, target_name=target_username):
                return
            target_name = self.mention_id(target_id, target_username)
            if target_id != user.id and not (is_creator or role == "admin"):
                await reply("Доступ запрещен")
                return
            balance = await store.get_balance(chat_id, target_id)
            job_info = await store.get_job(chat_id, target_id)
            rating_val = job_info.get("rating", 0.0)
            job_label = job_info.get("job_name") or "Безработный"
            target_role = self.resolve_role(perms, target_id)
            role_desc = {
                "admin": "Админ",
                "moderator": "Модератор",
                "default": "Гражданин",
                "banned": "Опущенный",
            }.get(target_role, "Гражданин")
            await reply(
                f"<b>Профиль</b> {target_name}\n"
                f"Роль: {role_desc}\n"
                f"Баланс: {format_currency(balance, currency)}\n"
                f"Работа: {job_label}\n"
                f"Общий рейтинг: {self.jobs.overall_stars(rating_val)} ({rating_val:.1f})"
            )
            return
        if command == "работа":
            if not require_plan(PLAN_ULTIMATE):
                return
            # inactivity penalty
            await self.jobs.adjust_inactivity(chat_id, user.id)
            if args and args[0].lower() == "инфо":
                explicit_username = self.pick_username_argument(args[1:]) if len(args) > 1 else None
                target_id = user.id
                target_name = self.mention_id(user.id, user.full_name or user.username)
                if explicit_username:
                    if not (is_creator or role == "admin"):
                        await reply("Доступ запрещен")
                        return
                    resolved = await self.resolve_target_from_message(
                        message, store, context, explicit_username, use_reply=not explicit_username
                    )
                    if not resolved:
                        await reply("Не удалось найти пользователя для работы.")
                        return
                    if await self._reject_bot_target(reply=reply, target_name=resolved[1]):
                        return
                    target_id, target_name = resolved[0], self.mention_id(resolved[0], resolved[1])
                target_job = await store.get_job(chat_id, target_id)
                if not target_job.get("job_name"):
                    if target_id == user.id:
                        await message.reply_text(
                            "<b>У тебя нет работы.</b> Пройди тест из 20 вопросов, отвечая на кнопки ниже.",
                            reply_markup=InlineKeyboardMarkup(
                                [[InlineKeyboardButton("Пройти тест", callback_data=f"job:teststart:{chat_id}:{target_id}")]]
                            ),
                            parse_mode=ParseMode.HTML,
                        )
                    else:
                        await reply("Пользователь пока без работы.")
                    return
                info_text = await self.jobs.work_info(chat_id, target_id, currency=currency)
                kb = None
                if target_id == user.id:
                    buttons = [
                        [InlineKeyboardButton("Уволиться", callback_data=f"job:quitask:{chat_id}:{target_id}"),],
                        [InlineKeyboardButton("Счёт", callback_data=f"job:wallet:{chat_id}:{target_id}"),],
                    ]
                    if shop_type == "normal":
                        buttons.append([InlineKeyboardButton("Прокачка", callback_data=f"job:upgrade:{chat_id}:{target_id}")])
                    kb = InlineKeyboardMarkup(buttons)
                sent = await message.reply_text(info_text, reply_markup=kb)
                if kb:
                    self.job_sessions[sent.message_id] = {"chat_id": chat_id, "user_id": user.id}
                return
            await self.jobs.handle_work_command(update, context, currency=currency, perms=perms)
            return
        if command == "права":
            role_desc = {
                "admin": "Админ",
                "moderator": "Модератор",
                "default": "Гражданин",
                "banned": "Опущенный",
            }.get(role, "Гражданин")
            await reply(f"<pre>Роль:\n {role_desc}</pre>")
            return
        if command == "бан":
            explicit_username = self.pick_username_argument(args)
            target = await self.resolve_target_from_message(message, store, context, explicit_username, use_reply=not explicit_username)
            if not target:
                await reply(f"Используй {prefix}бан @user")
                return
            if not (is_creator or role in {"admin", "moderator"}):
                await reply("Доступ запрещен")
                return
            uid, uname = target
            if await self._reject_bot_target(reply=reply, target_name=uname):
                return
            if uid == user.id:
                await reply("Нельзя забанить себя.")
                return
            if uid in admins:
                await reply("Нельзя забанить администратора чата.")
                return
            await store.ban_user(chat_id, uid)
            await store.log_event(chat_id, f"{self.log_handle(user)} забанил {self.log_handle(username=uname)}")
            await reply(f"{self.mention_id(uid, uname)} теперь <b>Опущенный</b>. Команды недоступны.")
            return
        if command == "разбанить":
            explicit_username = self.pick_username_argument(args)
            target = await self.resolve_target_from_message(
                message, store, context, explicit_username, use_reply=not explicit_username
            )
            if not target:
                await reply(f"Используй {prefix}разбанить @user")
                return
            if not (is_creator or role in {"admin", "moderator"}):
                await reply("Доступ запрещен")
                return
            uid, uname = target
            if await self._reject_bot_target(reply=reply, target_name=uname):
                return
            await store.unban_user(chat_id, uid)
            await store.log_event(chat_id, f"{self.log_handle(user)} разбанил {self.log_handle(username=uname)}")
            await reply(f"{self.mention_id(uid, uname)} восстановлен до роли <b>Гражданин</b>.")
            return
        if command in {"зачислить", "изъять"}:
            await reply("Команда устарела. Используй !!баланс зачислить/изъять/установить …")
            return
        if command == "перевод":
            handled = await self.transactions.handle_transfer_command(
                message,
                user,
                args,
                prefix,
                chat_id,
                store,
                currency,
                plan_code,
                context,
                reply=reply,
            )
            if handled:
                return
        if command == "ограбить":
            if not require_plan(PLAN_MEDIUM):
                return
            explicit_username = self.pick_username_argument(args)
            target = await self.resolve_target_from_message(message, store, context, explicit_username, use_reply=not explicit_username)
            if not target:
                await reply(f"Используй {prefix}ограбить @user")
                return
            uid, uname = target
            if await self._reject_bot_target(reply=reply, target_name=uname):
                return
            if uid == user.id:
                await reply("Грабить себя бессмысленно.")
                return
            cooldown_key = f"robbery:{chat_id}:{user.id}"
            remaining = await store.cooldown_remaining(cooldown_key)
            if remaining > 0:
                remaining_hours = max(1, (remaining + 3599) // 3600)
                await reply(f"Слишком часто грабить нельзя. Попробуй через {remaining_hours} ч.")
                return
            victim_balance = await store.get_balance(chat_id, uid)
            if victim_balance <= 0:
                await reply("Забирать нечего.")
                return
            roll = random.random()
            if roll < 0.01:
                steal_amount = victim_balance
                outcome_label = "всю сумму"
            elif roll < 0.31:
                steal_amount = victim_balance * 50 // 100
                outcome_label = "половину баланса"
            else:
                steal_amount = victim_balance * 15 // 100
                outcome_label = "15% баланса"
            if steal_amount < self.MIN_TRANSACTION:
                steal_amount = self.MIN_TRANSACTION
            steal_amount = min(steal_amount, victim_balance)
            if steal_amount > 0:
                deducted = await store.adjust_balance(chat_id, uid, uname, -steal_amount)
                if deducted is None:
                    await reply("Не удалось провести операцию.")
                    return
                new_balance = await store.adjust_balance(chat_id, user.id, user.username or user.full_name, steal_amount)
                await store.log_event(
                    chat_id,
                    f"{self.log_handle(user)} ограбил {self.log_handle(username=uname)} на {format_currency(steal_amount, currency)} ({outcome_label})",
                )
                await self._bump_rating(chat_id, user.id, 0.06)
                await reply(
                    f"Вы забрали {format_currency(steal_amount, currency)} у {self.mention_id(uid, uname)} ({outcome_label}). "
                    f"Ваш баланс: {format_currency(new_balance, currency)}"
                )
            await store.set_cooldown(cooldown_key, 6 * 3600)
            return
        if command == "ежедневка":
            last_claim = await store.last_daily_claim(chat_id, user.id)
            now = time.time()
            if not self.test_mode and now - last_claim < 24 * 3600:
                remaining = int((24 * 3600 - (now - last_claim)) / 3600)
                await reply(f"Бонус уже получен. Попробуй через {remaining} ч.")
                return
            reward = int(currency.get("daily_reward", 10000))
            luck_remaining = await store.luck_ticket_remaining(chat_id, user.id)
            luck_prefix = ""
            if luck_remaining > 0:
                if random.random() < 0.5:
                    reward *= 2
                    luck_prefix = "🎟️ Билет удачи сработал! "
                else:
                    luck_prefix = "🎟️ Билет удачи сегодня не сработал. "
            new_balance = await store.adjust_balance(
                chat_id,
                user.id,
                user.username or user.full_name,
                reward,
            )
            if not self.test_mode:
                await store.set_daily_claim(chat_id, user.id, now)
            await store.log_event(chat_id, f"Пользователь {self.log_handle(user)} получил ежедневку {format_currency(reward, currency)}")
            await self._bump_rating(chat_id, user.id, 0.05)
            await reply(
                f"{luck_prefix}Ежедневный бонус начислен: {format_currency(reward, currency)}. Ваш баланс: {format_currency(new_balance, currency)}"
            )
            return
        if command == "казна":
            sub = args[0].lower() if args else None
            if not sub:
                treasury = await store.get_treasury(chat_id)
                await reply(f"Казна: {format_currency(treasury, currency)}")
                return
            if sub == "депозит":
                amount_value, is_all = self.parse_amount_token(args[1]) if len(args) > 1 else (None, False)
                if amount_value is None and not is_all:
                    await reply(f"Укажи сумму от {self.MIN_TRANSACTION} до {self.MAX_TRANSACTION} или all.")
                    return
                if is_all:
                    amount_value = min(await store.get_balance(chat_id, user.id), self.MAX_TRANSACTION)
                updated = await store.adjust_balance(chat_id, user.id, user.username or user.full_name, -amount_value)
                if updated is None:
                    await reply("Недостаточно средств.")
                    return
                new_treasury = await store.adjust_treasury(chat_id, amount_value)
                await store.log_event(chat_id, f"{self.log_handle(user)} внёс {format_currency(amount_value, currency)} в казну")
                await self._bump_rating(chat_id, user.id, 0.05)
                await reply(f"Спасибо за вклад! Казна: {format_currency(new_treasury, currency)}")
                return
            if sub == "вывод":
                if not (is_creator or self.resolve_role(perms, user.id) == "admin"):
                    await reply("Доступ запрещен")
                    return
                amount_value, is_all = self.parse_amount_token(args[1]) if len(args) > 1 else (None, False)
                treasury = await store.get_treasury(chat_id)
                if is_all:
                    amount_value = treasury
                if amount_value is None:
                    await reply(f"Укажи сумму от {self.MIN_TRANSACTION} до {self.MAX_TRANSACTION} или all.")
                    return
                if amount_value > treasury:
                    await reply("Недостаточно средств в казне.")
                    return
                new_treasury = await store.adjust_treasury(chat_id, -amount_value)
                await store.adjust_balance(chat_id, user.id, user.username or user.full_name, amount_value, prevent_negative=False)
                await store.log_event(
                    chat_id,
                    f"{self.log_handle(user)} вывел {format_currency(amount_value, currency)} из казны (остаток {format_currency(new_treasury, currency)})",
                )
                await reply(f"Казна: {format_currency(new_treasury, currency)} (вы получили {format_currency(amount_value, currency)})")
                return
            await reply("Поддерживаются: депозит, вывод")
            return
        if command == "казино":
            handled = await self.casino.handle_command(
                update=update,
                context=context,
                chat_id=chat_id,
                user=user,
                args=args,
                prefix=prefix,
                store=store,
                currency=currency,
                is_creator=is_creator,
                plan_code=plan_code,
                reply=reply,
                message=message,
            )
            if handled:
                return
        if command in {"выдатьправа", "отобратьправа"}:
            explicit_username = self.pick_username_argument(args)
            target = await self.resolve_target_from_message(
                message, store, context, explicit_username, use_reply=not explicit_username
            )
            if not target or len(args) < 2:
                await reply(f"Используй {prefix}выдатьправа @user роль (admin|credit|debit)")
                return
            if not (is_creator or await self.has_admin_rights(user.id, admins, chat_id)):
                await reply("Доступ запрещен")
                return
            uid, uname = target
            role_arg = args[-1].lower()
            owner_id = await store.chat_owner(chat_id)
            if owner_id and uid == owner_id and (
                command == "отобратьправа" or role_arg in {"default", "credit", "debit", "moderator"}
            ):
                await reply("Доступ запрещен")
                return
            perms = await store.permissions(chat_id)
            for key in ("economy_admins", "allow_credit", "allow_debit"):
                perms.setdefault(key, [])
            lists = {
                "admin": perms["economy_admins"],
                "credit": perms["allow_credit"],
                "debit": perms["allow_debit"],
            }
            if role_arg == "moderator":
                lists["credit"].append(uid)
                lists["debit"].append(uid)
            elif role_arg == "default":
                lists["credit"] = [i for i in lists["credit"] if i != uid]
                lists["debit"] = [i for i in lists["debit"] if i != uid]
                lists["admin"] = [i for i in lists["admin"] if i != uid]
            elif role_arg in lists:
                if command == "выдатьправа":
                    lists[role_arg].append(uid)
                else:
                    lists[role_arg] = [i for i in lists[role_arg] if i != uid]
            else:
                await reply("Неизвестная роль. Доступны admin, credit, debit, moderator, default.")
                return
            if owner_id and owner_id not in lists["admin"]:
                lists["admin"].append(owner_id)
            await store.update_permissions(
                chat_id,
                economy_admins=lists.get("admin", perms["economy_admins"]),
                allow_credit=lists.get("credit", perms["allow_credit"]),
                allow_debit=lists.get("debit", perms["allow_debit"]),
            )
            await store.log_event(chat_id, f"Изменены права доступа участника {self.log_handle(username=uname)}: {role_arg}")
            await reply(f"Права для {self.mention_id(uid, uname)} обновлены: {role_arg}")
            return
        if command == "лог":
            owner_id = await store.chat_owner(chat_id)
            if not (is_creator or role == "admin"):
                await reply("Доступ запрещен")
                return
            hours = int(args[0]) if args and args[0].isdigit() else None
            if hours is None or hours <= 0:
                await reply("Укажи количество часов: !!лог 24")
                return
            await message.reply_text("Отправка логов...")
            since = time.time() - hours * 3600
            logs = await store.list_logs_since(chat_id, since)
            content_lines = [f"Логи за последние {hours} ч:"]
            if logs:
                for entry, ts in logs:
                    content_lines.append(f"- {entry}")
            else:
                content_lines.append("- Событий нет.")
            data = "\n".join(content_lines)
            bio = BytesIO(data.encode("utf-8"))
            bio.name = "logs.txt"
            try:
                await context.bot.send_document(user.id, bio)
            except Exception:
                if owner_id and owner_id != user.id:
                    bio.seek(0)
                    try:
                        await context.bot.send_document(owner_id, bio)
                    except Exception:
                        await reply("Не удалось отправить логи в личные сообщения.")
                        return
                else:
                    await reply("Не удалось отправить логи в личные сообщения.")
                    return
            await reply("Логи отправлены")
            return
        if command == "магазин":
            if shop_type == "normal":
                await self.normal_shop.send_shop(chat_id, message, currency)
            else:
                items = self.shop.visible_items(plan_code)
                keyboard = self.shop.build_shop_keyboard(chat_id, items, currency.get("icon", "💰"))
                text = self.shop.render_shop_menu_text() if items else "Магазин пуст."
                await message.reply_text(text, reply_markup=keyboard, parse_mode=ParseMode.HTML)
            return
        if command == "покупки":
            explicit_username = self.pick_username_argument(args)
            target_user_id = user.id
            if explicit_username:
                if not (is_creator or role in {"admin", "moderator"}):
                    await reply("Доступ запрещен")
                    return
                resolved = await self.resolve_target_from_message(message, store, context, explicit_username)
                if resolved:
                    if await self._reject_bot_target(reply=reply, target_name=resolved[1]):
                        return
                    target_user_id = resolved[0]
                else:
                    await reply("Не удалось найти пользователя для истории покупок.")
                    return
            per_page = 5
            total = await store.purchases_count(chat_id, target_user_id, include_consumed=True)
            items = await store.list_purchases(
                chat_id, target_user_id, limit=per_page, offset=0, include_consumed=True
            )
            total_pages = max(1, (total + per_page - 1) // per_page)
            keyboard = self.shop.build_purchase_keyboard(chat_id, target_user_id, 0, total_pages)
            sent = await message.reply_text(self.shop.render_purchases(items, currency), reply_markup=keyboard)
            self.purchases_sessions[sent.message_id] = {
                "chat_id": chat_id,
                "buyer_id": target_user_id,
                "viewer_id": user.id,
            }
            return
        if command == "товар" and args:
            if shop_type == "normal":
                handled = await self.normal_shop.handle_goods_command(
                    chat_id,
                    message,
                    user,
                    args,
                    currency,
                    is_creator,
                    perms,
                    prefix,
                )
                if handled:
                    return
            sub_command = args[0].lower()
            if sub_command != "использовать":
                await reply(f"Команда не распознана. Напиши {prefix}помощь.")
                return
            if len(args) < 2 or not args[1].isdigit():
                await reply(f"Формат: {prefix}товар использовать {{индекс}} [@user]")
                return
            idx = int(args[1])
            target_username = self.pick_username_argument(args[2:]) if len(args) > 2 else None
            purchase = await store.purchase_by_index(chat_id, user.id, idx, include_consumed=True)
            if not purchase:
                await reply("Товар с таким индексом не найден в ваших покупках.")
                return
            item_code = purchase.get("item_code")
            item = next((i for i in self.shop.items if i.get("code") == item_code), None)
            if not item:
                await reply("Товар устарел или больше не поддерживается.")
                return
            if purchase.get("consumed"):
                await reply("Этот товар уже использован.")
                return
            if not item.get("activatable"):
                await reply("Этот тип товара нельзя активировать.")
                return
            target = None
            if item.get("target_required"):
                if target_username:
                    target = await self.resolve_target_from_message(
                        message, store, context, target_username, use_reply=not target_username
                    )
                    if not target:
                        await reply("Не удалось найти цель для активации.")
                        return
                    if await self._reject_bot_target(reply=reply, target_name=target[1]):
                        return
                else:
                    target = await self._pick_random_nuke_target(chat_id, user.id)
                    if not target:
                        await reply("Не удалось подобрать цель для активации.")
                        return
            elif item_code == "shield":
                target = (user.id, user.username or user.full_name)
            await store.consume_purchase(purchase["id"])
            if item_code == "nuke":
                await self._trigger_nuke(chat_id, context, user, target, currency)
                await store.log_event(
                    chat_id, f"{self.log_handle(user)} активировал ядерку против {self.log_handle(username=target[1] if target else None, user_id=target[0] if target else None)}"
                )
                return
            if item_code == "shield":
                await store.set_nuke_shield(chat_id, user.id)
                await store.log_event(chat_id, f"{self.log_handle(user)} активировал щит")
                await reply("Щит активирован и сработает при следующей атаке.")
                return
            if item_code == "confetti":
                await self._bump_rating(chat_id, user.id, 0.05)
                bonus = self._scaled_daily_bonus(currency, "0.4", 5)
                await store.adjust_balance(
                    chat_id,
                    user.id,
                    user.username or user.full_name,
                    bonus,
                    prevent_negative=False,
                )
                await store.log_event(chat_id, f"{self.log_handle(user)} запустил конфетти")
                announcer = self.mention_id(user.id, user.full_name or user.username)
                await reply(f"🎉 {announcer} запускает конфетти-пушку!")
                await reply("✨ Конфетти летит по всему чату...")
                await reply(
                    f"🎊 Шоу завершено! Рейтинг {announcer} слегка вырос, бонус: {format_currency(bonus, currency)}."
                )
                return
            if item_code == "spotlight":
                if not target:
                    await reply("Нужна цель для прожектора.")
                    return
                target_id, target_name = target
                bonus = self._scaled_daily_bonus(currency, "0.8", 10)
                await store.adjust_balance(chat_id, target_id, target_name, bonus, prevent_negative=False)
                await self._bump_rating(chat_id, target_id, 0.2)
                await store.log_event(
                    chat_id,
                    f"{self.log_handle(user)} подсветил {self.log_handle(username=target_name, user_id=target_id)} прожектором",
                )
                await reply(f"🔦 Прожектор славы включён для {self.mention_id(target_id, target_name)}!")
                await reply(f"🏆 Минутка славы! Бонус: {format_currency(bonus, currency)} и +0.2 рейтинга.")
                return
            if item_code == "rain_cash":
                recipients = await self._pick_random_chat_users(chat_id, 3, exclude=[user.id])
                if not recipients:
                    await reply("Некому раздавать дождь. Попробуй позже.")
                    return
                base = self._scaled_daily_bonus(currency, "0.6", 8)
                lines = []
                await reply("🌧️ Над чатом сгущаются облака богатства...")
                for uid, uname in recipients:
                    bonus = random.randint(base, base * 2)
                    await store.adjust_balance(chat_id, uid, uname, bonus, prevent_negative=False)
                    lines.append(f"• {self.mention_id(uid, uname)} получил {format_currency(bonus, currency)}")
                await store.log_event(chat_id, f"{self.log_handle(user)} запустил денежный дождь")
                await reply("💸 Денежный дождь пролился!\n" + "\n".join(lines))
                return
            if item_code == "tax_holiday":
                remaining = await store.tax_holiday_remaining(chat_id)
                if remaining > 0:
                    mins = max(1, remaining // 60)
                    await reply(f"Налоговые каникулы уже активны ещё {mins} мин.")
                    return
                await store.set_tax_holiday(chat_id, 30 * 60)
                await store.log_event(chat_id, f"{self.log_handle(user)} включил налоговые каникулы")
                await reply("🧾 Налоговые каникулы активированы: налог 0% на 30 минут!")
                return
            if item_code == "loot_box":
                roll = random.choice(["cash", "rating", "shield"])
                await reply("🎁 Лутбокс открывается...")
                if roll == "cash":
                    bonus = self._scaled_daily_bonus(currency, "1.5", 15)
                    await store.adjust_balance(chat_id, user.id, user.username or user.full_name, bonus, prevent_negative=False)
                    await store.log_event(chat_id, f"{self.log_handle(user)} открыл лутбокс с бонусом {bonus}")
                    await reply(f"🎁 Лутбокс: тебе выпало {format_currency(bonus, currency)}!")
                    return
                if roll == "rating":
                    await self._bump_rating(chat_id, user.id, 0.3)
                    await store.log_event(chat_id, f"{self.log_handle(user)} получил рейтинг из лутбокса")
                    await reply("🎁 Лутбокс: рейтинг вырос на 0.3!")
                    return
                await store.set_nuke_shield(chat_id, user.id)
                await store.log_event(chat_id, f"{self.log_handle(user)} получил щит из лутбокса")
                await reply("🎁 Лутбокс: выпал энергетический щит!")
                return
            if item_code == "mystery_fine":
                if not target:
                    await reply("Нужна цель для штрафа-сюрприза.")
                    return
                target_id, target_name = target
                base = self._scaled_daily_bonus(currency, "0.9", 12)
                amount = random.randint(base, base * 2)
                await reply(f"🎲 Рулетка судьбы крутится для {self.mention_id(target_id, target_name)}...")
                if random.random() < 0.5:
                    current = await store.get_balance(chat_id, target_id)
                    fine = min(amount, current)
                    if fine <= 0:
                        await reply(f"Сюрприз не удался: у {self.mention_id(target_id, target_name)} пусто.")
                        return
                    await store.adjust_balance(chat_id, target_id, target_name, -fine)
                    await store.log_event(
                        chat_id,
                        f"{self.log_handle(user)} оштрафовал {self.log_handle(username=target_name, user_id=target_id)} на {fine}",
                    )
                    await reply(
                        f"🎲 Штраф-сюрприз! {self.mention_id(target_id, target_name)} теряет {format_currency(fine, currency)}."
                    )
                    return
                await store.adjust_balance(chat_id, target_id, target_name, amount, prevent_negative=False)
                await store.log_event(
                    chat_id,
                    f"{self.log_handle(user)} подарил {self.log_handle(username=target_name, user_id=target_id)} {amount}",
                )
                await reply(
                    f"🎲 Сюрприз! {self.mention_id(target_id, target_name)} получает {format_currency(amount, currency)}."
                )
                return
            if item_code == "party_boost":
                recipients = await self._pick_random_chat_users(chat_id, 5)
                if not recipients:
                    await reply("Некому устроить вечеринку. Попробуй позже.")
                    return
                bonus = self._scaled_daily_bonus(currency, "0.6", 8)
                lines = []
                await reply("🎶 Вечеринка стартует! Светомузыка включена.")
                for uid, uname in recipients:
                    await store.adjust_balance(chat_id, uid, uname, bonus, prevent_negative=False)
                    lines.append(f"• {self.mention_id(uid, uname)} +{format_currency(bonus, currency)}")
                await store.log_event(chat_id, f"{self.log_handle(user)} устроил вечеринку")
                await reply("🎈 Вечеринка в разгаре!\n" + "\n".join(lines))
                return
            if item_code == "luck_ticket":
                remaining = await store.luck_ticket_remaining(chat_id, user.id)
                await store.set_luck_ticket(chat_id, user.id, 24 * 3600)
                if remaining > 0:
                    await reply("🎟️ Билет удачи уже активен. Таймер обновлён.")
                else:
                    await reply("🎟️ Билет удачи активирован на сутки. Шанс x2 к ежедневке!")
                await store.log_event(chat_id, f"{self.log_handle(user)} активировал билет удачи")
                return
            if item_code == "instant_work":
                remaining = await store.instant_work_remaining(chat_id, user.id)
                await store.set_instant_work(chat_id, user.id, 3600)
                if remaining > 0:
                    await reply("⚡ Срочная смена уже активна. Таймер обновлён.")
                else:
                    await reply("⚡ Срочная смена активирована. Следующая смена без ожидания!")
                await store.log_event(chat_id, f"{self.log_handle(user)} активировал срочную смену")
                return
            if item_code == "treasury_gift":
                price = int(item.get("price", 0))
                treasury_share = int(price * 0.4) if price else 0
                pool = max(0, price - treasury_share)
                recipients = await self._pick_random_chat_users(chat_id, 3, exclude=[user.id])
                if treasury_share:
                    await store.adjust_treasury(chat_id, treasury_share, prevent_negative=False)
                lines = []
                if recipients and pool:
                    per_user = max(1, pool // len(recipients))
                    for uid, uname in recipients:
                        await store.adjust_balance(chat_id, uid, uname, per_user, prevent_negative=False)
                        lines.append(f"• {self.mention_id(uid, uname)} +{format_currency(per_user, currency)}")
                await store.log_event(chat_id, f"{self.log_handle(user)} отправил подарок казны")
                message_text = "🏛️ Подарок казны активирован!"
                if treasury_share:
                    message_text += f"\nВ казну: {format_currency(treasury_share, currency)}."
                if lines:
                    message_text += "\nРозыгрыш:\n" + "\n".join(lines)
                await reply(message_text)
                return
            if item_code == "hype_wave":
                recipients = await self._pick_random_chat_users(chat_id, 2, exclude=[user.id])
                await store.log_event(chat_id, f"{self.log_handle(user)} запустил хайп-волну")
                await reply("📣 Хайп-волна идёт по чату!")
                await reply("🚀 Лента ускоряется, внимание к магазину на максимум.")
                if recipients:
                    bonus = self._scaled_daily_bonus(currency, "0.7", 10)
                    lines = []
                    for uid, uname in recipients:
                        await store.adjust_balance(chat_id, uid, uname, bonus, prevent_negative=False)
                        lines.append(f"• {self.mention_id(uid, uname)} +{format_currency(bonus, currency)}")
                    await reply("🔥 Бонусы от волны:\n" + "\n".join(lines))
                else:
                    await reply("🔥 Волна прошла по пустому залу - без бонусов.")
                return
            await reply("Активировать удалось, но тип не поддержан.")
            return
        if await self.escripts.handle_command(
            chat_id=chat_id,
            command=command,
            update=update,
            context=context,
            args=args,
            plan_code=plan_code,
            override_only=False,
        ):
            return
        await reply(f"Команда не распознана. Напиши {prefix}помощь.")

    def build_application(self) -> Application:
        application = (
            ApplicationBuilder()
            .token(self.settings.token)
            .post_init(self.post_init)
            .defaults(
                Defaults(
                    parse_mode=ParseMode.HTML,
                    allow_sending_without_reply=True,
                    disable_web_page_preview=True,
                )
            )
            .build()
        )
        application.add_handler(CommandHandler("start", self.start))
        application.add_handler(CommandHandler("help", self.help_command))
        application.add_handler(CommandHandler("plans", self.plans_command))
        application.add_handler(CommandHandler("info", self.info_command))
        application.add_handler(CommandHandler("testmode", self.testmode_command))
        application.add_handler(CommandHandler("promo", self.promo_command))
        application.add_handler(CommandHandler("give_plan", self.give_plan_command))
        application.add_handler(CommandHandler("settings", self.settings_command))
        application.add_handler(CommandHandler("backup", self.backup_command))
        application.add_handler(CommandHandler("msg_all", self.msg_all_command))
        application.add_handler(CommandHandler("msg", self.msg_command))
        application.add_handler(ChatMemberHandler(self.on_bot_added, chat_member_types=("my_chat_member",)))
        application.add_handler(CallbackQueryHandler(self.handle_settings_callback, pattern=r"^settings:"))
        application.add_handler(CallbackQueryHandler(self.help_callback, pattern=r"^help:page:"))
        application.add_handler(CallbackQueryHandler(self.handle_plans_callback, pattern=r"^plans:"))
        application.add_handler(CallbackQueryHandler(self.poll_close_callback, pattern=r"^poll:close:"))
        application.add_handler(CallbackQueryHandler(self.handle_shop_router, pattern=r"^shop:"))
        application.add_handler(CallbackQueryHandler(self.handle_upgrade_shop_router, pattern=r"^upshop:"))
        application.add_handler(CallbackQueryHandler(self.handle_shop_settings_router, pattern=r"^shopcfg:"))
        application.add_handler(CallbackQueryHandler(self.handle_purchases_callback, pattern=r"^purchases:"))
        application.add_handler(CallbackQueryHandler(self.handle_broadcast_callback, pattern=r"^broadcast:"))
        application.add_handler(CallbackQueryHandler(self.handle_job_callback, pattern=r"^job:"))
        application.add_handler(CallbackQueryHandler(self.handle_casino_callback, pattern=r"^casino:"))
        application.add_handler(CallbackQueryHandler(self.handle_nuke_callback, pattern=r"^nuke:"))
        application.add_handler(CallbackQueryHandler(self.handle_escript_callback, pattern=r"^escript:"))
        application.add_handler(CallbackQueryHandler(self.handle_escript_button_callback, pattern=r"^escriptbtn:"))
        application.add_handler(PreCheckoutQueryHandler(self.precheckout_handler))
        application.add_handler(MessageHandler(filters.SUCCESSFUL_PAYMENT, self.successful_payment_handler))
        application.add_error_handler(self.error_handler)
        application.add_handler(MessageHandler(filters.ChatType.PRIVATE & filters.TEXT, self.handle_private_message))
        application.add_handler(
            MessageHandler(
                filters.ChatType.PRIVATE & (filters.PHOTO | filters.Document.ALL | filters.ANIMATION),
                self.handle_private_message,
            )
        )
        application.add_handler(
            MessageHandler(
                filters.ChatType.GROUPS & ~filters.StatusUpdate.ALL,
                self.handle_group_command,
            )
        )
        return application

    def run(self) -> None:
        if not self.settings.token:
            raise RuntimeError("BOT_TOKEN не задан")
        app = self.build_application()
        logger.info("Бот запущен и готов")
        while True:
            try:
                app.run_polling(allowed_updates=Update.ALL_TYPES, drop_pending_updates=False)
                break
            except TimedOut:
                logger.warning("Таймаут при инициализации Telegram API. Повтор через 5 секунд...")
                time.sleep(5)
            except Exception as exc:
                logger.error("Ошибка запуска бота: %s", exc)
                time.sleep(5)


__all__ = ["EconomyBot"]
