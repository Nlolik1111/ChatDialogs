import time
from typing import Any

from telegram import Update
from telegram.ext import ContextTypes


class PrivateMessages:
    def __init__(self, bot: Any) -> None:
        self.bot = bot

    async def handle(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        user = update.effective_user
        if not user:
            return
        store = self.bot.ensure_storage()
        on_cooldown = await store.check_cooldown(f"pm:{user.id}", 5)
        if on_cooldown:
            if update.message is not None:
                await update.message.reply_text("⏳ Подождите 5 секунд перед следующим сообщением.")
            return
        await self.bot._handle_private_message_impl(update, context)
