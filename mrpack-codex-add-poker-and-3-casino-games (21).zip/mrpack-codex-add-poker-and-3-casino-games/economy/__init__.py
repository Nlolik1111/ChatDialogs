"""Economy package facade."""
