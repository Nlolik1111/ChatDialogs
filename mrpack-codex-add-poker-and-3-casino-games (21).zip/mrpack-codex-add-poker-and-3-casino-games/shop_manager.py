import importlib
_mod = importlib.import_module("economy.shop_manager")
__all__ = [name for name in dir(_mod) if not name.startswith("__")]
globals().update({name: getattr(_mod, name) for name in __all__})
