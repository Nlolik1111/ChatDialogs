"""Application entrypoint for the EconomyBot."""
import logging

from economy.bot_core import EconomyBot
from economy.config import load_settings


logging.basicConfig(level=logging.INFO)


def main() -> None:
    """Load settings and run the bot."""
    settings = load_settings()
    bot = EconomyBot(settings)
    bot.run()


if __name__ == "__main__":
    main()
